# Security Specification — BatamProperti.com (`security_spec.md`)

## 1. Data Invariants

1. **Global Default Deny**: Any path not explicitly matched in `firestore.rules` is unconditionally denied (`allow read, write: if false;`).
2. **Admin Identity Verification**: Admin privileges are never trusted from client-supplied fields or unverified emails. A user is an admin (`isAdmin()`) only if authenticated (`request.auth != null`), `request.auth.token.email_verified == true`, and either their UID exists in `/admins/$(request.auth.uid)` or their verified email matches the bootstrapped owner email (`properti988@gmail.com`).
3. **Public vs Draft Listing Isolation**: Public visitors can only `get` or `list` documents in `/listings/{listingId}` whose `resource.data.status` is in `['Aktif', 'Terjual', 'Tersewa']`. Listings with status `'Draft'`, `'Menunggu Review'`, or `'Diarsipkan'` are strictly readable only by `isAdmin()`.
4. **Zero Public Listing Mutation**: Public visitors cannot `create`, `update`, or `delete` documents in `/listings/{listingId}` or `/settings/{settingId}`. Only `isAdmin()` can mutate listings and settings.
5. **PII Isolation on Inquiries & Consignments**: `/inquiries/{inquiryId}` and `/submissions/{submissionId}` contain customer PII (`name`, `whatsapp`). Public visitors can only `create` valid new submissions with initial status (`status == 'Baru'`, `internalNotes == ''`, `reviewStatus == 'Menunggu Review'`), and can NEVER `get`, `list`, `update`, or `delete` them. Only `isAdmin()` can read or update inquiries and submissions.
6. **Strict Timestamp & Key Enforcement**: Every `create` and `update` enforces `hasAll` / `hasOnly` key allowlists, string length boundaries, bounded array sizes, and server timestamp integrity (`request.time`).

## 2. The "Dirty Dozen" Payloads (Adversarial Test Cases)

1. **Payload 1 — Public Listing Creation Attempt**: Unauthenticated or non-admin user tries to create `/listings/prop-hack-1`. Must return `PERMISSION_DENIED`.
2. **Payload 2 — Draft Listing Leak via Query**: Unauthenticated user tries to read/list a `/listings/draft-1` where `status == 'Draft'` or `'Menunggu Review'`. Must return `PERMISSION_DENIED`.
3. **Payload 3 — Shadow Field Injection on Inquiry**: Visitor creates `/inquiries/inq-1` with an extra field `"isAdminApproved": true`. Rejected by `hasOnly()`.
4. **Payload 4 — Pre-populated Internal Notes by Visitor**: Visitor creates `/inquiries/inq-2` with `internalNotes: "Bypassed review"`. Rejected because `internalNotes` must be `""` on public create.
5. **Payload 5 — Status Shortcutting on Submission**: Visitor creates `/submissions/sub-1` with `reviewStatus: "Aktif"` instead of `"Menunggu Review"`. Rejected by schema validation.
6. **Payload 6 — PII Scraping on Inquiries**: Authenticated non-admin user attempts `get` or `list` on `/inquiries`. Rejected (`allow read: if isAdmin()`).
7. **Payload 7 — PII Scraping on Submissions**: Authenticated non-admin user attempts `get` or `list` on `/submissions`. Rejected (`allow read: if isAdmin()`).
8. **Payload 8 — Unverified Admin Email Spoof**: User with `email: "properti988@gmail.com"` but `email_verified: false` attempts to update `/settings/general`. Rejected.
9. **Payload 9 — Self-Assigned Admin Escalation**: Regular authenticated user attempts to write their own UID to `/admins/{uid}`. Rejected (`allow create, update, delete: if isAdmin()`).
10. **Payload 10 — Value Poisoning / Oversized String**: Visitor submits an inquiry with a 10,000-character `message` (exceeding max 2000 chars). Rejected by size check.
11. **Payload 11 — Unbounded Array Poisoning**: Visitor submits `/submissions/sub-2` with 25 photo URLs (exceeding max 10). Rejected by `photos.size() <= 10`.
12. **Payload 12 — Forged Client Timestamp**: Visitor submits `/inquiries/inq-3` with a past/future `createdAt` not matching `request.time`. Rejected by `incoming().createdAt == request.time`.
