import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rulesText = fs.readFileSync(new URL('./firestore.rules', import.meta.url), 'utf8');

test('Firestore rules enforce Global Default Deny and Rules Version 2', () => {
  assert.ok(rulesText.includes("rules_version = '2';"));
  assert.ok(rulesText.includes('match /{document=**}'));
  assert.ok(rulesText.includes('allow read, write: if false;'));
});

test('Dirty Dozen #1 & #2: Public listing mutations denied and Draft/Menunggu Review isolated to Admin', () => {
  assert.ok(
    rulesText.includes("existing().status in ['Aktif', 'Terjual', 'Tersewa'] || isAdmin()"),
    'Public listing reads must restrict status to Aktif, Terjual, or Tersewa'
  );
  assert.ok(
    rulesText.includes('allow create: if isAdmin() && isValidId(listingId) && isValidListing(incoming())'),
    'Only admin can create listings'
  );
});

test('Dirty Dozen #3, #4, #5: Public inquiries and submissions enforce strict key allowlists and initial status', () => {
  assert.ok(rulesText.includes("incoming().status == 'Baru'"));
  assert.ok(rulesText.includes("incoming().internalNotes == ''"));
  assert.ok(rulesText.includes("incoming().reviewStatus == 'Menunggu Review'"));
  assert.ok(rulesText.includes("incoming().leadStatus == 'Baru'"));
});

test('Dirty Dozen #6 & #7: PII isolation on inquiries and submissions restricts reads to Admin', () => {
  const inquiriesBlock = rulesText.split('match /inquiries/{inquiryId}')[1].split('match /submissions')[0];
  assert.ok(inquiriesBlock.includes('allow get: if isAdmin() && isValidId(inquiryId);'));
  assert.ok(inquiriesBlock.includes('allow list: if isAdmin();'));

  const submissionsBlock = rulesText.split('match /submissions/{submissionId}')[1].split('match /settings')[0];
  assert.ok(submissionsBlock.includes('allow get: if isAdmin() && isValidId(submissionId);'));
  assert.ok(submissionsBlock.includes('allow list: if isAdmin();'));
});

test('Dirty Dozen #8 & #9: Email spoofing and self-assigned admin escalation blocked', () => {
  assert.ok(
    rulesText.includes('request.auth != null && request.auth.token.email_verified == true'),
    'Must verify email_verified == true'
  );
  assert.ok(
    rulesText.includes("request.auth.token.email == 'properti988@gmail.com'"),
    'Must check bootstrapped admin email'
  );
});

test('Dirty Dozen #10, #11, #12: String lengths, bounded arrays, and request.time timestamps enforced', () => {
  assert.ok(rulesText.includes('data.photos is list && data.photos.size() <= 15'));
  assert.ok(rulesText.includes('data.photos is list && data.photos.size() <= 10'));
  assert.ok(rulesText.includes('incoming().createdAt == request.time'));
  assert.ok(rulesText.includes('incoming().updatedAt == request.time'));
});
