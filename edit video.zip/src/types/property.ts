export type PropertyType =
  | 'Rumah'
  | 'Ruko'
  | 'Apartemen'
  | 'Tanah'
  | 'Kos-kosan'
  | 'Gudang'
  | 'Komersial Lainnya';

export type TransactionType = 'Dijual' | 'Disewakan';

export type MarketCategory = 'Primary' | 'Secondary';

export type ListingStatus =
  | 'Draft'
  | 'Menunggu Review'
  | 'Aktif'
  | 'Terjual'
  | 'Tersewa'
  | 'Diarsipkan';

export type LeadStatus =
  | 'Baru'
  | 'Sudah Dihubungi'
  | 'Jadwal Survei'
  | 'Negosiasi'
  | 'Selesai'
  | 'Tidak Jadi';

export type BatamArea =
  | 'Batam Center'
  | 'Pasir Putih'
  | 'Nagoya'
  | 'Bengkong'
  | 'Sekupang'
  | 'Tiban'
  | 'Batu Aji'
  | 'Lubuk Baja'
  | 'Nongsa'
  | 'Kabil & Punggur';

export interface PropertyListing {
  id: string;
  code: string;
  title: string;
  slug: string;
  propertyType: PropertyType;
  transactionType: TransactionType;
  marketCategory?: MarketCategory; // 'Primary' (Properti Baru / Developer) or 'Secondary' (Properti Seken)
  price: number;
  pricePeriod?: string; // e.g., "per tahun", "per bulan", or ""
  area: string;
  complexName?: string;
  address?: string;
  landArea: number;
  buildingArea: number;
  dimensions?: string;
  bedrooms: number;
  bathrooms: number;
  floors: number;
  furnishStatus?: string;
  facilities: string[];
  description: string;
  photos: string[];
  mainPhotoIndex: number;
  videoUrl?: string;
  legalStatus?: string;
  isFeatured: boolean;
  isDemo: boolean;
  status: ListingStatus;
  listedDate: string;
  viewsCount?: number;
  waClicksCount?: number;
  lastClickedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserPreferenceProfile {
  targetPrice?: number;
  minPrice?: number | '';
  maxPrice?: number | '';
  priceRangeLabel?: string;
  preferredArea?: string;
  preferredPropertyType?: PropertyType | 'Semua';
  preferredTransactionType?: TransactionType | 'Semua';
  lastKeyword?: string;
  viewedListingIds: string[];
  updatedAt: string;
}

export interface RecommendedListingItem {
  listing: PropertyListing;
  reasonBadge: string;
  matchType: 'budget' | 'preference' | 'popular';
  engagementScore: number;
}

export interface CustomerInquiry {
  id: string;
  inquiryType: 'Pertanyaan' | 'Survei';
  name: string;
  whatsapp: string;
  listingId: string;
  listingCode: string;
  listingTitle: string;
  message: string;
  preferredSurveyTime: string;
  status: LeadStatus;
  internalNotes: string;
  createdAt: string;
  updatedAt: string;
}

export interface PropertySubmission {
  id: string;
  ownerName: string;
  whatsapp: string;
  propertyType: PropertyType;
  transactionType: TransactionType;
  location: string;
  expectedPrice: number;
  specifications: string;
  description: string;
  photos: string[];
  reviewStatus: 'Menunggu Review';
  leadStatus: LeadStatus;
  internalNotes: string;
  createdAt: string;
  updatedAt: string;
}

export interface SiteSettings {
  siteName: string;
  companyName: string;
  logoText: string;
  logoUrl: string;
  whatsappNumber: string;
  email: string;
  officeAddress: string;
  heroTitle: string;
  heroSubtitle: string;
  instagramUrl: string;
  facebookUrl: string;
  tiktokUrl: string;
  youtubeUrl: string;
  seoTitle: string;
  seoDescription: string;
  updatedAt: string;
}

export type SortOption = 'terbaru' | 'harga-terendah' | 'harga-tertinggi';

export interface FilterState {
  keyword: string;
  transactionType: 'Semua' | TransactionType;
  propertyType: 'Semua' | PropertyType;
  marketCategory?: 'Semua' | MarketCategory;
  area: string; // 'Semua' or specific area
  minPrice: number | '';
  maxPrice: number | '';
  minLandArea: number | '';
  minBuildingArea: number | '';
  minBedrooms: number | '';
  minBathrooms: number | '';
  onlyFeatured: boolean;
  onlyNew: boolean;
  sortBy: SortOption;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}
