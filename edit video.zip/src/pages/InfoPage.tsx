import React, { useEffect, useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { buildWhatsAppUrl } from '../utils/propertyLogic';
import { RoutePath } from '../components/Navbar';

interface InfoPageProps {
  initialTab?: 'tentang' | 'kontak' | 'faq' | 'privasi' | 'syarat';
  navigate: (route: RoutePath) => void;
}

export const InfoPage: React.FC<InfoPageProps> = ({
  initialTab = 'tentang',
  navigate,
}) => {
  const { settings, updateSeoMeta } = useProperty();
  const [activeTab, setActiveTab] = useState<
    'tentang' | 'kontak' | 'faq' | 'privasi' | 'syarat'
  >(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    updateSeoMeta(
      `Informasi & Layanan Resmi — ${settings.companyName} | ${settings.siteName}`,
      `Informasi resmi mengenai ${settings.companyName}, kontak kantor di Batam, FAQ, Kebijakan Privasi, dan Syarat Penggunaan.`
    );
  }, [settings.companyName, settings.siteName, updateSeoMeta]);

  const waUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Halo Tim ${settings.siteName} (${settings.companyName}), saya ingin menghubungi kantor terkait layanan properti di Batam.`
  );

  const tabs: Array<{
    id: 'tentang' | 'kontak' | 'faq' | 'privasi' | 'syarat';
    label: string;
  }> = [
    { id: 'tentang', label: 'Tentang Kami' },
    { id: 'kontak', label: 'Kontak Resmi' },
    { id: 'faq', label: 'Pertanyaan Umum (FAQ)' },
    { id: 'privasi', label: 'Kebijakan Privasi' },
    { id: 'syarat', label: 'Syarat Penggunaan' },
  ];

  return (
    <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6 space-y-2">
        <p className="text-xs font-semibold text-amber-700">
          Pusat Informasi Resmi · {settings.companyName}
        </p>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif">
          Tentang {settings.siteName} & Ketentuan Layanan
        </h1>
      </div>

      {/* Interactive Tab Bar */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeTab === tab.id
                ? 'bg-[#0A192F] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        {activeTab === 'tentang' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-serif">
                Profil {settings.companyName} ({settings.siteName})
              </h2>
              <p className="text-sm text-slate-700 leading-relaxed mt-3">
                <strong>{settings.siteName}</strong> adalah portal jual, sewa, dan pemasaran properti di Kota Batam yang dikelola oleh <strong>{settings.companyName}</strong>. Kami memfokuskan layanan pada kawasan strategis di Batam, meliputi <strong>Batam Center, Pasir Putih, Nagoya, Bengkong, Sekupang, Tiban</strong>, serta area berkembang lainnya.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-2">
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <h3 className="text-sm font-bold text-slate-900">
                  01. Kurasi Listing Transparan
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Setiap properti disajikan dengan spesifikasi faktual. Kami tidak mencantumkan klaim legalitas atau kondisi bangunan yang belum diverifikasi oleh pemilik atau admin.
                </p>
              </div>
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <h3 className="text-sm font-bold text-slate-900">
                  02. Pendampingan Survei & Negosiasi
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Transaksi properti membutuhkan peninjauan langsung. Tim broker kami mengatur jadwal survei fisik serta menjembatani negosiasi antara pemilik dan calon pembeli/penyewa.
                </p>
              </div>
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <h3 className="text-sm font-bold text-slate-900">
                  03. Pemasaran Titip Properti
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Pemilik rumah, ruko, apartemen, maupun tanah di Batam dapat menitipkan pemasaran unitnya melalui formulir online yang ditinjau oleh tim internal.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'kontak' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-serif">
                Kontak Resmi & Kantor {settings.companyName}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Seluruh informasi kontak di bawah ini dikelola langsung melalui Dashboard Admin.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4 text-sm">
                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Perusahaan Pengelola
                  </p>
                  <p className="font-bold text-slate-900 mt-0.5">
                    {settings.companyName || '[Placeholder Admin: Nama perusahaan belum diisi]'}
                  </p>
                </div>

                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Nomor WhatsApp Utama
                  </p>
                  {settings.whatsappNumber ? (
                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block font-bold text-[#0A192F] underline tabular-nums mt-0.5"
                    >
                      +{settings.whatsappNumber.replace(/^\+/, '')} (Klik untuk Chat WhatsApp)
                    </a>
                  ) : (
                    <p className="text-xs text-amber-700 mt-0.5">
                      [Placeholder Admin: Nomor WhatsApp belum dikonfigurasi di Pengaturan Website]
                    </p>
                  )}
                </div>

                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Alamat Email Resmi
                  </p>
                  {settings.email ? (
                    <a
                      href={`mailto:${settings.email}`}
                      className="inline-block font-semibold text-slate-900 underline mt-0.5"
                    >
                      {settings.email}
                    </a>
                  ) : (
                    <p className="text-xs text-amber-700 mt-0.5">
                      [Placeholder Admin: Email belum dikonfigurasi di Pengaturan Website]
                    </p>
                  )}
                </div>

                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Alamat Kantor Operasional
                  </p>
                  <p className="text-slate-800 leading-relaxed mt-0.5">
                    {settings.officeAddress ||
                      '[Placeholder Admin: Alamat kantor belum diisi di Pengaturan Website]'}
                  </p>
                </div>
              </div>

              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                <h3 className="text-sm font-bold text-slate-900">
                  Tautan Media Sosial Resmi
                </h3>
                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center justify-between py-2 border-b border-slate-200">
                    <span className="font-semibold text-slate-600">Instagram</span>
                    {settings.instagramUrl ? (
                      <a
                        href={settings.instagramUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0A192F] font-semibold underline"
                      >
                        {settings.instagramUrl}
                      </a>
                    ) : (
                      <span className="text-slate-400">
                        [Belum diisi oleh Admin]
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-slate-200">
                    <span className="font-semibold text-slate-600">Facebook</span>
                    {settings.facebookUrl ? (
                      <a
                        href={settings.facebookUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0A192F] font-semibold underline"
                      >
                        {settings.facebookUrl}
                      </a>
                    ) : (
                      <span className="text-slate-400">
                        [Belum diisi oleh Admin]
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-slate-200">
                    <span className="font-semibold text-slate-600">TikTok</span>
                    {settings.tiktokUrl ? (
                      <a
                        href={settings.tiktokUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0A192F] font-semibold underline"
                      >
                        {settings.tiktokUrl}
                      </a>
                    ) : (
                      <span className="text-slate-400">
                        [Belum diisi oleh Admin]
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="font-semibold text-slate-600">YouTube</span>
                    {settings.youtubeUrl ? (
                      <a
                        href={settings.youtubeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0A192F] font-semibold underline"
                      >
                        {settings.youtubeUrl}
                      </a>
                    ) : (
                      <span className="text-slate-400">
                        [Belum diisi oleh Admin]
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => navigate({ page: 'admin' })}
                    className="px-4 py-2 text-xs font-semibold text-white bg-[#0A192F] rounded-lg"
                  >
                    Ubah Kontak di Pengaturan Admin
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'faq' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-slate-900 font-serif">
              Pertanyaan yang Sering Diajukan (FAQ)
            </h2>
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <h3 className="text-sm font-bold text-slate-900">
                  1. Apakah pengajuan minat atau jadwal survei di website ini memungut biaya?
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Tidak. Seluruh fitur pencarian, penyimpanan favorit, dan pengajuan jadwal survei di BatamProperti.com gratis tanpa biaya pendaftaran. Pengajuan minat bukan merupakan tanda jadi (booking fee) dan tidak mengikat transaksi.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <h3 className="text-sm font-bold text-slate-900">
                  2. Bagaimana proses transaksi pembelian atau penyewaan properti di Batam?
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Kami tidak menggunakan sistem keranjang belanja instan karena properti memerlukan verifikasi fisik dan legalitas. Setelah Anda memilih unit, broker {settings.companyName} akan mendampingi survei lokasi, negosiasi harga dengan pemilik, pengecekan dokumen (seperti SHGB/UWTO), hingga akad/penandatanganan resmi di hadapan PPAT/Notaris.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <h3 className="text-sm font-bold text-slate-900">
                  3. Bagaimana cara menitipkan properti saya agar dipasarkan di BatamProperti.com?
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Buka menu “Titipkan Properti”, lalu lengkapi nama pemilik, nomor WhatsApp, lokasi, spesifikasi, harga harapan, dan foto unit. Data Anda akan masuk dengan status “Menunggu Review” dan segera ditinjau oleh admin sebelum dipublikasikan.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <h3 className="text-sm font-bold text-slate-900">
                  4. Apa arti label “Contoh Listing” pada beberapa kartu properti?
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Unit dengan label “Contoh Listing” merupakan data demonstrasi awal sistem untuk memperlihatkan cara kerja katalog dan filter. Admin dapat menghapus seluruh Contoh Listing kapan saja melalui Dashboard Admin.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'privasi' && (
          <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
            <h2 className="text-xl font-bold text-slate-900 font-serif">
              Kebijakan Privasi ({settings.siteName})
            </h2>
            <p>
              <strong>{settings.companyName}</strong> menghormati dan melindungi privasi setiap pengunjung serta pemilik properti yang menggunakan layanan {settings.siteName}.
            </p>
            <ul className="list-disc list-inside space-y-2 text-xs text-slate-600">
              <li>
                <strong>Pengumpulan Data:</strong> Kami hanya mengumpulkan informasi yang Anda kirimkan secara sukarela melalui formulir pertanyaan, permintaan survei, atau formulir titip properti (meliputi nama, nomor WhatsApp, dan rincian kebutuhan properti).
              </li>
              <li>
                <strong>Isolasi Data Pribadi (PII):</strong> Nomor telepon/WhatsApp, nama peminat, serta catatan internal broker disimpan secara aman dan hanya dapat diakses oleh Administrator terautentikasi. Data pribadi pelanggan tidak pernah ditampilkan kepada pengunjung publik.
              </li>
              <li>
                <strong>Penggunaan Data:</strong> Data kontak hanya digunakan oleh tim broker resmi {settings.companyName} untuk menindaklanjuti permintaan survei, konsultasi, atau verifikasi titip properti.
              </li>
            </ul>
          </div>
        )}

        {activeTab === 'syarat' && (
          <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
            <h2 className="text-xl font-bold text-slate-900 font-serif">
              Syarat Penggunaan ({settings.siteName})
            </h2>
            <p>
              Dengan mengakses dan menggunakan {settings.siteName}, Anda menyetujui ketentuan penggunaan berikut:
            </p>
            <ul className="list-disc list-inside space-y-2 text-xs text-slate-600">
              <li>
                <strong>Sifat Informasi Katalog:</strong> Informasi harga, ketersediaan, dan spesifikasi properti dapat berubah sewaktu-waktu sesuai pembaruan dari pemilik properti. Pastikan selalu melakukan konfirmasi dan survei fisik bersama broker resmi kami.
              </li>
              <li>
                <strong>Pengajuan Minat Non-Mengikat:</strong> Pengiriman formulir pertanyaan atau jadwal survei melalui situs ini tidak membentuk perjanjian pengikatan jual beli maupun tanda jadi.
              </li>
              <li>
                <strong>Kebenaran Data Titip Properti:</strong> Pemilik properti yang mengirimkan pengajuan titip jual/sewa menyatakan bahwa dirinya adalah pemilik sah atau pihak yang diberi kuasa atas unit properti tersebut.
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
