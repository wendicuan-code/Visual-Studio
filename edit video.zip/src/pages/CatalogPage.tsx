import React, { useEffect, useMemo, useState } from 'react';
import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import {
  BATAM_AREAS,
  DEFAULT_FILTERS,
  detectPriceRangeId,
  filterAndSortListings,
  mapPriceRangeToBounds,
  PRICE_RANGE_OPTIONS,
  PROPERTY_TYPES,
} from '../utils/propertyLogic';
import {
  FilterState,
  PropertyListing,
  PropertyType,
  SortOption,
  TransactionType,
} from '../types/property';
import { PropertyCard } from '../components/PropertyCard';
import { SmartRecommendations } from '../components/SmartRecommendations';
import { RoutePath } from '../components/Navbar';

interface CatalogPageProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  navigate: (route: RoutePath) => void;
  onAskSurvey?: (listing: PropertyListing) => void;
}

const PAGE_SIZE = 6;

export const CatalogPage: React.FC<CatalogPageProps> = ({
  filters,
  setFilters,
  navigate,
}) => {
  const { publicListings, updateSeoMeta, recordUserSearchIntent } = useProperty();
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    updateSeoMeta(
      'Katalog Properti Dijual & Disewakan di Batam | BatamProperti.com',
      'Cari dan filter rumah, ruko, apartemen, tanah kavling, dan kos-kosan Primary maupun Secondary di Batam Center, Pasir Putih, Nagoya, Bengkong, Sekupang, dan Tiban.'
    );
  }, [updateSeoMeta]);

  const filteredListings = useMemo(
    () => filterAndSortListings(publicListings, filters, false),
    [publicListings, filters]
  );

  const visibleListings = filteredListings.slice(0, visibleCount);

  const resetAllFilters = () => {
    setFilters(DEFAULT_FILTERS);
    setVisibleCount(PAGE_SIZE);
  };

  const activePriceRangeId = detectPriceRangeId(filters.minPrice, filters.maxPrice);

  const handlePriceRangeSelect = (rangeId: string) => {
    const bounds = mapPriceRangeToBounds(rangeId);
    setFilters((prev) => ({
      ...prev,
      minPrice: bounds.minPrice,
      maxPrice: bounds.maxPrice,
    }));
    recordUserSearchIntent({
      minPrice: bounds.minPrice,
      maxPrice: bounds.maxPrice,
      targetPrice: bounds.targetPrice,
      priceRangeLabel: bounds.priceRangeLabel,
    });
    setVisibleCount(PAGE_SIZE);
  };

  const hasActiveFilters =
    filters.keyword !== '' ||
    filters.transactionType !== 'Semua' ||
    filters.propertyType !== 'Semua' ||
    (filters.marketCategory && filters.marketCategory !== 'Semua') ||
    filters.area !== 'Semua' ||
    filters.minPrice !== '' ||
    filters.maxPrice !== '' ||
    filters.minLandArea !== '' ||
    filters.minBuildingArea !== '' ||
    filters.minBedrooms !== '' ||
    filters.minBathrooms !== '' ||
    filters.onlyFeatured ||
    filters.onlyNew;

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header & Category Mode Switcher (Properti Baru/Primary vs Secondary vs Jual/Sewa) */}
      <div className="border-b border-stone-200 pb-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-emerald-700">
              {filters.onlyNew || filters.marketCategory === 'Primary'
                ? 'Koleksi Properti Baru & Primary Developer · PT Cuan Properti'
                : filters.marketCategory === 'Secondary'
                ? 'Koleksi Properti Secondary (Seken / Pemilik) · PT Cuan Properti'
                : 'Katalog Properti Resmi · PT Cuan Properti'}
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif mt-1">
              {filters.onlyNew || filters.marketCategory === 'Primary'
                ? 'Properti Baru (Primary) di Batam'
                : filters.marketCategory === 'Secondary'
                ? 'Properti Secondary (Seken) di Batam'
                : 'Daftar Properti Dijual & Disewakan di Batam'}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <label htmlFor="catalog-sort" className="text-xs font-semibold text-slate-600">
              Urutkan:
            </label>
            <select
              id="catalog-sort"
              value={filters.sortBy}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, sortBy: e.target.value as SortOption }))
              }
              className="px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="terbaru">Listing Terbaru</option>
              <option value="harga-terendah">Harga Terendah</option>
              <option value="harga-tertinggi">Harga Tertinggi</option>
            </select>
          </div>
        </div>

        {/* Quick Category Tabs: Properti Baru/Primary, Secondary, Semua, Dijual, Disewakan */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setFilters((prev) => ({
                ...prev,
                onlyNew: true,
                marketCategory: 'Primary',
                transactionType: 'Semua',
              }));
              setVisibleCount(PAGE_SIZE);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              filters.onlyNew || filters.marketCategory === 'Primary'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-slate-700 hover:border-emerald-500'
            }`}
          >
            Properti Baru / Primary
          </button>

          <button
            type="button"
            onClick={() => {
              setFilters((prev) => ({
                ...prev,
                onlyNew: false,
                marketCategory: 'Secondary',
                transactionType: 'Semua',
              }));
              setVisibleCount(PAGE_SIZE);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              filters.marketCategory === 'Secondary'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-slate-700 hover:border-emerald-500'
            }`}
          >
            Properti Secondary (Seken)
          </button>

          <button
            type="button"
            onClick={() => {
              setFilters((prev) => ({
                ...prev,
                onlyNew: false,
                marketCategory: 'Semua',
                transactionType: 'Semua',
              }));
              setVisibleCount(PAGE_SIZE);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              !filters.onlyNew &&
              (!filters.marketCategory || filters.marketCategory === 'Semua') &&
              filters.transactionType === 'Semua'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-slate-700 hover:border-slate-400'
            }`}
          >
            Semua Properti (Jual & Sewa)
          </button>

          <button
            type="button"
            onClick={() => {
              setFilters((prev) => ({
                ...prev,
                onlyNew: false,
                marketCategory: 'Semua',
                transactionType: 'Dijual',
              }));
              recordUserSearchIntent({ transactionType: 'Dijual' });
              setVisibleCount(PAGE_SIZE);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              !filters.onlyNew &&
              (!filters.marketCategory || filters.marketCategory === 'Semua') &&
              filters.transactionType === 'Dijual'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-slate-700 hover:border-slate-400'
            }`}
          >
            Properti Dijual
          </button>

          <button
            type="button"
            onClick={() => {
              setFilters((prev) => ({
                ...prev,
                onlyNew: false,
                marketCategory: 'Semua',
                transactionType: 'Disewakan',
              }));
              recordUserSearchIntent({ transactionType: 'Disewakan' });
              setVisibleCount(PAGE_SIZE);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              !filters.onlyNew &&
              (!filters.marketCategory || filters.marketCategory === 'Semua') &&
              filters.transactionType === 'Disewakan'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-slate-700 hover:border-slate-400'
            }`}
          >
            Properti Disewakan
          </button>
        </div>
      </div>

      {/* Filter Panel */}
      <section
        aria-label="Filter Katalog Properti"
        className="bg-white border border-stone-200 rounded-3xl p-5 space-y-4 shadow-2xs"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3.5">
          {/* Keyword */}
          <div className="sm:col-span-2">
            <label
              htmlFor="cat-keyword"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Kata Kunci / Kode Listing
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="cat-keyword"
                type="text"
                value={filters.keyword}
                onChange={(e) => {
                  const val = e.target.value;
                  setFilters((prev) => ({ ...prev, keyword: val }));
                  recordUserSearchIntent({ keyword: val });
                  setVisibleCount(PAGE_SIZE);
                }}
                placeholder="Cari kode BP-BTM, nama perumahan, atau lokasi..."
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A192F]"
              />
            </div>
          </div>

          {/* Jual / Sewa */}
          <div>
            <label
              htmlFor="cat-trans"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Status Transaksi
            </label>
            <select
              id="cat-trans"
              value={filters.transactionType}
              onChange={(e) => {
                const val = e.target.value as 'Semua' | TransactionType;
                setFilters((prev) => ({
                  ...prev,
                  transactionType: val,
                }));
                recordUserSearchIntent({ transactionType: val });
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Semua (Jual & Sewa)</option>
              <option value="Dijual">Dijual</option>
              <option value="Disewakan">Disewakan</option>
            </select>
          </div>

          {/* Jenis Properti */}
          <div>
            <label
              htmlFor="cat-type"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Jenis Properti
            </label>
            <select
              id="cat-type"
              value={filters.propertyType}
              onChange={(e) => {
                const val = e.target.value as 'Semua' | PropertyType;
                setFilters((prev) => ({
                  ...prev,
                  propertyType: val,
                }));
                recordUserSearchIntent({ propertyType: val });
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Semua Jenis</option>
              {PROPERTY_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Area / Kecamatan */}
          <div>
            <label
              htmlFor="cat-area"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Area / Kecamatan
            </label>
            <select
              id="cat-area"
              value={filters.area}
              onChange={(e) => {
                const val = e.target.value;
                setFilters((prev) => ({ ...prev, area: val }));
                recordUserSearchIntent({ area: val });
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Seluruh Batam</option>
              {BATAM_AREAS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>

          {/* Kisaran Harga (Range Price) */}
          <div>
            <label
              htmlFor="cat-price-range"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Kisaran Harga
            </label>
            <select
              id="cat-price-range"
              value={activePriceRangeId}
              onChange={(e) => handlePriceRangeSelect(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">Semua Harga</option>
              {PRICE_RANGE_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Toggle Advanced Specifications Filter */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => setShowAdvanced((prev) => !prev)}
              aria-expanded={showAdvanced}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0A192F] hover:text-amber-700"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>
                {showAdvanced
                  ? 'Sembunyikan Filter Spesifikasi & Harga Detail'
                  : 'Filter Spesifikasi Luas Tanah/Bangunan & Kamar'}
              </span>
            </button>

            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.onlyFeatured}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, onlyFeatured: e.target.checked }))
                }
                className="rounded border-slate-300 text-[#0A192F] focus:ring-[#0A192F]"
              />
              <span>Properti Unggulan</span>
            </label>

            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.onlyNew || filters.marketCategory === 'Primary'}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    onlyNew: e.target.checked,
                    marketCategory: e.target.checked ? 'Primary' : 'Semua',
                  }))
                }
                className="rounded border-slate-300 text-[#0A192F] focus:ring-[#0A192F]"
              />
              <span>Properti Primary (Baru)</span>
            </label>
          </div>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={resetAllFilters}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Hapus Filter</span>
            </button>
          )}
        </div>

        {/* Expanded Advanced Filters */}
        {showAdvanced && (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
            <div>
              <label
                htmlFor="cat-min-price"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Harga Minimum (Rp)
              </label>
              <input
                id="cat-min-price"
                type="number"
                min={0}
                step={50000000}
                value={filters.minPrice}
                onChange={(e) => {
                  const val = e.target.value ? Number(e.target.value) : '';
                  setFilters((prev) => ({
                    ...prev,
                    minPrice: val,
                  }));
                  recordUserSearchIntent({
                    minPrice: val,
                    maxPrice: filters.maxPrice,
                  });
                }}
                placeholder="Contoh: 500000000"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="cat-max-price"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Harga Maksimum (Rp)
              </label>
              <input
                id="cat-max-price"
                type="number"
                min={0}
                step={50000000}
                value={filters.maxPrice}
                onChange={(e) => {
                  const val = e.target.value ? Number(e.target.value) : '';
                  setFilters((prev) => ({
                    ...prev,
                    maxPrice: val,
                  }));
                  recordUserSearchIntent({
                    minPrice: filters.minPrice,
                    maxPrice: val,
                  });
                }}
                placeholder="Contoh: 2000000000"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="cat-min-lt"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Min. Luas Tanah (m²)
              </label>
              <input
                id="cat-min-lt"
                type="number"
                min={0}
                value={filters.minLandArea}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    minLandArea: e.target.value ? Number(e.target.value) : '',
                  }))
                }
                placeholder="Contoh: 100"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="cat-min-lb"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Min. Luas Bangunan (m²)
              </label>
              <input
                id="cat-min-lb"
                type="number"
                min={0}
                value={filters.minBuildingArea}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    minBuildingArea: e.target.value ? Number(e.target.value) : '',
                  }))
                }
                placeholder="Contoh: 80"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="cat-min-kt"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Min. Kamar Tidur
              </label>
              <select
                id="cat-min-kt"
                value={filters.minBedrooms}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    minBedrooms: e.target.value ? Number(e.target.value) : '',
                  }))
                }
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
              >
                <option value="">Semua</option>
                <option value="1">1+ Kamar Tidur</option>
                <option value="2">2+ Kamar Tidur</option>
                <option value="3">3+ Kamar Tidur</option>
                <option value="4">4+ Kamar Tidur</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="cat-min-km"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Min. Kamar Mandi
              </label>
              <select
                id="cat-min-km"
                value={filters.minBathrooms}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    minBathrooms: e.target.value ? Number(e.target.value) : '',
                  }))
                }
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
              >
                <option value="">Semua</option>
                <option value="1">1+ Kamar Mandi</option>
                <option value="2">2+ Kamar Mandi</option>
                <option value="3">3+ Kamar Mandi</option>
              </select>
            </div>
          </div>
        )}
      </section>

      {/* Results Count Summary */}
      <div className="flex items-center justify-between text-xs text-slate-600">
        <p>
          Menampilkan <strong className="text-slate-900 tabular-nums">{visibleListings.length}</strong> dari{' '}
          <strong className="text-slate-900 tabular-nums">{filteredListings.length}</strong> properti yang sesuai kriteria
        </p>
      </div>

      {/* Results Grid or Empty State */}
      {filteredListings.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-4">
          <h2 className="text-lg font-bold text-slate-900 font-serif">
            Tidak Ada Properti yang Sesuai Filter Pencarian
          </h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Maaf, kami tidak menemukan listing properti yang cocok persis dengan kombinasi filter Anda saat ini. Lihat rekomendasi yang mendekati pilihan Anda atau properti terpopuler di bawah ini.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={resetAllFilters}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0A192F] hover:bg-slate-800 rounded-lg transition-colors"
            >
              Hapus Semua Filter
            </button>
            <button
              type="button"
              onClick={() => navigate({ page: 'consign' })}
              className="px-5 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors"
            >
              Titipkan Properti
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {visibleListings.map((listing) => (
              <PropertyCard
                key={listing.id}
                listing={listing}
                onSelect={(slug) => navigate({ page: 'detail', slug })}
              />
            ))}
          </div>

          {/* Load More Pagination */}
          {visibleCount < filteredListings.length && (
            <div className="pt-6 text-center">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                className="px-6 py-3 text-xs font-semibold text-[#0A192F] bg-white border border-slate-300 hover:border-[#0A192F] rounded-lg transition-colors tabular-nums"
              >
                Muat Lebih Banyak ({filteredListings.length - visibleCount} Properti Lainnya)
              </button>
            </div>
          )}
        </>
      )}

      {/* Smart Recommendations Section on Catalog Page (Matches User Rate + Popular) */}
      <SmartRecommendations
        onSelectListing={(slug) => navigate({ page: 'detail', slug })}
        limit={3}
        compactHeader
      />
    </div>
  );
};
