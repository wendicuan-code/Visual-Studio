import React, { useEffect, useState } from 'react';
import { MessageCircle, ArrowUpRight, CheckCircle2, Building2 } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import {
  buildConsignWhatsAppMessage,
  buildWhatsAppUrl,
} from '../utils/propertyLogic';
import { RoutePath } from '../components/Navbar';

interface ConsignPageProps {
  navigate: (route: RoutePath) => void;
}

export const ConsignPage: React.FC<ConsignPageProps> = ({ navigate }) => {
  const { submitPropertyConsignment, settings, updateSeoMeta } = useProperty();

  // Strictly 3 fields as requested: Nama, Alamat & Blok Rumah, Deskripsi
  const [ownerName, setOwnerName] = useState('');
  const [blockAddress, setBlockAddress] = useState('');
  const [description, setDescription] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedWaUrl, setSubmittedWaUrl] = useState<string | null>(null);
  const [submittedMessage, setSubmittedMessage] = useState<string>('');

  useEffect(() => {
    updateSeoMeta(
      'Titipkan Properti ke WhatsApp Admin | BatamProperti.com',
      'Titip listing properti cukup tulis Nama, Alamat & Blok Rumah, serta Deskripsi, lalu kirimkan langsung ke WhatsApp Admin.'
    );
  }, [updateSeoMeta]);

  const liveWaMessage = buildConsignWhatsAppMessage({
    ownerName: ownerName || '-',
    blockAddress: blockAddress || '-',
    description: description || '-',
  });

  const liveWaUrl = buildWhatsAppUrl(settings.whatsappNumber, liveWaMessage);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (ownerName.trim().length < 2) {
      setError('Mohon isi Nama terlebih dahulu.');
      return;
    }
    if (blockAddress.trim().length < 3) {
      setError('Mohon isi Alamat & Blok Rumah.');
      return;
    }
    if (description.trim().length < 5) {
      setError('Mohon isi Deskripsi singkat properti.');
      return;
    }

    setSubmitting(true);

    const formattedMsg = buildConsignWhatsAppMessage({
      ownerName: ownerName.trim(),
      blockAddress: blockAddress.trim(),
      description: description.trim(),
    });

    const targetWaUrl = buildWhatsAppUrl(settings.whatsappNumber, formattedMsg);

    // Save record in background so Admin also has a log in Dashboard Admin
    try {
      await submitPropertyConsignment({
        ownerName: ownerName.trim(),
        whatsapp: '081200000000',
        propertyType: 'Rumah',
        transactionType: 'Dijual',
        location: blockAddress.trim(),
        expectedPrice: 1_000_000_000,
        specifications: blockAddress.trim(),
        description: description.trim(),
        photos: ['/images/rumah-batam-center.svg'],
      });
    } catch {
      // Proceed directly to WhatsApp
    }

    setSubmitting(false);
    setSubmittedMessage(formattedMsg);
    setSubmittedWaUrl(targetWaUrl);

    // Directly open WhatsApp
    const linkEl = document.createElement('a');
    linkEl.href = targetWaUrl;
    linkEl.target = '_blank';
    linkEl.rel = 'noopener noreferrer';
    document.body.appendChild(linkEl);
    linkEl.click();
    document.body.removeChild(linkEl);
  };

  return (
    <div className="max-w-[860px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="border-b border-stone-200 pb-6 space-y-2">
        <p className="text-xs font-semibold text-emerald-700">
          Titip Listing Properti · Langsung Kirim ke WhatsApp
        </p>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif">
          Titipkan Properti Anda
        </h1>
        <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
          Cukup tulis <strong>Nama</strong>, <strong>Alamat &amp; Blok Rumah</strong>, serta{' '}
          <strong>Deskripsi</strong> properti Anda, lalu kirimkan langsung ke WhatsApp Admin.
        </p>
      </div>

      {submittedWaUrl ? (
        <div className="bg-white border border-emerald-200 rounded-3xl p-6 sm:p-8 shadow-md space-y-6">
          <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-sm font-bold">
                Pesan Titip Listing Siap Dikirim ke WhatsApp!
              </p>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Klik tombol di bawah jika aplikasi WhatsApp belum terbuka secara otomatis.
              </p>
            </div>
          </div>

          <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-2">
            <p className="text-xs font-semibold text-slate-500">
              Pesan WhatsApp ke Admin (+{settings.whatsappNumber}):
            </p>
            <pre className="text-xs text-slate-800 whitespace-pre-wrap font-sans leading-relaxed">
              {submittedMessage}
            </pre>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={submittedWaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-2xl shadow-sm inline-flex items-center gap-2 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Kirim ke WhatsApp Sekarang</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>

            <button
              type="button"
              onClick={() => {
                setSubmittedWaUrl(null);
                setOwnerName('');
                setBlockAddress('');
                setDescription('');
              }}
              className="px-5 py-3.5 text-xs font-semibold text-slate-700 bg-stone-100 hover:bg-stone-200 rounded-2xl transition-colors"
            >
              Tulis Titip Listing Baru
            </button>

            <button
              type="button"
              onClick={() => navigate({ page: 'catalog' })}
              className="px-5 py-3.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
            >
              Kembali ke Katalog
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Strictly 3-Field Form: Nama, Alamat & Blok Rumah, Deskripsi */}
          <form
            onSubmit={handleSubmit}
            className="lg:col-span-7 bg-white border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5"
          >
            {error && (
              <div
                role="alert"
                className="p-4 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium"
              >
                {error}
              </div>
            )}

            <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <h2 className="text-base font-bold text-slate-900 font-serif">
                Form Titip Listing ke WhatsApp
              </h2>
            </div>

            {/* 1. NAMA */}
            <div>
              <label
                htmlFor="consign-owner"
                className="block text-xs font-semibold text-slate-800 mb-1.5"
              >
                1. Nama *
              </label>
              <input
                id="consign-owner"
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="Tulis nama Anda (contoh: Bapak Hendra)"
                className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            {/* 2. ALAMAT & BLOK RUMAH */}
            <div>
              <label
                htmlFor="consign-block-address"
                className="block text-xs font-semibold text-slate-800 mb-1.5"
              >
                2. Alamat &amp; Blok Rumah *
              </label>
              <input
                id="consign-block-address"
                type="text"
                required
                value={blockAddress}
                onChange={(e) => setBlockAddress(e.target.value)}
                placeholder="Contoh: Perumahan Sukajadi Blok B No. 12, Batam Center"
                className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            {/* 3. DESKRIPSI */}
            <div>
              <label
                htmlFor="consign-description"
                className="block text-xs font-semibold text-slate-800 mb-1.5"
              >
                3. Deskripsi *
              </label>
              <textarea
                id="consign-description"
                rows={4}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Contoh: Dijual rumah 2 lantai, 4 KT, 3 KM, SHGB, harga Rp 1,9 miliar nego..."
                className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 px-6 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-2xl shadow-md transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <MessageCircle className="w-4 h-4" />
                <span>
                  {submitting ? 'Mengirim ke WhatsApp...' : 'Kirimkan ke WhatsApp'}
                </span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Right Column: Live WhatsApp Preview */}
          <aside className="lg:col-span-5 bg-white border border-stone-200/90 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-serif font-bold text-sm">
                WA
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Isi Pesan WhatsApp
                </h3>
                <p className="text-xs text-emerald-700 font-medium">
                  Tujuan: +{settings.whatsappNumber}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
              {liveWaMessage}
            </div>

            {ownerName.trim() && blockAddress.trim() && description.trim() && (
              <a
                href={liveWaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Langsung Buka WhatsApp</span>
              </a>
            )}
          </aside>
        </div>
      )}
    </div>
  );
};
