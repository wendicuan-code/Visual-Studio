import React, { useEffect } from 'react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/PropertyCard';
import { RoutePath } from '../components/Navbar';
import { PropertyListing } from '../types/property';

interface FavoritesPageProps {
  navigate: (route: RoutePath) => void;
  onAskSurvey?: (listing: PropertyListing) => void;
}

export const FavoritesPage: React.FC<FavoritesPageProps> = ({
  navigate,
}) => {
  const { publicListings, favorites, updateSeoMeta } = useProperty();

  useEffect(() => {
    updateSeoMeta(
      'Properti Favorit Anda | BatamProperti.com',
      'Lihat daftar properti favorit pilihan Anda di Batam dan konsultasikan langsung bersama Admin BatamProperti.'
    );
  }, [updateSeoMeta]);

  const favoriteListings = publicListings.filter((item) =>
    favorites.includes(item.id)
  );

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Saved Favorites */}
      <section className="space-y-6">
        <div className="border-b border-slate-200 pb-5 space-y-1.5">
          <p className="text-xs font-semibold text-amber-700">Daftar Simpanan Anda</p>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif">
            Properti Favorit ({favoriteListings.length})
          </h1>
          <p className="text-xs text-slate-500">
            Properti yang Anda tandai tersimpan otomatis di memori peramban (browser) perangkat Anda dan akan tetap ada meskipun halaman ditutup atau dibuka kembali tanpa perlu login.
          </p>
        </div>

        {favoriteListings.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
            <h2 className="text-base font-bold text-slate-800">
              Belum Ada Properti yang Disimpan ke Favorit
            </h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Klik ikon hati pada kartu properti atau halaman detail untuk menyimpan properti pilihan Anda dan membandingkannya nanti.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => navigate({ page: 'catalog' })}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0A192F] rounded-lg"
              >
                Jelajahi Katalog Properti
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteListings.map((listing) => (
              <PropertyCard
                key={listing.id}
                listing={listing}
                onSelect={(slug) => navigate({ page: 'detail', slug })}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
