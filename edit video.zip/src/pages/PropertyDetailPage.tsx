import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Building2, ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import {
  buildListingWhatsAppMessage,
  buildWhatsAppUrl,
  formatRupiahLengkap,
  formatRupiahRingkas,
} from '../utils/propertyLogic';
import { PropertyCard } from '../components/PropertyCard';
import { SmartRecommendations } from '../components/SmartRecommendations';
import { RoutePath } from '../components/Navbar';
import { PropertyListing } from '../types/property';

interface PropertyDetailPageProps {
  slug: string;
  navigate: (route: RoutePath) => void;
  onAskSurvey?: (listing: PropertyListing, mode?: 'Pertanyaan' | 'Survei') => void;
}

export const PropertyDetailPage: React.FC<PropertyDetailPageProps> = ({
  slug,
  navigate,
}) => {
  const {
    publicListings,
    listings,
    isAdmin,
    favorites,
    toggleFavorite,
    settings,
    updateSeoMeta,
    recordListingInteraction,
  } = useProperty();

  const pool = isAdmin ? listings : publicListings;
  const listing = useMemo(
    () =>
      pool.find(
        (item) =>
          item.slug.toLowerCase() === slug.toLowerCase() ||
          item.code.toLowerCase() === slug.toLowerCase() ||
          item.id === slug
      ),
    [pool, slug]
  );

  const [activePhotoIdx, setActivePhotoIdx] = useState<number>(0);
  const [imgError, setImgError] = useState<boolean>(false);
  const trackedSlugRef = useRef<string | null>(null);

  useEffect(() => {
    if (listing) {
      setActivePhotoIdx(listing.mainPhotoIndex || 0);
      setImgError(false);
      updateSeoMeta(
        `${listing.title} (${listing.code}) — ${listing.transactionType} di ${listing.area}, Batam`,
        `${listing.transactionType} ${listing.propertyType} di ${listing.area}, Batam. Harga ${formatRupiahRingkas(
          listing.price,
          listing.pricePeriod
        )}. ${listing.description.slice(0, 120)}`
      );
      if (trackedSlugRef.current !== listing.id) {
        trackedSlugRef.current = listing.id;
        recordListingInteraction(listing, 'view');
      }
    }
  }, [listing, recordListingInteraction, updateSeoMeta]);

  if (!listing) {
    return (
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center space-y-4">
        <h1 className="text-2xl font-bold text-slate-900 font-serif">
          Listing Properti Tidak Ditemukan
        </h1>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          Properti yang Anda cari mungkin telah terjual, diarsipkan, atau URL tidak sesuai. Silakan kembali ke katalog properti BatamProperti.com.
        </p>
        <div className="pt-2">
          <button
            type="button"
            onClick={() => navigate({ page: 'catalog' })}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0A192F] rounded-lg"
          >
            Kembali ke Katalog Properti
          </button>
        </div>
      </div>
    );
  }

  const isFav = favorites.includes(listing.id);
  const photos =
    listing.photos && listing.photos.length > 0
      ? listing.photos
      : ['/images/rumah-batam-center.svg'];
  const currentPhoto = photos[activePhotoIdx] || photos[0];

  const handlePrevPhoto = () => {
    setActivePhotoIdx((prev) => (prev - 1 + photos.length) % photos.length);
    setImgError(false);
  };

  const handleNextPhoto = () => {
    setActivePhotoIdx((prev) => (prev + 1) % photos.length);
    setImgError(false);
  };

  const waMessage = buildListingWhatsAppMessage(listing);
  const waUrl = buildWhatsAppUrl(settings.whatsappNumber, waMessage);

  // Only include non-empty specification rows (never fabricate or show empty fields)
  const specRows: Array<{ label: string; value: string }> = [
    { label: 'Kode Listing', value: listing.code },
    { label: 'Status Transaksi', value: listing.transactionType },
    {
      label: 'Kategori Pasar',
      value:
        listing.marketCategory === 'Primary'
          ? 'Primary (Properti Baru)'
          : 'Secondary (Properti Seken)',
    },
    { label: 'Status Ketersediaan', value: listing.status },
    { label: 'Jenis Properti', value: listing.propertyType },
    { label: 'Area / Kecamatan', value: listing.area },
  ];

  if (listing.complexName && listing.complexName.trim().length > 0) {
    specRows.push({ label: 'Perumahan / Gedung', value: listing.complexName });
  }
  if (listing.address && listing.address.trim().length > 0) {
    specRows.push({ label: 'Lokasi', value: listing.address });
  }
  if (listing.landArea > 0) {
    specRows.push({ label: 'Luas Tanah', value: `${listing.landArea} m²` });
  }
  if (listing.buildingArea > 0) {
    specRows.push({ label: 'Luas Bangunan', value: `${listing.buildingArea} m²` });
  }
  if (listing.dimensions && listing.dimensions.trim().length > 0) {
    specRows.push({ label: 'Dimensi', value: listing.dimensions });
  }
  if (listing.bedrooms > 0) {
    specRows.push({ label: 'Kamar Tidur', value: `${listing.bedrooms} Kamar` });
  }
  if (listing.bathrooms > 0) {
    specRows.push({ label: 'Kamar Mandi', value: `${listing.bathrooms} Kamar` });
  }
  if (listing.floors > 0) {
    specRows.push({ label: 'Jumlah Lantai', value: `${listing.floors} Lantai` });
  }
  if (listing.furnishStatus && listing.furnishStatus.trim().length > 0) {
    specRows.push({ label: 'Kondisi / Furnish', value: listing.furnishStatus });
  }
  // Legalitas is ONLY shown if filled by admin
  if (listing.legalStatus && listing.legalStatus.trim().length > 0) {
    specRows.push({ label: 'Informasi Legalitas', value: listing.legalStatus });
  }
  if (listing.listedDate && listing.listedDate.trim().length > 0) {
    specRows.push({ label: 'Tanggal Listing', value: listing.listedDate });
  }

  const similarListings = publicListings
    .filter(
      (item) =>
        item.id !== listing.id &&
        (item.area.toLowerCase() === listing.area.toLowerCase() ||
          item.propertyType === listing.propertyType)
    )
    .slice(0, 3);

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Breadcrumb & Back Link */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <button
          type="button"
          onClick={() => navigate({ page: 'catalog' })}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-[#0A192F]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Katalog Properti</span>
        </button>

        <div className="text-xs text-slate-500 flex items-center flex-wrap gap-1.5">
          <span>Katalog</span>
          <span aria-hidden="true">/</span>
          <span>{listing.area}</span>
          <span aria-hidden="true">/</span>
          <span className="font-mono text-slate-800">{listing.code}</span>
        </div>
      </div>

      {/* Demo Listing Warning Banner if applicable */}
      {listing.isDemo && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-slate-800">
          <strong>Pemberitahuan Contoh Listing:</strong> Unit dengan kode{' '}
          <span className="font-mono font-semibold">{listing.code}</span> ini ditandai sebagai{' '}
          <strong>“Contoh Listing”</strong> untuk keperluan demonstrasi portal BatamProperti.com dan bukan penawaran unit riil yang sedang dipasarkan.
        </div>
      )}

      {/* Main Contiguous Detail Split (Gallery Left + Sticky Action Module Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Photo Gallery, Description, Specifications, Facilities */}
        <div className="lg:col-span-8 space-y-8">
          {/* Main Gallery Viewport with Clean White Frame & Interactive Slider Controls */}
          <div className="bg-white p-3 rounded-3xl border border-stone-200/90 shadow-md space-y-3">
            <div className="relative aspect-[16/10] bg-stone-100 rounded-2xl overflow-hidden border border-stone-200/60 group">
              {!imgError ? (
                <img
                  src={currentPhoto}
                  alt={`${listing.title} — Foto ${activePhotoIdx + 1}`}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover transition-all duration-500"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-100 to-emerald-50 text-slate-700 p-8 text-center">
                  <Building2 className="w-12 h-12 text-emerald-600 mb-3" />
                  <p className="text-sm font-semibold">{listing.title}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    {listing.propertyType} · {listing.area}
                  </p>
                </div>
              )}

              {/* Interactive Prev / Next Gallery Slide Buttons */}
              {photos.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={handlePrevPhoto}
                    aria-label="Foto sebelumnya"
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-emerald-600 text-slate-900 hover:text-white flex items-center justify-center shadow-md transition-all"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    type="button"
                    onClick={handleNextPhoto}
                    aria-label="Foto berikutnya"
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-emerald-600 text-slate-900 hover:text-white flex items-center justify-center shadow-md transition-all"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              <div className="absolute bottom-3 left-3 bg-white/95 text-slate-800 px-3.5 py-1.5 rounded-xl text-xs font-medium shadow-xs border border-stone-200/80">
                <span className="text-emerald-700 font-bold">
                  {listing.transactionType}
                </span>
                <span aria-hidden="true" className="mx-1.5 text-stone-300">
                  ·
                </span>
                <span className="font-semibold">{listing.propertyType}</span>
                {listing.isDemo && (
                  <>
                    <span aria-hidden="true" className="mx-1.5 text-stone-300">
                      ·
                    </span>
                    <span className="text-slate-500">Contoh Listing</span>
                  </>
                )}
              </div>

              {photos.length > 1 && (
                <div className="absolute bottom-3 right-3 bg-white/95 text-slate-800 px-3 py-1.5 rounded-xl text-xs font-mono font-semibold tabular-nums shadow-xs border border-stone-200/80">
                  Foto {activePhotoIdx + 1} / {photos.length}
                </div>
              )}
            </div>

            {/* Thumbnail Selector */}
            {photos.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-1 px-1">
                {photos.map((photoUrl, idx) => (
                  <button
                    key={`${photoUrl}-${idx}`}
                    type="button"
                    onClick={() => {
                      setActivePhotoIdx(idx);
                      setImgError(false);
                    }}
                    aria-label={`Pilih foto ${idx + 1}`}
                    className={`relative w-24 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      activePhotoIdx === idx
                        ? 'border-emerald-600 ring-2 ring-emerald-500/30'
                        : 'border-stone-200 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={photoUrl}
                      alt={`Thumbnail ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Description Section */}
          <section className="bg-white border border-stone-200 rounded-3xl p-6 space-y-3 shadow-2xs">
            <h2 className="text-lg font-bold text-slate-900 font-serif">
              Deskripsi Properti
            </h2>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {listing.description}
            </p>
          </section>

          {/* Specifications Table (Strictly Non-Empty Fields Only) */}
          <section className="bg-white border border-stone-200 rounded-3xl p-6 space-y-4 shadow-2xs">
            <h2 className="text-lg font-bold text-slate-900 font-serif">
              Spesifikasi Lengkap
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm">
              {specRows.map((row) => (
                <div
                  key={row.label}
                  className="py-2 border-b border-stone-100 flex items-center justify-between gap-4"
                >
                  <span className="text-slate-500 text-xs">{row.label}</span>
                  <span className="font-semibold text-slate-900 text-right tabular-nums">
                    {row.value}
                  </span>
                </div>
              ))}
            </div>
          </section>

          {/* Facilities List (Only if non-empty) */}
          {listing.facilities && listing.facilities.length > 0 && (
            <section className="bg-white border border-stone-200 rounded-3xl p-6 space-y-4 shadow-2xs">
              <h2 className="text-lg font-bold text-slate-900 font-serif">
                Fasilitas & Keunggulan Lokasi
              </h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-sm text-slate-700">
                {listing.facilities.map((fac) => (
                  <li
                    key={fac}
                    className="py-2 px-3.5 bg-stone-50 border border-stone-200/80 rounded-xl text-xs font-medium text-slate-800"
                  >
                    {fac}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Optional Video Link */}
          {listing.videoUrl && listing.videoUrl.trim().length > 0 && (
            <section className="bg-white border border-stone-200 rounded-3xl p-6 space-y-2 shadow-2xs">
              <h2 className="text-base font-bold text-slate-900 font-serif">
                Video Properti
              </h2>
              <a
                href={listing.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block text-xs font-semibold text-emerald-700 underline"
              >
                Tonton Video Tur Properti ({listing.videoUrl})
              </a>
            </section>
          )}
        </div>

        {/* Right Column: Sticky Contiguous Consultation & Action Module */}
        <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-5">
          <div className="bg-white border border-stone-200 rounded-3xl p-6 space-y-5 shadow-md">
            <div className="space-y-2">
              <div className="flex items-center flex-wrap gap-1.5 text-xs text-slate-500">
                <span className="font-mono font-semibold text-emerald-800">
                  {listing.code}
                </span>
                <span aria-hidden="true">·</span>
                <span>{listing.area}</span>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-slate-800">{listing.status}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">
                  {(listing.viewsCount || 0) + (listing.waClicksCount || 0)}x dilihat
                </span>
              </div>

              <h1 className="text-xl font-bold text-slate-900 font-serif leading-snug">
                {listing.title}
              </h1>

              <div className="pt-2 border-t border-stone-100">
                <p className="text-xs text-slate-500">Harga Penawaran</p>
                <p className="text-2xl font-bold text-emerald-700 tabular-nums mt-0.5">
                  {formatRupiahRingkas(listing.price, listing.pricePeriod)}
                </p>
                <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                  ({formatRupiahLengkap(listing.price)}
                  {listing.pricePeriod ? ` / ${listing.pricePeriod}` : ''})
                </p>
              </div>
            </div>

            {/* Primary & Secondary Action Buttons — Direct WhatsApp Admin Routing + Favorite */}
            <div className="space-y-2.5 pt-2">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => recordListingInteraction(listing, 'wa_click')}
                className="flex items-center justify-center w-full py-3.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-sm"
              >
                Chat Admin via WhatsApp Sekarang
              </a>

              <button
                type="button"
                onClick={() => toggleFavorite(listing.id)}
                className={`w-full py-2.5 px-4 text-xs font-semibold rounded-xl border transition-colors flex items-center justify-center gap-2 ${
                  isFav
                    ? 'bg-rose-50 border-rose-300 text-rose-700'
                    : 'bg-white border-stone-300 text-slate-700 hover:bg-stone-50'
                }`}
              >
                <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                <span>{isFav ? 'Tersimpan di Favorit' : 'Simpan Favorit'}</span>
              </button>
            </div>

            {/* Admin Consultation Guidance Info */}
            <div className="pt-4 border-t border-stone-100 space-y-2 text-xs text-slate-600 leading-relaxed">
              <p className="font-semibold text-slate-900">
                Alur Konsultasi Admin {settings.companyName}:
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-600">
                <li>Chat Admin via WhatsApp & konfirmasi ketersediaan unit</li>
                <li>Kunjungan langsung di lokasi Batam</li>
                <li>Negosiasi harga & pengecekan dokumen asli</li>
                <li>Proses transaksi resmi melalui PPAT / Notaris</li>
              </ol>
              <p className="text-[11px] text-slate-500 pt-1">
                Konsultasi melalui WhatsApp tidak memungut biaya apa pun dan tidak mengikat transaksi.
              </p>
            </div>
          </div>
        </aside>
      </div>

      {/* Smart Recommendations Section based on user budget/preference + popular */}
      <SmartRecommendations
        excludeListingId={listing.id}
        onSelectListing={(nextSlug) => {
          navigate({ page: 'detail', slug: nextSlug });
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        limit={3}
        compactHeader
      />

      {/* Similar Properties Section */}
      {similarListings.length > 0 && (
        <section className="pt-8 border-t border-slate-200 space-y-6">
          <div>
            <p className="text-xs font-semibold text-amber-700">Rekomendasi Terkait</p>
            <h2 className="text-2xl font-bold text-slate-900 font-serif mt-0.5">
              Properti Serupa di Batam
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {similarListings.map((sim) => (
              <PropertyCard
                key={sim.id}
                listing={sim}
                onSelect={(nextSlug) => {
                  navigate({ page: 'detail', slug: nextSlug });
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
