import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus,
  Search,
  Edit3,
  Trash2,
  ArrowUp,
  ArrowDown,
  Star,
  Upload,
  LogOut,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { AdminPopularityAnalytics } from '../components/AdminPopularityAnalytics';
import {
  BATAM_AREAS,
  formatRupiahRingkas,
  generateSlug,
  PROPERTY_TYPES,
} from '../utils/propertyLogic';
import {
  ListingStatus,
  MarketCategory,
  PropertyListing,
  PropertyType,
  SiteSettings,
  TransactionType,
} from '../types/property';
import { uploadPropertyPhoto } from '../lib/firebase';
import { RoutePath } from '../components/Navbar';

interface AdminPageProps {
  navigate: (route: RoutePath) => void;
}

const LISTING_STATUSES: ListingStatus[] = [
  'Draft',
  'Menunggu Review',
  'Aktif',
  'Terjual',
  'Tersewa',
  'Diarsipkan',
];

export const AdminPage: React.FC<AdminPageProps> = ({ navigate }) => {
  const {
    listings,
    settings,
    isAdmin,
    firestoreConnected,
    firebaseProjectInfo,
    loginAdminGoogle,
    loginAdminWithToken,
    logoutAdmin,
    createListing,
    updateListing,
    deleteListing,
    clearDemoListings,
    restoreDemoListings,
    updateSiteSettings,
    updateSeoMeta,
  } = useProperty();

  // Login State
  const [setupTokenInput, setSetupTokenInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Admin Navigation Tab
  const [activeTab, setActiveTab] = useState<
    'ringkasan' | 'listing' | 'pengaturan' | 'integrasi'
  >('ringkasan');

  // Listing Management Filters
  const [searchListing, setSearchListing] = useState('');
  const [filterStatus, setFilterStatus] = useState<'Semua' | ListingStatus>('Semua');
  const [filterType, setFilterType] = useState<'Semua' | PropertyType>('Semua');
  const [filterMarketCategory, setFilterMarketCategory] = useState<
    'Semua' | MarketCategory
  >('Semua');

  // Listing Modal State (Add / Edit)
  const [showListingModal, setShowListingModal] = useState(false);
  const [editingListingId, setEditingListingId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [savingListing, setSavingListing] = useState(false);

  // Form Fields for Listing
  const [fCode, setFCode] = useState('');
  const [fTitle, setFTitle] = useState('');
  const [fSlug, setFSlug] = useState('');
  const [fPropertyType, setFPropertyType] = useState<PropertyType>('Rumah');
  const [fTransactionType, setFTransactionType] = useState<TransactionType>('Dijual');
  const [fMarketCategory, setFMarketCategory] = useState<MarketCategory>('Secondary');
  const [fPrice, setFPrice] = useState<number>(1_000_000_000);
  const [fPricePeriod, setFPricePeriod] = useState('');
  const [fArea, setFArea] = useState(BATAM_AREAS[0]);
  const [fComplexName, setFComplexName] = useState('');
  const [fAddress, setFAddress] = useState('');
  const [fLandArea, setFLandArea] = useState<number>(120);
  const [fBuildingArea, setFBuildingArea] = useState<number>(100);
  const [fDimensions, setFDimensions] = useState('');
  const [fBedrooms, setFBedrooms] = useState<number>(3);
  const [fBathrooms, setFBathrooms] = useState<number>(2);
  const [fFloors, setFFloors] = useState<number>(2);
  const [fFurnishStatus, setFFurnishStatus] = useState('Unfurnished');
  const [fFacilitiesText, setFFacilitiesText] = useState('');
  const [fDescription, setFDescription] = useState('');
  const [fPhotos, setFPhotos] = useState<string[]>(['/images/rumah-batam-center.svg']);
  const [fMainPhotoIndex, setFMainPhotoIndex] = useState<number>(0);
  const [fNewPhotoUrl, setFNewPhotoUrl] = useState('');
  const [fVideoUrl, setFVideoUrl] = useState('');
  const [fLegalStatus, setFLegalStatus] = useState('');
  const [fIsFeatured, setFIsFeatured] = useState<boolean>(false);
  const [fIsDemo, setFIsDemo] = useState<boolean>(false);
  const [fStatus, setFStatus] = useState<ListingStatus>('Aktif');
  const [fListedDate, setFListedDate] = useState<string>(
    new Date().toISOString().slice(0, 10)
  );

  // Settings Form State
  const [settingsForm, setSettingsForm] = useState<SiteSettings>(settings);

  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  useEffect(() => {
    updateSeoMeta(
      'Dashboard Admin — BatamProperti.com (PT Cuan Properti)',
      'Panel pengelolaan katalog properti Primary & Secondary, analitik properti populer, dan pengaturan situs BatamProperti.com.'
    );
  }, [updateSeoMeta]);

  // Summary Metrics
  const activeCount = useMemo(
    () => listings.filter((l) => l.status === 'Aktif').length,
    [listings]
  );
  const primaryCount = useMemo(
    () => listings.filter((l) => l.marketCategory === 'Primary').length,
    [listings]
  );
  const secondaryCount = useMemo(
    () => listings.filter((l) => (l.marketCategory || 'Secondary') === 'Secondary').length,
    [listings]
  );
  const demoCount = useMemo(
    () => listings.filter((l) => l.isDemo).length,
    [listings]
  );

  const filteredAdminListings = useMemo(() => {
    const q = searchListing.trim().toLowerCase();
    return listings.filter((item) => {
      if (filterStatus !== 'Semua' && item.status !== filterStatus) return false;
      if (filterType !== 'Semua' && item.propertyType !== filterType) return false;
      const itemCat = item.marketCategory || 'Secondary';
      if (filterMarketCategory !== 'Semua' && itemCat !== filterMarketCategory) {
        return false;
      }
      if (q) {
        const hay = `${item.code} ${item.title} ${item.area} ${item.complexName || ''} ${itemCat}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [listings, searchListing, filterStatus, filterType, filterMarketCategory]);

  // Open Modal for New Listing
  const openAddListingModal = () => {
    const nextCode = `BP-BTM-${String(listings.length + 1).padStart(3, '0')}`;
    setEditingListingId(null);
    setFormError(null);
    setFCode(nextCode);
    setFTitle('');
    setFSlug('');
    setFPropertyType('Rumah');
    setFTransactionType('Dijual');
    setFMarketCategory('Primary');
    setFPrice(1_250_000_000);
    setFPricePeriod('');
    setFArea('Batam Center');
    setFComplexName('');
    setFAddress('');
    setFLandArea(120);
    setFBuildingArea(100);
    setFDimensions('8 x 15 m');
    setFBedrooms(3);
    setFBathrooms(2);
    setFFloors(2);
    setFFurnishStatus('Unfurnished');
    setFFacilitiesText('Carport, Keamanan 24 Jam, Air SPAM Batam');
    setFDescription('');
    setFPhotos(['/images/rumah-batam-center.svg']);
    setFMainPhotoIndex(0);
    setFVideoUrl('');
    setFLegalStatus('');
    setFIsFeatured(false);
    setFIsDemo(false);
    setFStatus('Aktif');
    setFListedDate(new Date().toISOString().slice(0, 10));
    setShowListingModal(true);
  };

  // Open Modal for Editing Existing Listing (Preserving all old data!)
  const openEditListingModal = (item: PropertyListing) => {
    setEditingListingId(item.id);
    setFormError(null);
    setFCode(item.code);
    setFTitle(item.title);
    setFSlug(item.slug);
    setFPropertyType(item.propertyType);
    setFTransactionType(item.transactionType);
    setFMarketCategory(item.marketCategory || 'Secondary');
    setFPrice(item.price);
    setFPricePeriod(item.pricePeriod || '');
    setFArea(item.area);
    setFComplexName(item.complexName || '');
    setFAddress(item.address || '');
    setFLandArea(item.landArea);
    setFBuildingArea(item.buildingArea);
    setFDimensions(item.dimensions || '');
    setFBedrooms(item.bedrooms);
    setFBathrooms(item.bathrooms);
    setFFloors(item.floors);
    setFFurnishStatus(item.furnishStatus || '');
    setFFacilitiesText((item.facilities || []).join(', '));
    setFDescription(item.description);
    setFPhotos(
      item.photos && item.photos.length > 0
        ? [...item.photos]
        : ['/images/rumah-batam-center.svg']
    );
    setFMainPhotoIndex(item.mainPhotoIndex || 0);
    setFVideoUrl(item.videoUrl || '');
    setFLegalStatus(item.legalStatus || '');
    setFIsFeatured(item.isFeatured);
    setFIsDemo(item.isDemo);
    setFStatus(item.status);
    setFListedDate(item.listedDate || new Date().toISOString().slice(0, 10));
    setShowListingModal(true);
  };

  const handlePhotoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const added: string[] = [];
    for (let i = 0; i < Math.min(files.length, 5); i++) {
      const file = files[i];
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.readAsDataURL(file);
      });
      if (dataUrl) {
        const uploaded = await uploadPropertyPhoto(dataUrl, file.name);
        added.push(uploaded);
      }
    }
    setFPhotos((prev) => [...prev, ...added].slice(0, 15));
    e.target.value = '';
  };

  const movePhoto = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= fPhotos.length) return;
    const copy = [...fPhotos];
    const temp = copy[index];
    copy[index] = copy[target];
    copy[target] = temp;
    setFPhotos(copy);
    if (fMainPhotoIndex === index) setFMainPhotoIndex(target);
    else if (fMainPhotoIndex === target) setFMainPhotoIndex(index);
  };

  const removePhoto = (index: number) => {
    if (fPhotos.length <= 1) return;
    const next = fPhotos.filter((_, i) => i !== index);
    setFPhotos(next);
    if (fMainPhotoIndex >= next.length) {
      setFMainPhotoIndex(0);
    }
  };

  const handleSaveListing = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSavingListing(true);

    const facilities = fFacilitiesText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 20);

    const payload: Partial<PropertyListing> = {
      code: fCode.trim().toUpperCase(),
      title: fTitle.trim(),
      slug: fSlug.trim() ? fSlug.trim().toLowerCase() : generateSlug(fTitle, fCode),
      propertyType: fPropertyType,
      transactionType: fTransactionType,
      marketCategory: fMarketCategory,
      price: Number(fPrice),
      pricePeriod: fPricePeriod.trim(),
      area: fArea,
      complexName: fComplexName.trim(),
      address: fAddress.trim(),
      landArea: Number(fLandArea) || 0,
      buildingArea: Number(fBuildingArea) || 0,
      dimensions: fDimensions.trim(),
      bedrooms: Number(fBedrooms) || 0,
      bathrooms: Number(fBathrooms) || 0,
      floors: Number(fFloors) || 0,
      furnishStatus: fFurnishStatus.trim(),
      facilities,
      description: fDescription.trim(),
      photos: fPhotos.length > 0 ? fPhotos : ['/images/rumah-batam-center.svg'],
      mainPhotoIndex: fMainPhotoIndex,
      videoUrl: fVideoUrl.trim(),
      legalStatus: fLegalStatus.trim(),
      isFeatured: fIsFeatured,
      isDemo: fIsDemo,
      status: fStatus,
      listedDate: fListedDate,
    };

    const res = editingListingId
      ? await updateListing(editingListingId, payload)
      : await createListing(payload);

    setSavingListing(false);
    if (!res.ok) {
      setFormError(res.error || 'Gagal menyimpan listing.');
      return;
    }
    setShowListingModal(false);
  };

  const handleGoogleLogin = async () => {
    setLoginError(null);
    setLoginLoading(true);
    const res = await loginAdminGoogle();
    setLoginLoading(false);
    if (!res.ok) {
      setLoginError(res.error || 'Gagal login Google.');
    }
  };

  const handleTokenLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);
    const res = await loginAdminWithToken(setupTokenInput);
    setLoginLoading(false);
    if (!res.ok) {
      setLoginError(res.error || 'Token setup tidak sesuai.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSiteSettings(settingsForm);
  };

  // Separate Admin Login View if not authenticated
  if (!isAdmin) {
    return (
      <div className="max-w-[960px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Login Card */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <p className="text-xs font-semibold text-amber-700">
                Akses Terbatas · {settings.companyName}
              </p>
              <h1 className="text-2xl font-bold text-slate-900 font-serif mt-1">
                Login Administrator BatamProperti.com
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Halaman ini khusus untuk pengelola resmi. Pendaftaran terbuka untuk publik dinonaktifkan demi keamanan katalog.
              </p>
            </div>

            {loginError && (
              <div
                role="alert"
                className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700"
              >
                {loginError}
              </div>
            )}

            {/* Method 1: Firebase Google Authentication */}
            <div className="space-y-3">
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Opsi 1: Autentikasi Firebase Google (Direkomendasikan)
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Masuk menggunakan akun Google Administrator yang terdaftar pada sistem (<strong>properti988@gmail.com</strong> atau UID yang terdaftar di koleksi <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">/admins</code> Firestore).
              </p>
              <button
                type="button"
                disabled={loginLoading}
                onClick={handleGoogleLogin}
                className="w-full py-3 px-4 text-xs font-semibold text-white bg-[#0A192F] hover:bg-slate-800 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <span>Masuk dengan Google (Firebase Auth)</span>
              </button>
            </div>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-white px-3 text-xs text-slate-400">
                  ATAU INISIALISASI ADMIN PERTAMA
                </span>
              </div>
            </div>

            {/* Method 2: Server Environment Setup Token */}
            <form onSubmit={handleTokenLogin} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-setup-token"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Opsi 2: Token Setup Admin Server (`ADMIN_SETUP_TOKEN`)
                </label>
                <input
                  id="admin-setup-token"
                  type="password"
                  required
                  value={setupTokenInput}
                  onChange={(e) => setSetupTokenInput(e.target.value)}
                  placeholder="Masukkan nilai ADMIN_SETUP_TOKEN dari environment..."
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setSetupTokenInput('BATAM_PROPERTI_ADMIN_SETUP')}
                  className="text-xs font-semibold text-amber-700 hover:underline"
                >
                  Isi Token Pengujian Default (Lingkungan Preview)
                </button>

                <button
                  type="submit"
                  disabled={loginLoading}
                  className="px-5 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors"
                >
                  {loginLoading ? 'Memverifikasi...' : 'Masuk Dashboard Admin'}
                </button>
              </div>
            </form>
          </div>

          {/* Setup & Security Guide Box */}
          <div className="lg:col-span-5 bg-slate-900 text-slate-200 rounded-xl p-6 space-y-4 border border-slate-800">
            <h2 className="text-base font-bold text-white font-serif">
              Panduan Keamanan & Setup Admin Pertama
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Sesuai standar keamanan, aplikasi ini tidak menyediakan form registrasi admin terbuka dan tidak menanam password di kode frontend.
            </p>
            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed">
              <li>
                <strong>Firebase Authentication:</strong> Project Firebase{' '}
                <code className="font-mono text-[#FDE047]">
                  {firebaseProjectInfo.projectId}
                </code>{' '}
                telah terhubung. Masuk dengan akun Google{' '}
                <code className="font-mono text-[#FDE047]">properti988@gmail.com</code>.
              </li>
              <li>
                <strong>Token Setup Server-Side:</strong> Untuk pengujian atau inisialisasi pertama tanpa popup Google, server memverifikasi header terhadap variabel environment <code className="font-mono text-[#FDE047]">ADMIN_SETUP_TOKEN</code> di <code className="font-mono">server.ts</code>.
              </li>
              <li>
                <strong>Produksi:</strong> Ubah nilai <code className="font-mono">ADMIN_SETUP_TOKEN</code> dan <code className="font-mono">ADMIN_BOOTSTRAP_EMAIL</code> pada panel Secrets / Environment Variables server Anda.
              </li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Admin Workspace Header */}
      <div className="bg-[#0A192F] text-white rounded-xl p-6 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#D4AF37]">
            Portal Manajemen Internal · {settings.companyName}
          </p>
          <h1 className="text-2xl font-bold font-serif mt-0.5">
            Dashboard Admin {settings.siteName}
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Masuk sebagai: <span className="font-semibold text-white">Admin</span> · Status Firestore:{' '}
            <span className="text-emerald-400 font-semibold">
              {firestoreConnected ? 'Terhubung' : 'Mode Server Lokal'}
            </span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={openAddListingModal}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Listing Baru</span>
          </button>
          <button
            type="button"
            onClick={logoutAdmin}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
          >
            <LogOut className="w-4 h-4" />
            <span>Keluar</span>
          </button>
        </div>
      </div>

      {/* Admin Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-200/80 rounded-xl overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('ringkasan')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'ringkasan'
              ? 'bg-[#0A192F] text-white'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          Ringkasan & Data Demo
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('listing')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap tabular-nums ${
            activeTab === 'listing'
              ? 'bg-[#0A192F] text-white'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          Kelola Listing ({listings.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('pengaturan')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'pengaturan'
              ? 'bg-[#0A192F] text-white'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          Pengaturan Website & Unggulan
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('integrasi')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeTab === 'integrasi'
              ? 'bg-[#0A192F] text-white'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          Konfigurasi Firebase & Storage
        </button>
      </div>

      {/* TAB 1: RINGKASAN */}
      {activeTab === 'ringkasan' && (
        <div className="space-y-8">
          {/* 4 KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-1">
              <p className="text-xs font-semibold text-slate-500">Listing Aktif</p>
              <p className="text-3xl font-bold text-[#0A192F] font-mono tabular-nums">
                {activeCount}
              </p>
              <p className="text-xs text-slate-500">
                Tampil di katalog publik BatamProperti.com
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-1">
              <p className="text-xs font-semibold text-emerald-700">
                Properti Primary (Baru)
              </p>
              <p className="text-3xl font-bold text-emerald-700 font-mono tabular-nums">
                {primaryCount}
              </p>
              <p className="text-xs text-slate-500">
                Tampil di menu Properti Baru / Primary
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-1">
              <p className="text-xs font-semibold text-slate-500">
                Properti Secondary (Seken)
              </p>
              <p className="text-3xl font-bold text-[#0A192F] font-mono tabular-nums">
                {secondaryCount}
              </p>
              <p className="text-xs text-slate-500">
                Unit properti seken / pemilik
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-1">
              <p className="text-xs font-semibold text-amber-700">
                Properti Unggulan
              </p>
              <p className="text-3xl font-bold text-amber-700 font-mono tabular-nums">
                {listings.filter((l) => l.isFeatured).length}
              </p>
              <p className="text-xs text-slate-500">
                Ditampilkan di Slider Utama Beranda
              </p>
            </div>
          </div>

          {/* Demo Data Management Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-slate-900 font-serif">
                Pengelolaan Data Demonstrasi (“Contoh Listing”)
              </h2>
              <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
                Saat ini terdapat <strong className="tabular-nums">{demoCount}</strong> unit berlabel <strong>Contoh Listing</strong> di dalam database. Anda dapat menghapus seluruh data demonstrasi dengan satu klik ketika siap memasukkan properti asli PT Cuan Properti.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              {demoCount > 0 ? (
                <button
                  type="button"
                  onClick={clearDemoListings}
                  className="px-4 py-2.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap"
                >
                  Hapus Semua Contoh Listing ({demoCount})
                </button>
              ) : (
                <button
                  type="button"
                  onClick={restoreDemoListings}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap"
                >
                  Pulihkan Contoh Listing Demonstrasi
                </button>
              )}
              <button
                type="button"
                onClick={openAddListingModal}
                className="px-4 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors whitespace-nowrap"
              >
                + Masukkan Listing Asli
              </button>
            </div>
          </div>

          {/* Direct WhatsApp Info Banner */}
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-emerald-950 font-serif">
                Alur Titip Listing & Konsultasi Langsung ke WhatsApp Admin
              </h3>
              <p className="text-xs text-slate-600">
                Seluruh pengajuan Titipkan Properti dan konsultasi pengunjung langsung diarahkan ke chat WhatsApp Admin (<strong>+{settings.whatsappNumber.replace(/^\+/, "")}</strong>).
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab("pengaturan")}
              className="px-4 py-2 text-xs font-semibold text-emerald-900 bg-white border border-emerald-300 hover:bg-emerald-100 rounded-lg whitespace-nowrap shrink-0"
            >
              Atur Nomor WhatsApp
            </button>
          </div>

          <AdminPopularityAnalytics
            listings={listings}
            onViewListing={(slug) => navigate({ page: "detail", slug })}
          />
        </div>
      )}

      {/* TAB 2: KELOLA LISTING */}
      {activeTab === 'listing' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 font-serif">
                Manajemen Katalog Listing Properti (Primary & Secondary)
              </h2>
              <p className="text-xs text-slate-500">
                Pilih kategori <strong>Primary</strong> agar unit tampil di menu <strong>Properti Baru (Primary)</strong>, atau <strong>Secondary</strong> untuk properti seken/pemilik.
              </p>
            </div>
            <button
              type="button"
              onClick={openAddListingModal}
              className="px-4 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg whitespace-nowrap"
            >
              + Tambah Listing Properti
            </button>
          </div>

          {/* Search & Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchListing}
                onChange={(e) => setSearchListing(e.target.value)}
                placeholder="Cari kode listing, judul, atau lokasi..."
                aria-label="Cari listing di tabel admin"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>

            <select
              value={filterMarketCategory}
              onChange={(e) =>
                setFilterMarketCategory(e.target.value as 'Semua' | MarketCategory)
              }
              aria-label="Filter kategori Primary atau Secondary"
              className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Semua Kategori (Primary & Secondary)</option>
              <option value="Primary">Kategori: Primary (Properti Baru)</option>
              <option value="Secondary">Kategori: Secondary (Properti Seken)</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) =>
                setFilterStatus(e.target.value as 'Semua' | ListingStatus)
              }
              aria-label="Filter status listing"
              className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Semua Status Publikasi</option>
              {LISTING_STATUSES.map((st) => (
                <option key={st} value={st}>
                  Status: {st}
                </option>
              ))}
            </select>

            <select
              value={filterType}
              onChange={(e) =>
                setFilterType(e.target.value as 'Semua' | PropertyType)
              }
              aria-label="Filter jenis properti"
              className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="Semua">Semua Jenis Properti</option>
              {PROPERTY_TYPES.map((tp) => (
                <option key={tp} value={tp}>
                  {tp}
                </option>
              ))}
            </select>
          </div>

          {/* Listings Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-3 px-3 font-semibold">Kode & Judul</th>
                  <th className="py-3 px-3 font-semibold">Area & Jenis</th>
                  <th className="py-3 px-3 font-semibold">Primary / Secondary</th>
                  <th className="py-3 px-3 font-semibold">Harga</th>
                  <th className="py-3 px-3 font-semibold">Statistik Klik</th>
                  <th className="py-3 px-3 font-semibold">Status Publikasi</th>
                  <th className="py-3 px-3 font-semibold">Unggulan</th>
                  <th className="py-3 px-3 font-semibold text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAdminListings.map((item) => {
                  const currentCategory: MarketCategory =
                    item.marketCategory === 'Primary' ? 'Primary' : 'Secondary';
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80">
                      <td className="py-3.5 px-3 max-w-xs">
                        <div className="font-mono font-bold text-slate-900">
                          {item.code}
                          {item.isDemo && (
                            <span className="ml-2 font-sans font-normal text-amber-700">
                              · Contoh Listing
                            </span>
                          )}
                        </div>
                        <div className="font-medium text-slate-800 line-clamp-1 mt-0.5">
                          {item.title}
                        </div>
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <div className="font-semibold text-slate-900">{item.area}</div>
                        <div className="text-slate-500">
                          {item.propertyType} · {item.transactionType}
                        </div>
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <select
                          value={currentCategory}
                          aria-label={`Ubah kategori Primary/Secondary untuk ${item.code}`}
                          onChange={(e) =>
                            updateListing(item.id, {
                              marketCategory: e.target.value as MarketCategory,
                            })
                          }
                          className={`px-2.5 py-1.5 text-xs font-semibold border rounded-md ${
                            currentCategory === 'Primary'
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                              : 'bg-slate-50 border-slate-300 text-slate-700'
                          }`}
                        >
                          <option value="Primary">Primary (Properti Baru)</option>
                          <option value="Secondary">Secondary (Seken)</option>
                        </select>
                      </td>
                      <td className="py-3.5 px-3 font-mono font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                        {formatRupiahRingkas(item.price, item.pricePeriod)}
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <div className="font-mono font-semibold text-slate-900 tabular-nums">
                          {(item.viewsCount || 0) + (item.waClicksCount || 0)} total klik
                        </div>
                        <div className="text-[11px] text-slate-500 tabular-nums">
                          {item.viewsCount || 0} dilihat · {item.waClicksCount || 0} WA
                        </div>
                      </td>
                      <td className="py-3.5 px-3">
                        <select
                          value={item.status}
                          aria-label={`Ubah status ${item.code}`}
                          onChange={(e) =>
                            updateListing(item.id, {
                              status: e.target.value as ListingStatus,
                            })
                          }
                          className="px-2.5 py-1.5 text-xs font-semibold border border-slate-300 rounded-md bg-white"
                        >
                          {LISTING_STATUSES.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3.5 px-3">
                        <button
                          type="button"
                          onClick={() =>
                            updateListing(item.id, { isFeatured: !item.isFeatured })
                          }
                          aria-label={`Tandai unggulan ${item.code}`}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold ${
                            item.isFeatured
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          <Star
                            className={`w-3.5 h-3.5 ${
                              item.isFeatured ? 'fill-amber-600 text-amber-600' : ''
                            }`}
                          />
                          <span>{item.isFeatured ? 'Unggulan' : 'Biasa'}</span>
                        </button>
                      </td>
                      <td className="py-3.5 px-3 text-right whitespace-nowrap space-x-1.5">
                        <button
                          type="button"
                          onClick={() => navigate({ page: 'detail', slug: item.slug })}
                          title="Lihat Halaman Detail"
                          className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 rounded-md inline-flex items-center"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditListingModal(item)}
                          className="px-2.5 py-1.5 text-xs font-semibold text-white bg-[#0A192F] hover:bg-slate-800 rounded-md inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteListing(item.id)}
                          aria-label={`Hapus ${item.code}`}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-md inline-flex items-center"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: PENGATURAN WEBSITE */}
      {activeTab === 'pengaturan' && (
        <form
          onSubmit={handleSaveSettings}
          className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6"
        >
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 font-serif">
              Pengaturan Identitas, Kontak, Beranda & SEO Website
            </h2>
            <p className="text-xs text-slate-500">
              Perubahan yang disimpan akan langsung diterapkan pada Header, Beranda, Halaman Kontak, tombol WhatsApp, dan metadata SEO.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Website / Portal
              </label>
              <input
                type="text"
                value={settingsForm.siteName}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, siteName: e.target.value })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Perusahaan Pengelola
              </label>
              <input
                type="text"
                value={settingsForm.companyName}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    companyName: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Teks Logo Header
              </label>
              <input
                type="text"
                value={settingsForm.logoText}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, logoText: e.target.value })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nomor WhatsApp Utama Admin (Format 628... atau 08...)
              </label>
              <input
                type="text"
                value={settingsForm.whatsappNumber}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    whatsappNumber: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Resmi Perusahaan
              </label>
              <input
                type="email"
                value={settingsForm.email}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, email: e.target.value })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Judul Hero Utama Beranda
              </label>
              <input
                type="text"
                value={settingsForm.heroTitle}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, heroTitle: e.target.value })
                }
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Alamat Kantor di Batam
            </label>
            <input
              type="text"
              value={settingsForm.officeAddress}
              onChange={(e) =>
                setSettingsForm({
                  ...settingsForm,
                  officeAddress: e.target.value,
                })
              }
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Subjudul Hero Beranda
            </label>
            <textarea
              rows={2}
              value={settingsForm.heroSubtitle}
              onChange={(e) =>
                setSettingsForm({
                  ...settingsForm,
                  heroSubtitle: e.target.value,
                })
              }
              className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                URL Instagram
              </label>
              <input
                type="text"
                value={settingsForm.instagramUrl}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    instagramUrl: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                URL Facebook
              </label>
              <input
                type="text"
                value={settingsForm.facebookUrl}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    facebookUrl: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Judul SEO Default (`&lt;title&gt;`)
              </label>
              <input
                type="text"
                value={settingsForm.seoTitle}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, seoTitle: e.target.value })
                }
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Deskripsi Meta SEO Default
              </label>
              <input
                type="text"
                value={settingsForm.seoDescription}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    seoDescription: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors"
            >
              Simpan Pengaturan Website
            </button>
          </div>
        </form>
      )}

      {/* TAB 5: KONFIGURASI FIREBASE & STORAGE */}
      {activeTab === 'integrasi' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 font-serif">
              Status Integrasi Firebase Authentication, Cloud Firestore & Storage
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Ringkasan koneksi cloud dan langkah konfigurasi lanjutan untuk operasional produksi PT Cuan Properti.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">
                  Firebase Project ID
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="font-mono text-xs text-slate-700">
                {firebaseProjectInfo.projectId}
              </p>
              <p className="text-[11px] text-slate-500">
                Terkonfigurasi di firebase-applet-config.json
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">
                  Cloud Firestore Database
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="font-mono text-xs text-slate-700 truncate">
                {firebaseProjectInfo.firestoreDatabaseId}
              </p>
              <p className="text-[11px] text-slate-500">
                Security Rules (`firestore.rules`) aktif & ter-deploy
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">
                  Firebase Storage Bucket
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="font-mono text-xs text-slate-700 truncate">
                {firebaseProjectInfo.storageBucket}
              </p>
              <p className="text-[11px] text-slate-500">
                Unggah foto otomatis fallback ke Data URL jika bucket belum dibuka
              </p>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 text-slate-200 space-y-3 text-xs leading-relaxed">
            <h3 className="text-sm font-bold text-white">
              Langkah Konfigurasi Produksi yang Dapat Anda Sesuaikan:
            </h3>
            <ol className="list-decimal list-inside space-y-2">
              <li>
                <strong>Nomor WhatsApp & Alamat Kantor Asli:</strong> Buka tab <em>Pengaturan Website</em> di atas, lalu ganti nomor WhatsApp utama, email, alamat kantor Batam, dan tautan media sosial resmi PT Cuan Properti.
              </li>
              <li>
                <strong>Menghapus Contoh Listing:</strong> Buka tab <em>Ringkasan & Data Demo</em> lalu klik tombol <strong>“Hapus Semua Contoh Listing”</strong> sebelum meluncurkan website ke publik.
              </li>
              <li>
                <strong>Menambahkan Admin Baru di Firestore:</strong> Masuk dengan akun utama <code className="font-mono text-[#FDE047]">properti988@gmail.com</code>, atau tambahkan dokumen UID admin baru pada koleksi <code className="font-mono text-[#FDE047]">/admins/&#123;uid&#125;</code> di Firebase Console.
              </li>
              <li>
                <strong>Environment Variables Server:</strong> Di pengaturan Secrets/Environment server produksi, tetapkan nilai rahasia unik untuk <code className="font-mono text-[#FDE047]">ADMIN_SETUP_TOKEN</code>.
              </li>
            </ol>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT LISTING */}
      {showListingModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="listing-modal-title"
        >
          <div className="bg-white rounded-xl max-w-3xl w-full border border-slate-200 overflow-hidden my-8">
            <div className="px-6 py-4 bg-[#0A192F] text-white flex items-center justify-between">
              <h2 id="listing-modal-title" className="text-base font-bold font-serif">
                {editingListingId
                  ? `Edit Listing Properti (${fCode})`
                  : 'Tambah Listing Properti Baru'}
              </h2>
              <button
                type="button"
                onClick={() => setShowListingModal(false)}
                className="text-xs font-semibold text-slate-300 hover:text-white"
              >
                Tutup [X]
              </button>
            </div>

            <form
              onSubmit={handleSaveListing}
              className="p-6 space-y-5 max-h-[80vh] overflow-y-auto"
            >
              {formError && (
                <div
                  role="alert"
                  className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700"
                >
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kode Listing Unik *
                  </label>
                  <input
                    type="text"
                    required
                    value={fCode}
                    onChange={(e) => setFCode(e.target.value)}
                    placeholder="BP-BTM-010"
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label
                    htmlFor="admin-market-category"
                    className="block text-xs font-semibold text-emerald-800 mb-1"
                  >
                    Kategori Pasar (Primary / Secondary) *
                  </label>
                  <select
                    id="admin-market-category"
                    value={fMarketCategory}
                    onChange={(e) =>
                      setFMarketCategory(e.target.value as MarketCategory)
                    }
                    className="w-full px-3 py-2 text-xs font-semibold border border-emerald-400 rounded-lg bg-emerald-50/60 text-slate-900"
                  >
                    <option value="Primary">
                      Primary — Properti Baru / Developer (Tampil di Menu Properti Baru)
                    </option>
                    <option value="Secondary">
                      Secondary — Properti Seken / Pemilik
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Publikasi *
                  </label>
                  <select
                    value={fStatus}
                    onChange={(e) => setFStatus(e.target.value as ListingStatus)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {LISTING_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Judul Listing *
                  </label>
                  <input
                    type="text"
                    required
                    value={fTitle}
                    onChange={(e) => setFTitle(e.target.value)}
                    placeholder="Contoh: Rumah 2 Lantai Cluster Modern di Batam Center"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Slug URL (Otomatis jika dikosongkan)
                  </label>
                  <input
                    type="text"
                    value={fSlug}
                    onChange={(e) => setFSlug(e.target.value)}
                    placeholder="rumah-2-lantai-batam-center-bp-btm-010"
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Jenis Properti *
                  </label>
                  <select
                    value={fPropertyType}
                    onChange={(e) =>
                      setFPropertyType(e.target.value as PropertyType)
                    }
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {PROPERTY_TYPES.map((tp) => (
                      <option key={tp} value={tp}>
                        {tp}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Jual / Sewa *
                  </label>
                  <select
                    value={fTransactionType}
                    onChange={(e) =>
                      setFTransactionType(e.target.value as TransactionType)
                    }
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Dijual">Dijual</option>
                    <option value="Disewakan">Disewakan</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Harga (Rupiah) *
                  </label>
                  <input
                    type="number"
                    required
                    min={100000}
                    value={fPrice}
                    onChange={(e) => setFPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Periode Sewa (Opsional)
                  </label>
                  <input
                    type="text"
                    value={fPricePeriod}
                    onChange={(e) => setFPricePeriod(e.target.value)}
                    placeholder="Kosongkan atau isi: tahun / bulan"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Area / Kecamatan di Batam *
                  </label>
                  <select
                    value={fArea}
                    onChange={(e) => setFArea(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {BATAM_AREAS.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Perumahan / Gedung
                  </label>
                  <input
                    type="text"
                    value={fComplexName}
                    onChange={(e) => setFComplexName(e.target.value)}
                    placeholder="Cluster Sukajadi / Nagoya Citywalk"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Alamat / Lokasi Umum
                  </label>
                  <input
                    type="text"
                    value={fAddress}
                    onChange={(e) => setFAddress(e.target.value)}
                    placeholder="Jl. Engku Putri, Batam Center"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Luas Tanah (m²)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fLandArea}
                    onChange={(e) => setFLandArea(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Luas Bangunan (m²)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fBuildingArea}
                    onChange={(e) => setFBuildingArea(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Dimensi
                  </label>
                  <input
                    type="text"
                    value={fDimensions}
                    onChange={(e) => setFDimensions(e.target.value)}
                    placeholder="10 x 18 m"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kamar Tidur
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fBedrooms}
                    onChange={(e) => setFBedrooms(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kamar Mandi
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fBathrooms}
                    onChange={(e) => setFBathrooms(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Jumlah Lantai
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fFloors}
                    onChange={(e) => setFFloors(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kondisi / Furnish
                  </label>
                  <input
                    type="text"
                    value={fFurnishStatus}
                    onChange={(e) => setFFurnishStatus(e.target.value)}
                    placeholder="Unfurnished / Semi / Full Furnished"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Legalitas (Opsional — Hanya tampil jika diisi)
                  </label>
                  <input
                    type="text"
                    value={fLegalStatus}
                    onChange={(e) => setFLegalStatus(e.target.value)}
                    placeholder="Kosongkan jika belum diverifikasi (Contoh: SHGB & UWTO)"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    URL Video (Opsional)
                  </label>
                  <input
                    type="text"
                    value={fVideoUrl}
                    onChange={(e) => setFVideoUrl(e.target.value)}
                    placeholder="https://youtube.com/..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Fasilitas (Pisahkan dengan koma)
                </label>
                <input
                  type="text"
                  value={fFacilitiesText}
                  onChange={(e) => setFFacilitiesText(e.target.value)}
                  placeholder="Keamanan 24 Jam, Carport 2 Mobil, Kolam Renang, Air SPAM Batam"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Deskripsi Lengkap Properti *
                </label>
                <textarea
                  rows={3}
                  required
                  value={fDescription}
                  onChange={(e) => setFDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                />
              </div>

              {/* Multi-Photo Upload, Reorder, Main Photo Selection & Delete */}
              <div className="space-y-3 p-4 rounded-xl bg-slate-50 border border-slate-200">
                <label className="block text-xs font-bold text-slate-800">
                  Galeri Foto Properti (Pilih Foto Utama, Ubah Urutan, atau Hapus)
                </label>

                <div className="flex flex-wrap items-center gap-2">
                  <label className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0A192F] bg-white border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-100">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Unggah File Foto</span>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handlePhotoFileUpload}
                      className="hidden"
                    />
                  </label>

                  <input
                    type="text"
                    value={fNewPhotoUrl}
                    onChange={(e) => setFNewPhotoUrl(e.target.value)}
                    placeholder="Atau masukkan URL foto (/images/ruko-nagoya.svg)..."
                    className="flex-1 min-w-[200px] px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (fNewPhotoUrl.trim()) {
                        setFPhotos((prev) =>
                          [...prev, fNewPhotoUrl.trim()].slice(0, 15)
                        );
                        setFNewPhotoUrl('');
                      }
                    }}
                    className="px-3 py-2 text-xs font-semibold text-white bg-[#0A192F] rounded-lg"
                  >
                    + Tambah Foto
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  {fPhotos.map((url, idx) => (
                    <div
                      key={`${url}-${idx}`}
                      className={`p-2 rounded-lg border bg-white space-y-2 ${
                        fMainPhotoIndex === idx
                          ? 'border-[#0A192F] ring-2 ring-[#D4AF37]'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="aspect-[4/3] rounded overflow-hidden bg-slate-100">
                        <img
                          src={url}
                          alt={`Foto ${idx + 1}`}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex items-center justify-between gap-1">
                        <button
                          type="button"
                          onClick={() => setFMainPhotoIndex(idx)}
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            fMainPhotoIndex === idx
                              ? 'bg-[#D4AF37] text-[#0A192F]'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {fMainPhotoIndex === idx ? 'Foto Utama' : 'Jadikan Utama'}
                        </button>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => movePhoto(idx, -1)}
                            disabled={idx === 0}
                            aria-label="Geser foto ke kiri"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30"
                          >
                            <ArrowUp className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => movePhoto(idx, 1)}
                            disabled={idx === fPhotos.length - 1}
                            aria-label="Geser foto ke kanan"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30"
                          >
                            <ArrowDown className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removePhoto(idx)}
                            disabled={fPhotos.length <= 1}
                            aria-label="Hapus foto"
                            className="p-1 text-red-600 hover:text-red-800 disabled:opacity-30"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Checkboxes */}
              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={fIsFeatured}
                    onChange={(e) => setFIsFeatured(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  <span>Tandai sebagai Properti Unggulan (Tampil di Beranda)</span>
                </label>

                <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={fIsDemo}
                    onChange={(e) => setFIsDemo(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  <span>Tandai sebagai “Contoh Listing” (Data Demonstrasi)</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowListingModal(false)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingListing}
                  className="px-6 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg"
                >
                  {savingListing
                    ? 'Menyimpan...'
                    : editingListingId
                    ? 'Simpan Perubahan Listing'
                    : 'Publikasikan / Simpan Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
