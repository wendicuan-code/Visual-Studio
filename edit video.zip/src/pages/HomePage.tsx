import React, { useCallback, useEffect, useMemo, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import {
  Search,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  MoveHorizontal,
  Sparkles,
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import {
  BATAM_AREAS,
  buildListingWhatsAppMessage,
  buildWhatsAppUrl,
  formatRupiahRingkas,
  mapPriceRangeToBounds,
  PRICE_RANGE_OPTIONS,
  PROPERTY_TYPES,
} from '../utils/propertyLogic';
import { PropertyCard } from '../components/PropertyCard';
import { SmartRecommendations } from '../components/SmartRecommendations';
import { RoutePath } from '../components/Navbar';
import {
  FilterState,
  PropertyListing,
  PropertyType,
  TransactionType,
} from '../types/property';

interface HomePageProps {
  navigate: (route: RoutePath) => void;
  onApplyQuickSearch: (partial: Partial<FilterState>) => void;
  onAskSurvey?: (listing: PropertyListing) => void;
}

interface HeroCarouselSlide {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  area: string;
  propertyType: string;
  transactionType: TransactionType;
  price: number;
  pricePeriod?: string;
  priceLabel: string;
  specsLabel: string;
  image: string;
  gallery: string[];
  slug: string;
  isDemo?: boolean;
}

const FALLBACK_HERO_SLIDES: HeroCarouselSlide[] = [
  {
    id: 'fallback-btm-001',
    code: 'BP-BTM-001',
    title: 'Rumah 2 Lantai Modern Tropis di Kawasan Batam Center',
    subtitle:
      'Hunian modern tropis dekat Pelabuhan Feri Internasional Batam Center, Mega Mall, dan pusat pemerintahan Kota Batam.',
    area: 'Batam Center',
    propertyType: 'Rumah',
    transactionType: 'Dijual',
    price: 1_980_000_000,
    priceLabel: 'Rp 1,98 miliar',
    specsLabel: 'LT 180 m² · LB 210 m² · 4 KT · 3 KM',
    image: '/images/rumah-batam-center.svg',
    gallery: [
      '/images/rumah-batam-center.svg',
      '/images/rumah-pasir-putih.svg',
      '/images/apartemen-harbour.svg',
    ],
    slug: 'rumah-2-lantai-modern-tropis-di-kawasan-batam-center-bp-btm-001',
    isDemo: true,
  },
  {
    id: 'fallback-btm-002',
    code: 'BP-BTM-002',
    title: 'Ruko Komersial 3 Lantai Hadap Jalan Utama di Nagoya',
    subtitle:
      'Unit ruko komersial strategis di koridor niaga utama Nagoya Batam dengan trafik pengunjung tinggi.',
    area: 'Nagoya',
    propertyType: 'Ruko',
    transactionType: 'Dijual',
    price: 3_450_000_000,
    priceLabel: 'Rp 3,45 miliar',
    specsLabel: 'LT 90 m² · LB 240 m² · 3 Lantai',
    image: '/images/ruko-nagoya.svg',
    gallery: [
      '/images/ruko-nagoya.svg',
      '/images/rumah-batam-center.svg',
      '/images/apartemen-harbour.svg',
    ],
    slug: 'ruko-komersial-3-lantai-hadap-jalan-utama-di-nagoya-bp-btm-002',
    isDemo: true,
  },
];

export const HomePage: React.FC<HomePageProps> = ({
  navigate,
  onApplyQuickSearch,
}) => {
  const {
    publicListings,
    settings,
    updateSeoMeta,
    recordUserSearchIntent,
  } = useProperty();

  // Build Hero Carousel slides dynamically from featured listings
  const heroSlides: HeroCarouselSlide[] = useMemo(() => {
    const featured = publicListings.filter((item) => item.isFeatured);
    const source = featured.length > 0 ? featured : publicListings.slice(0, 5);
    if (source.length === 0) return FALLBACK_HERO_SLIDES;

    return source.map((item) => {
      const specsParts: string[] = [];
      if (item.landArea > 0) specsParts.push(`LT ${item.landArea} m²`);
      if (item.buildingArea > 0) specsParts.push(`LB ${item.buildingArea} m²`);
      if (item.bedrooms > 0) specsParts.push(`${item.bedrooms} KT`);
      if (item.bathrooms > 0) specsParts.push(`${item.bathrooms} KM`);
      if (item.floors > 0 && specsParts.length < 3) {
        specsParts.push(`${item.floors} Lantai`);
      }

      const photos =
        item.photos && item.photos.length > 0
          ? item.photos
          : ['/images/rumah-batam-center.svg'];
      const mainImg = photos[item.mainPhotoIndex || 0] || photos[0];

      return {
        id: item.id,
        code: item.code,
        title: item.title,
        subtitle: item.description.replace(/^\[CONTOH LISTING DEMONSTRASI\]\s*/i, ''),
        area: item.area,
        propertyType: item.propertyType,
        transactionType: item.transactionType,
        price: item.price,
        pricePeriod: item.pricePeriod,
        priceLabel: formatRupiahRingkas(item.price, item.pricePeriod),
        specsLabel: specsParts.join(' · ') || `${item.propertyType} di ${item.area}`,
        image: mainImg,
        gallery: photos,
        slug: item.slug,
        isDemo: item.isDemo,
      };
    });
  }, [publicListings]);

  // Embla Carousel with swipe gesture support + Autoplay plugin
  const [emblaRef, emblaApi] = useEmblaCarousel(
    {
      loop: true,
      align: 'center',
      dragFree: false,
      skipSnaps: false,
    },
    [
      Autoplay({
        delay: 5500,
        stopOnInteraction: false,
        stopOnMouseEnter: true,
      }),
    ]
  );

  const [selectedIndex, setSelectedIndex] = useState(0);

  const onSelectSlide = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelectSlide();
    emblaApi.on('select', onSelectSlide);
    emblaApi.on('reInit', onSelectSlide);
    return () => {
      emblaApi.off('select', onSelectSlide);
      emblaApi.off('reInit', onSelectSlide);
    };
  }, [emblaApi, onSelectSlide]);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  const scrollTo = useCallback(
    (index: number) => {
      if (emblaApi) emblaApi.scrollTo(index);
    },
    [emblaApi]
  );

  // Compact Quick Search State (Keyword, Area, Jenis Properti, Status, Harga)
  const [keyword, setKeyword] = useState('');
  const [area, setArea] = useState('Semua');
  const [propertyType, setPropertyType] = useState<'Semua' | PropertyType>('Semua');
  const [transactionType, setTransactionType] = useState<'Semua' | TransactionType>('Semua');
  const [priceRange, setPriceRange] = useState('all');

  useEffect(() => {
    updateSeoMeta(
      settings.seoTitle || 'BatamProperti.com — Portal Jual, Sewa & Pemasaran Properti Batam',
      settings.seoDescription ||
        'Temukan rumah, ruko, apartemen, tanah kavling, dan properti komersial di Batam bersama PT Cuan Properti.'
    );
  }, [settings.seoDescription, settings.seoTitle, updateSeoMeta]);

  const handlePriceRangeChange = (nextRange: string) => {
    setPriceRange(nextRange);
    const bounds = mapPriceRangeToBounds(nextRange);
    recordUserSearchIntent({
      minPrice: bounds.minPrice,
      maxPrice: bounds.maxPrice,
      targetPrice: bounds.targetPrice,
      priceRangeLabel: bounds.priceRangeLabel,
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const bounds = mapPriceRangeToBounds(priceRange);

    recordUserSearchIntent({
      keyword,
      area,
      propertyType,
      transactionType,
      minPrice: bounds.minPrice,
      maxPrice: bounds.maxPrice,
      targetPrice: bounds.targetPrice,
      priceRangeLabel: bounds.priceRangeLabel,
    });

    onApplyQuickSearch({
      keyword,
      area,
      propertyType,
      transactionType,
      minPrice: bounds.minPrice,
      maxPrice: bounds.maxPrice,
    });
    navigate({ page: 'catalog' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const featuredListings = publicListings.filter((item) => item.isFeatured);

  const latestListings = [...publicListings]
    .sort(
      (a, b) =>
        new Date(b.listedDate || b.createdAt).getTime() -
        new Date(a.listedDate || a.createdAt).getTime()
    )
    .slice(0, 6);

  const areaShowcase = [
    {
      name: 'Batam Center',
      tagline: 'Pusat Pemerintahan, Feri Internasional & Cluster Modern',
      image: '/images/rumah-batam-center.svg',
    },
    {
      name: 'Pasir Putih',
      tagline: 'Kawasan Residensial Favorit, Kuliner & Apartemen Sea-View',
      image: '/images/apartemen-harbour.svg',
    },
    {
      name: 'Nagoya',
      tagline: 'Distrik Bisnis Utama, Ruko Niaga & Pusat Perbelanjaan',
      image: '/images/ruko-nagoya.svg',
    },
    {
      name: 'Bengkong',
      tagline: 'Hunian Strategis & Kos-kosan Produktif Dekat Pusat Kota',
      image: '/images/kos-bengkong.svg',
    },
    {
      name: 'Sekupang',
      tagline: 'Kavling Siap Bangun, Kawasan Hijau & Pelabuhan Domestik',
      image: '/images/tanah-sekupang.svg',
    },
    {
      name: 'Tiban',
      tagline: 'Perumahan Keluarga Berkembang dengan Akses Mudah',
      image: '/images/rumah-pasir-putih.svg',
    },
  ].map((item) => ({
    ...item,
    count: publicListings.filter(
      (l) => l.area.toLowerCase() === item.name.toLowerCase()
    ).length,
  }));

  const generalWaUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Halo Admin ${settings.siteName} (${settings.companyName}), saya ingin berkonsultasi mengenai pencarian atau pemasaran properti di Batam.`
  );

  const hasDemoData = publicListings.some((l) => l.isDemo);

  return (
    <div className="space-y-16 pb-24">
      {/* 1. SATU SLIDER UTAMA (EMBLA SWIPE CAROUSEL) + KOLOM PENCARIAN SINGKAT DI BAWAHNYA */}
      <section className="relative bg-gradient-to-b from-emerald-50/50 via-stone-50 to-white border-b border-stone-200/80 overflow-hidden">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6 lg:px-8 pt-7 pb-10 relative z-10 space-y-6">
          {/* Header Kicker & Navigasi Slider Tunggal */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{settings.heroTitle || 'Temukan Properti yang Tepat di Batam'}</span>
              <span aria-hidden="true" className="text-stone-300">
                ·
              </span>
              <span className="text-slate-500 font-normal inline-flex items-center gap-1">
                <MoveHorizontal className="w-3.5 h-3.5 text-emerald-600" />
                <span>Geser (Swipe) untuk melihat properti unggulan</span>
              </span>
            </div>

            {/* Navigasi Tunggal Slider (Dots + Prev/Next) */}
            <div className="flex items-center gap-3 self-end sm:self-auto">
              <div className="flex items-center gap-1.5">
                {heroSlides.map((slide, idx) => (
                  <button
                    key={slide.id}
                    type="button"
                    onClick={() => scrollTo(idx)}
                    aria-label={`Pilih slide ${idx + 1}: ${slide.title}`}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      idx === selectedIndex
                        ? 'w-7 bg-emerald-600'
                        : 'w-2 bg-stone-300 hover:bg-stone-400'
                    }`}
                  />
                ))}
                <span className="ml-1.5 font-mono text-xs text-slate-500 tabular-nums">
                  0{selectedIndex + 1}/0{heroSlides.length}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={scrollPrev}
                  aria-label="Slide sebelumnya"
                  className="w-9 h-9 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-slate-800 flex items-center justify-center transition-colors shadow-2xs"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={scrollNext}
                  aria-label="Slide berikutnya"
                  className="w-9 h-9 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-slate-800 flex items-center justify-center transition-colors shadow-2xs"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 1 SLIDER TUNGGAL: Embla Viewport dengan Swipe Gesture */}
          <div className="bg-white p-3 sm:p-4 rounded-3xl border border-stone-200/90 shadow-lg">
            <div
              ref={emblaRef}
              className="overflow-hidden rounded-2xl cursor-grab active:cursor-grabbing select-none"
              aria-roledescription="carousel"
              aria-label="Slider Properti Unggulan Batam"
            >
              <div className="flex touch-pan-y">
                {heroSlides.map((slide, idx) => {
                  const slideWaUrl = buildWhatsAppUrl(
                    settings.whatsappNumber,
                    buildListingWhatsAppMessage({
                      title: slide.title,
                      code: slide.code,
                      transactionType: slide.transactionType,
                      area: slide.area,
                      price: slide.price,
                      pricePeriod: slide.pricePeriod,
                    })
                  );

                  return (
                    <div
                      key={slide.id}
                      className="flex-[0_0_100%] min-w-0 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center bg-stone-50/70 rounded-2xl overflow-hidden border border-stone-200/60 p-3 sm:p-5"
                      role="group"
                      aria-roledescription="slide"
                      aria-label={`${idx + 1} dari ${heroSlides.length}: ${slide.title}`}
                    >
                      {/* Foto Properti di dalam Slide */}
                      <div className="lg:col-span-7 relative aspect-[16/10] rounded-2xl overflow-hidden bg-stone-100 border border-stone-200/70">
                        <img
                          src={slide.image}
                          alt={`${slide.title} — ${slide.area}`}
                          referrerPolicy="no-referrer"
                          draggable={false}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 pointer-events-none">
                          <span className="bg-white/95 backdrop-blur-md border border-stone-200/80 px-3 py-1 rounded-xl text-xs font-semibold text-slate-800 shadow-xs">
                            <span className="text-emerald-700 font-bold">
                              {slide.area}
                            </span>{' '}
                            · <span className="font-mono">{slide.code}</span>
                          </span>
                          <span className="bg-emerald-600 text-white px-3.5 py-1 rounded-xl text-xs font-bold tabular-nums shadow-sm">
                            {slide.priceLabel}
                          </span>
                        </div>
                      </div>

                      {/* Informasi & Tombol Aksi di dalam Slide yang Sama */}
                      <div className="lg:col-span-5 flex flex-col justify-between space-y-4 px-1 sm:px-2">
                        <div className="space-y-2.5">
                          <div className="flex items-center flex-wrap gap-1.5 text-xs">
                            <span className="font-bold text-emerald-700">
                              {slide.transactionType} · {slide.propertyType}
                            </span>
                            {slide.isDemo && (
                              <>
                                <span aria-hidden="true" className="text-stone-300">
                                  ·
                                </span>
                                <span className="text-slate-500">Contoh Listing</span>
                              </>
                            )}
                          </div>

                          <h1 className="text-xl sm:text-2xl lg:text-[26px] font-bold tracking-tight text-slate-900 font-serif leading-snug">
                            {slide.title}
                          </h1>

                          <div className="flex flex-wrap items-baseline gap-2.5">
                            <span className="text-xl sm:text-2xl font-bold text-emerald-700 tabular-nums">
                              {slide.priceLabel}
                            </span>
                            <span className="text-xs font-medium text-slate-500 tabular-nums">
                              {slide.specsLabel}
                            </span>
                          </div>

                          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-2">
                            {slide.subtitle}
                          </p>
                        </div>

                        <div className="pt-2 flex flex-wrap items-center gap-2.5">
                          <a
                            href={slideWaUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors inline-flex items-center gap-1.5 shadow-2xs"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span>Hubungi WA Unit Ini</span>
                          </a>

                          <button
                            type="button"
                            onClick={() =>
                              navigate({ page: 'detail', slug: slide.slug })
                            }
                            className="px-4 py-2.5 text-xs font-semibold text-slate-800 bg-white hover:bg-stone-100 border border-stone-300 rounded-xl transition-colors inline-flex items-center gap-1.5"
                          >
                            <span>Lihat Detail</span>
                            <ArrowRight className="w-3.5 h-3.5 text-emerald-700" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* KOLOM PENCARIAN SINGKAT TEPAT DI BAWAH SLIDER (TERMASUK FILTER JENIS & HARGA) */}
          <form
            onSubmit={handleSearchSubmit}
            aria-label="Form Pencarian Singkat Properti"
            className="max-w-5xl mx-auto bg-white text-slate-900 p-2.5 sm:p-3 rounded-2xl border border-stone-200/90 shadow-md"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2 items-center">
              <div className="relative sm:col-span-2 lg:col-span-4">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="home-keyword"
                  type="text"
                  aria-label="Kata kunci pencarian properti"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder="Cari perumahan, lokasi, atau budget (misal: 500 juta)..."
                  className="w-full pl-10 pr-3 py-2.5 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="lg:col-span-2">
                <select
                  id="home-area"
                  aria-label="Pilih area Batam"
                  value={area}
                  onChange={(e) => {
                    setArea(e.target.value);
                    recordUserSearchIntent({ area: e.target.value });
                  }}
                  className="w-full px-2.5 py-2.5 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="Semua">Semua Area</option>
                  {BATAM_AREAS.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-2">
                <select
                  id="home-type"
                  aria-label="Pilih jenis properti"
                  value={propertyType}
                  onChange={(e) => {
                    const nextType = e.target.value as 'Semua' | PropertyType;
                    setPropertyType(nextType);
                    recordUserSearchIntent({ propertyType: nextType });
                  }}
                  className="w-full px-2.5 py-2.5 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="Semua">Semua Jenis</option>
                  {PROPERTY_TYPES.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-2">
                <select
                  id="home-price"
                  aria-label="Pilih kisaran harga"
                  value={priceRange}
                  onChange={(e) => handlePriceRangeChange(e.target.value)}
                  className="w-full px-2.5 py-2.5 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="all">Semua Harga</option>
                  {PRICE_RANGE_OPTIONS.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2 lg:col-span-2 flex items-center gap-2">
                <select
                  id="home-transaction"
                  aria-label="Pilih status jual atau sewa"
                  value={transactionType}
                  onChange={(e) => {
                    const nextTrans = e.target.value as 'Semua' | TransactionType;
                    setTransactionType(nextTrans);
                    recordUserSearchIntent({ transactionType: nextTrans });
                  }}
                  className="w-full px-2.5 py-2.5 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="Semua">Jual & Sewa</option>
                  <option value="Dijual">Dijual</option>
                  <option value="Disewakan">Disewakan</option>
                </select>

                <button
                  type="submit"
                  className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors whitespace-nowrap inline-flex items-center justify-center gap-1.5 shrink-0"
                >
                  <Search className="w-4 h-4" />
                  <span>Cari</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      </section>

      {/* Notice if Demo Listings are active */}
      {hasDemoData && (
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs text-slate-700">
            <strong>Informasi Data Demonstrasi:</strong> Katalog saat ini menampilkan beberapa unit berlabel <strong>“Contoh Listing”</strong> agar fitur pencarian, swipe carousel, rekomendasi pintar sesuai budget, dan tombol WhatsApp dapat langsung diuji.
          </div>
        </div>
      )}

      {/* 1B. REKOMENDASI PINTAR SESUAI PREFERENSI USER & PROPERTI PALING RAMAI */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <SmartRecommendations
          onSelectListing={(slug) => navigate({ page: 'detail', slug })}
          limit={6}
        />
      </div>

      {/* 2. PROPERTI UNGGULAN GRID */}
      {featuredListings.length > 0 && (
        <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold text-emerald-700">
                Kurasi Pilihan Terbaik
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif mt-1">
                Properti Unggulan di Batam
              </h2>
            </div>

            <button
              type="button"
              onClick={() => {
                onApplyQuickSearch({ onlyFeatured: true });
                navigate({ page: 'catalog' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-800 hover:text-emerald-700 transition-colors whitespace-nowrap"
            >
              <span>Lihat Semua Unggulan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredListings.slice(0, 3).map((listing) => (
              <PropertyCard
                key={listing.id}
                listing={listing}
                onSelect={(slug) => navigate({ page: 'detail', slug })}
              />
            ))}
          </div>
        </section>
      )}

      {/* 3. ARCHITECTURAL AREA SHOWCASE BENTO GRID + LISTING TERBARU */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <p className="text-xs font-semibold text-emerald-700">
                Fokus Wilayah Pemasaran
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif mt-1">
                Eksplorasi Kawasan Populer di Batam
              </h2>
            </div>
            <p className="text-xs text-slate-500">
              Klik kawasan untuk memfilter properti di area tersebut
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {areaShowcase.map((areaItem) => (
              <button
                key={areaItem.name}
                type="button"
                onClick={() => {
                  onApplyQuickSearch({ area: areaItem.name });
                  navigate({ page: 'catalog' });
                }}
                className="group bg-white p-2.5 rounded-3xl border border-stone-200/90 hover:border-emerald-500/70 text-left shadow-xs hover:shadow-md transition-all"
              >
                <div className="relative h-44 rounded-2xl overflow-hidden bg-stone-100">
                  <img
                    src={areaItem.image}
                    alt={`Properti di ${areaItem.name} Batam`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-3 right-3">
                    <span className="text-xs font-mono font-semibold text-emerald-800 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-xl shadow-xs tabular-nums">
                      {areaItem.count} Listing
                    </span>
                  </div>
                </div>
                <div className="px-2 pt-3 pb-1">
                  <h3 className="text-base font-bold text-slate-900 font-serif group-hover:text-emerald-700 transition-colors">
                    {areaItem.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                    {areaItem.tagline}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Listing Terbaru Grid */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold text-emerald-700">
                Katalog Terkini · Klik Hubungi WA pada Setiap Kartu
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 font-serif mt-1">
                Listing Properti Terbaru
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigate({ page: 'catalog' })}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-800 hover:text-emerald-700 transition-colors whitespace-nowrap"
            >
              <span>Buka Katalog Lengkap</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {latestListings.length === 0 ? (
            <div className="p-10 bg-white border border-stone-200 rounded-3xl text-center space-y-3">
              <p className="text-base font-semibold text-slate-800">
                Belum Ada Listing Aktif
              </p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Saat ini belum ada properti aktif di database. Jika Anda pemilik properti, silakan kirim data properti Anda untuk ditinjau tim kami.
              </p>
              <button
                type="button"
                onClick={() => navigate({ page: 'consign' })}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-xl"
              >
                Titipkan Properti Anda
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {latestListings.map((listing) => (
                <PropertyCard
                  key={listing.id}
                  listing={listing}
                  onSelect={(slug) => navigate({ page: 'detail', slug })}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 4. Direct WhatsApp Banner Section */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white rounded-3xl p-8 sm:p-10 border border-emerald-600/40 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-lg">
          <div className="lg:col-span-8 space-y-3">
            <p className="text-xs font-semibold text-emerald-200">
              Layanan Pemasaran & Konsultasi — {settings.companyName}
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif">
              Butuh Rekomendasi Cepat atau Ingin Titip Jual Properti di Batam?
            </h2>
            <p className="text-sm text-emerald-50/90 leading-relaxed max-w-2xl">
              Hubungi Admin secara langsung melalui WhatsApp untuk cek ketersediaan unit maupun penitipan properti di seluruh area Batam.
            </p>
          </div>
          <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3">
            <a
              href={generalWaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 px-5 text-xs font-semibold text-emerald-950 bg-white hover:bg-emerald-50 rounded-2xl transition-colors text-center inline-flex items-center justify-center gap-2 shadow-sm"
            >
              <MessageCircle className="w-4 h-4 text-emerald-700" />
              <span>Chat Admin via WhatsApp Sekarang</span>
            </a>
            <button
              type="button"
              onClick={() => navigate({ page: 'consign' })}
              className="w-full py-3.5 px-5 text-xs font-semibold text-white bg-emerald-900/50 hover:bg-emerald-900/70 border border-white/20 rounded-2xl transition-colors text-center"
            >
              Titipkan Properti
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
