import React, { useEffect } from 'react';
import { RoutePath } from '../components/Navbar';
import { useProperty } from '../context/PropertyContext';

interface NotFoundPageProps {
  navigate: (route: RoutePath) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ navigate }) => {
  const { updateSeoMeta } = useProperty();

  useEffect(() => {
    updateSeoMeta(
      '404 Halaman Tidak Ditemukan | BatamProperti.com',
      'Halaman yang Anda tuju tidak ditemukan di portal BatamProperti.com.'
    );
  }, [updateSeoMeta]);

  return (
    <div className="max-w-[800px] mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-5">
      <p className="text-xs font-mono font-semibold text-amber-700">
        ERROR 404 · HALAMAN TIDAK DITEMUKAN
      </p>
      <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 font-serif">
        Maaf, Halaman yang Anda Cari Tidak Tersedia
      </h1>
      <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
        Tautan yang Anda buka mungkin sudah dipindahkan atau tidak valid. Silakan kembali ke Beranda atau telusuri Katalog Properti BatamProperti.com.
      </p>
      <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
        <button
          type="button"
          onClick={() => navigate({ page: 'home' })}
          className="px-5 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg transition-colors"
        >
          Kembali ke Beranda
        </button>
        <button
          type="button"
          onClick={() => navigate({ page: 'catalog' })}
          className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0A192F] hover:bg-slate-800 rounded-lg transition-colors"
        >
          Buka Katalog Properti
        </button>
      </div>
    </div>
  );
};
