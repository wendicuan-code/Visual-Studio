import React, { useState } from 'react';
import { Menu, MessageCircle, X, Sparkles } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { buildWhatsAppUrl } from '../utils/propertyLogic';

export type RoutePath =
  | { page: 'home' }
  | {
      page: 'catalog';
      presetArea?: string;
      presetType?: string;
      presetTransaction?: string;
      presetPrimary?: boolean;
    }
  | { page: 'detail'; slug: string }
  | { page: 'favorites' }
  | { page: 'consign' }
  | { page: 'info'; tab?: 'tentang' | 'kontak' | 'faq' | 'privasi' | 'syarat' }
  | { page: 'admin' }
  | { page: 'not-found' };

interface NavbarProps {
  currentRoute: RoutePath;
  navigate: (route: RoutePath) => void;
  onOpenCSChat?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  navigate,
  onOpenCSChat,
}) => {
  const { settings, favorites } = useProperty();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const waUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Halo CS ${settings.siteName} (${settings.companyName}), saya ingin berkonsultasi mengenai properti di Batam.`
  );

  const handleNav = (route: RoutePath) => {
    navigate(route);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isPrimaryActive =
    currentRoute.page === 'catalog' && Boolean(currentRoute.presetPrimary);
  const isCatalogGeneralActive =
    (currentRoute.page === 'catalog' && !currentRoute.presetPrimary) ||
    currentRoute.page === 'detail';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md text-slate-900 border-b border-stone-200/90 shadow-2xs">
      {/* Strict 3-Zone Top Bar Contract */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav({ page: 'home' })}
          className="text-xl font-bold tracking-tight text-slate-900 hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 text-left font-serif"
          aria-label="Beranda BatamProperti.com"
        >
          {settings.logoText || 'BatamProperti.com'}
        </button>

        {/* Zone 2: Updated Navigation Links with Properti Baru / Primary */}
        <nav
          aria-label="Navigasi Utama"
          className="hidden md:flex items-center gap-5 lg:gap-6 text-sm font-medium text-slate-600"
        >
          <button
            type="button"
            onClick={() => handleNav({ page: 'home' })}
            className={`hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
              currentRoute.page === 'home'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent'
            }`}
          >
            Beranda
          </button>

          <button
            type="button"
            onClick={() =>
              handleNav({ page: 'catalog', presetPrimary: true })
            }
            className={`inline-flex items-center gap-1.5 hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
              isPrimaryActive
                ? 'border-emerald-600 text-emerald-800 font-semibold'
                : 'border-transparent text-slate-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Properti Baru / Primary</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleNav({ page: 'catalog', presetPrimary: false })
            }
            className={`hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
              isCatalogGeneralActive
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent'
            }`}
          >
            Jual & Sewa
          </button>

          <button
            type="button"
            onClick={() => handleNav({ page: 'consign' })}
            className={`hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
              currentRoute.page === 'consign'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent'
            }`}
          >
            Titipkan Properti
          </button>

          <button
            type="button"
            onClick={() => handleNav({ page: 'favorites' })}
            className={`hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 tabular-nums ${
              currentRoute.page === 'favorites'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent'
            }`}
          >
            Favorit ({favorites.length})
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action — Direct WhatsApp Link */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors whitespace-nowrap shrink-0 shadow-xs"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Hubungi WA</span>
          </a>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="md:hidden p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-stone-100 transition-colors"
            aria-label={mobileMenuOpen ? 'Tutup menu navigasi' : 'Buka menu navigasi'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-stone-200 px-4 pt-3 pb-5 space-y-1.5 shadow-lg">
          <button
            type="button"
            onClick={() => handleNav({ page: 'home' })}
            className="block w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-stone-100"
          >
            Beranda
          </button>
          <button
            type="button"
            onClick={() => handleNav({ page: 'catalog', presetPrimary: true })}
            className="flex items-center gap-2 w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold text-emerald-800 bg-emerald-50/70 hover:bg-emerald-100/70"
          >
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Properti Baru / Primary</span>
          </button>
          <button
            type="button"
            onClick={() => handleNav({ page: 'catalog', presetPrimary: false })}
            className="block w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-stone-100"
          >
            Katalog Jual & Sewa
          </button>
          <button
            type="button"
            onClick={() => handleNav({ page: 'consign' })}
            className="block w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-stone-100"
          >
            Titipkan Properti (Kirim ke WA Admin)
          </button>
          <button
            type="button"
            onClick={() => handleNav({ page: 'favorites' })}
            className="block w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-stone-100 tabular-nums"
          >
            Properti Favorit ({favorites.length})
          </button>
          <button
            type="button"
            onClick={() => handleNav({ page: 'info', tab: 'tentang' })}
            className="block w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-stone-100"
          >
            Tentang Kami & Informasi
          </button>
          <div className="pt-2">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chat CS via WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
