import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  Database,
  Eye,
  Flame,
  MessageCircle,
  RefreshCw,
  TrendingUp,
} from 'lucide-react';
import { collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { PropertyListing } from '../types/property';
import {
  formatRupiahRingkas,
  getListingEngagementScore,
} from '../utils/propertyLogic';

interface AdminPopularityAnalyticsProps {
  listings: PropertyListing[];
  onViewListing: (slug: string) => void;
}

interface FirestoreAggregatedCounts {
  [listingId: string]: {
    views: number;
    waClicks: number;
  };
}

export const AdminPopularityAnalytics: React.FC<AdminPopularityAnalyticsProps> = ({
  listings,
  onViewListing,
}) => {
  const [firestoreEventsMap, setFirestoreEventsMap] =
    useState<FirestoreAggregatedCounts>({});
  const [firestoreListingsMap, setFirestoreListingsMap] =
    useState<FirestoreAggregatedCounts>({});
  const [totalFirestoreEvents, setTotalFirestoreEvents] = useState<number>(0);
  const [syncingFirestore, setSyncingFirestore] = useState<boolean>(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string>('');
  const [chartView, setChartView] = useState<'listings' | 'areas'>('listings');

  // Subscribe to real-time /listing_events in Firestore and fetch /listings from Firestore
  const fetchFirestoreListingsSnapshot = useCallback(async () => {
    setSyncingFirestore(true);
    try {
      const snap = await getDocs(collection(db, 'listings'));
      const map: FirestoreAggregatedCounts = {};
      snap.forEach((docSnap) => {
        const data = docSnap.data();
        if (data && data.id) {
          map[String(data.id)] = {
            views: Number(data.viewsCount) || 0,
            waClicks: Number(data.waClicksCount) || 0,
          };
        }
      });
      setFirestoreListingsMap(map);
      setLastSyncedAt(
        new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    } catch {
      // Uses local + listing_events aggregation if /listings collection is empty
    } finally {
      setSyncingFirestore(false);
    }
  }, []);

  useEffect(() => {
    fetchFirestoreListingsSnapshot();

    const unsubscribe = onSnapshot(
      collection(db, 'listing_events'),
      (snapshot) => {
        const agg: FirestoreAggregatedCounts = {};
        let count = 0;
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          const lid = String(data.listingId || '');
          if (!lid) return;
          if (!agg[lid]) {
            agg[lid] = { views: 0, waClicks: 0 };
          }
          if (data.eventType === 'wa_click') {
            agg[lid].waClicks += 1;
            agg[lid].views += 1;
          } else {
            agg[lid].views += 1;
          }
          count += 1;
        });
        setFirestoreEventsMap(agg);
        setTotalFirestoreEvents(count);
        setLastSyncedAt(
          new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          })
        );
      },
      () => {
        // Fallback to server state if client listener is restricted
      }
    );

    return () => unsubscribe();
  }, [fetchFirestoreListingsSnapshot]);

  // Merge listing metrics with aggregated Firestore click & view data
  const aggregatedListings = useMemo(() => {
    return listings.map((item) => {
      const fsListing = firestoreListingsMap[item.id];
      const fsEvents = firestoreEventsMap[item.id];

      const baseViews = Math.max(
        Number(item.viewsCount) || 0,
        fsListing?.views || 0
      );
      const baseWaClicks = Math.max(
        Number(item.waClicksCount) || 0,
        fsListing?.waClicks || 0
      );

      // Combine baseline with any additional live Firestore events
      const viewsCount = Math.max(baseViews, (fsEvents?.views || 0) + baseViews);
      const waClicksCount = Math.max(
        baseWaClicks,
        (fsEvents?.waClicks || 0) + baseWaClicks
      );

      return {
        ...item,
        viewsCount,
        waClicksCount,
      };
    });
  }, [listings, firestoreListingsMap, firestoreEventsMap]);

  const rankedListings = useMemo(() => {
    return [...aggregatedListings]
      .sort((a, b) => {
        const scoreDiff =
          getListingEngagementScore(b) - getListingEngagementScore(a);
        if (scoreDiff !== 0) return scoreDiff;
        return (b.viewsCount || 0) - (a.viewsCount || 0);
      })
      .slice(0, 10);
  }, [aggregatedListings]);

  // Aggregate popularity by Batam area for the Area Interest Chart
  const areaChartData = useMemo(() => {
    const map = new Map<
      string,
      { area: string; views: number; waClicks: number; units: number }
    >();
    for (const item of aggregatedListings) {
      const current = map.get(item.area) || {
        area: item.area,
        views: 0,
        waClicks: 0,
        units: 0,
      };
      current.views += Number(item.viewsCount) || 0;
      current.waClicks += Number(item.waClicksCount) || 0;
      current.units += 1;
      map.set(item.area, current);
    }
    return Array.from(map.values()).sort(
      (a, b) => b.views + b.waClicks * 2 - (a.views + a.waClicks * 2)
    );
  }, [aggregatedListings]);

  const stats = useMemo(() => {
    const totalViews = aggregatedListings.reduce(
      (acc, item) => acc + (Number(item.viewsCount) || 0),
      0
    );
    const totalWaClicks = aggregatedListings.reduce(
      (acc, item) => acc + (Number(item.waClicksCount) || 0),
      0
    );
    const totalInteractions = totalViews + totalWaClicks;
    const topItem = rankedListings[0] || null;
    const maxScore = topItem
      ? Math.max(1, getListingEngagementScore(topItem))
      : 1;
    const maxTotalClicks = topItem
      ? Math.max(
          1,
          (Number(topItem.viewsCount) || 0) +
            (Number(topItem.waClicksCount) || 0)
        )
      : 1;

    return {
      totalViews,
      totalWaClicks,
      totalInteractions,
      topItem,
      maxScore,
      maxTotalClicks,
    };
  }, [aggregatedListings, rankedListings]);

  return (
    <div
      aria-label="Dashboard Analitik & Grafik Properti Terpopuler Firestore"
      className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-2xs"
    >
      {/* Header & Firestore Sync Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Flame className="w-4 h-4 text-amber-600" />
            <span>Analitik Properti Ramai &amp; Terklik Terbanyak (Firestore Aggregation)</span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 font-serif mt-0.5">
            Peringkat Item Properti Paling Ramai Diminati Pengunjung
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
              <Database className="w-3.5 h-3.5" />
              <span>Tersinkronisasi dengan Firestore (`listing_events` &amp; `listings`)</span>
            </span>
            {lastSyncedAt && (
              <span>· Update terakhir: {lastSyncedAt}</span>
            )}
            {totalFirestoreEvents > 0 && (
              <span>· +{totalFirestoreEvents} event klik real-time</span>
            )}
          </p>
        </div>

        {/* Summary Engagement Counters & Refresh Button */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <span className="text-slate-500 block">Total Klik Detail</span>
            <span className="text-base font-bold text-slate-900 tabular-nums inline-flex items-center gap-1.5 mt-0.5">
              <Eye className="w-4 h-4 text-emerald-600" />
              {stats.totalViews}x dilihat
            </span>
          </div>

          <div className="px-4 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
            <span className="text-emerald-800 block">Total Klik WhatsApp</span>
            <span className="text-base font-bold text-emerald-900 tabular-nums inline-flex items-center gap-1.5 mt-0.5">
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              {stats.totalWaClicks}x klik WA
            </span>
          </div>

          <button
            type="button"
            onClick={fetchFirestoreListingsSnapshot}
            disabled={syncingFirestore}
            className="px-3.5 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 text-emerald-600 ${
                syncingFirestore ? 'animate-spin' : ''
              }`}
            />
            <span>Sinkronkan Firestore</span>
          </button>
        </div>
      </div>

      {/* VISUAL CHART SECTION: Interactive Chart of Most Popular Listings */}
      <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl p-5 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
              <BarChart3 className="w-4 h-4 text-emerald-600" />
              <span>Visualisasi Grafik Minat Properti Tertinggi</span>
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              {chartView === 'listings'
                ? 'Grafik Perbandingan Klik Detail (Views) vs Klik WhatsApp per Properti'
                : 'Grafik Distribusi Minat & Klik Berdasarkan Kawasan di Batam'}
            </h3>
          </div>

          {/* Chart Mode Switcher & Legend */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-3 text-[11px] font-medium text-slate-600 mr-1">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 inline-block" />
                <span>Klik Detail (Views)</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500 inline-block" />
                <span>Klik WhatsApp (Prospek)</span>
              </span>
            </div>

            <div className="inline-flex rounded-xl bg-white border border-slate-200 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setChartView('listings')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  chartView === 'listings'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Per Unit Properti
              </button>
              <button
                type="button"
                onClick={() => setChartView('areas')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  chartView === 'areas'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Per Kawasan Batam
              </button>
            </div>
          </div>
        </div>

        {/* Chart Body */}
        {chartView === 'listings' ? (
          <div
            role="img"
            aria-label="Grafik batang properti paling populer berdasarkan jumlah dilihat dan klik WhatsApp"
            className="space-y-3.5 pt-1"
          >
            {rankedListings.slice(0, 8).map((item, idx) => {
              const views = Number(item.viewsCount) || 0;
              const waClicks = Number(item.waClicksCount) || 0;
              const total = views + waClicks;
              const viewsWidthPct = Math.min(
                100,
                Math.max(4, Math.round((views / stats.maxTotalClicks) * 100))
              );
              const waWidthPct = Math.min(
                100,
                Math.max(2, Math.round((waClicks / stats.maxTotalClicks) * 100))
              );
              const conversionRate =
                views > 0 ? Math.round((waClicks / views) * 100) : 0;

              return (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200/80 rounded-xl p-3.5 space-y-2 hover:border-emerald-400 transition-colors"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`px-2 py-0.5 rounded-md font-mono font-bold text-[11px] tabular-nums shrink-0 ${
                          idx === 0
                            ? 'bg-amber-500 text-white'
                            : idx < 3
                            ? 'bg-emerald-100 text-emerald-900'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        #{idx + 1}
                      </span>
                      <span className="font-mono font-bold text-emerald-800 shrink-0">
                        {item.code}
                      </span>
                      <button
                        type="button"
                        onClick={() => onViewListing(item.slug)}
                        className="font-semibold text-slate-900 hover:text-emerald-700 truncate text-left"
                      >
                        {item.title}
                      </button>
                      <span className="text-slate-400 hidden sm:inline">·</span>
                      <span className="text-slate-500 hidden sm:inline shrink-0">
                        {item.area} ({formatRupiahRingkas(item.price, item.pricePeriod)})
                      </span>
                    </div>

                    <div className="flex items-center gap-3 font-mono text-[11px] tabular-nums shrink-0">
                      <span className="text-emerald-700 font-semibold">
                        {views} dilihat
                      </span>
                      <span className="text-amber-700 font-semibold">
                        {waClicks} klik WA
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-bold">
                        Total: {total} ({conversionRate}% WA)
                      </span>
                    </div>
                  </div>

                  {/* Stacked / Dual Horizontal Visual Bar */}
                  <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden flex items-center p-0.5 gap-0.5">
                    <div
                      className="h-full bg-emerald-600 rounded-l-full transition-all duration-500"
                      style={{ width: `${viewsWidthPct}%` }}
                      title={`Klik Detail: ${views}x`}
                    />
                    <div
                      className="h-full bg-amber-500 rounded-r-full transition-all duration-500"
                      style={{ width: `${waWidthPct}%` }}
                      title={`Klik WhatsApp: ${waClicks}x`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div
            role="img"
            aria-label="Grafik distribusi minat properti berdasarkan area di Batam"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1"
          >
            {areaChartData.map((areaItem, idx) => {
              const total = areaItem.views + areaItem.waClicks;
              const maxAreaTotal = Math.max(
                1,
                (areaChartData[0]?.views || 0) + (areaChartData[0]?.waClicks || 0)
              );
              const pct = Math.min(
                100,
                Math.max(10, Math.round((total / maxAreaTotal) * 100))
              );

              return (
                <div
                  key={areaItem.area}
                  className="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[11px] font-mono font-semibold text-emerald-700">
                        Kawasan #{idx + 1}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">
                        {areaItem.area}
                      </h4>
                    </div>
                    <span className="text-xs font-mono font-bold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-lg tabular-nums">
                      {total} klik ({areaItem.units} unit)
                    </span>
                  </div>

                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-600 font-mono tabular-nums">
                    <span>{areaItem.views}x dilihat</span>
                    <span className="text-amber-700 font-semibold">
                      {areaItem.waClicks}x klik WA
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Top Ranked Listings Table */}
      {rankedListings.length === 0 ? (
        <p className="text-xs text-slate-500 py-4">
          Belum ada data listing properti untuk dianalisis.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/80">
                <th className="py-3 px-3 font-semibold">Peringkat</th>
                <th className="py-3 px-3 font-semibold">Properti &amp; Kode</th>
                <th className="py-3 px-3 font-semibold">Area &amp; Harga</th>
                <th className="py-3 px-3 font-semibold text-right">Klik Detail</th>
                <th className="py-3 px-3 font-semibold text-right">Klik WA</th>
                <th className="py-3 px-3 font-semibold w-48">Tingkat Keramaian</th>
                <th className="py-3 px-3 font-semibold text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rankedListings.map((item, index) => {
                const views = Number(item.viewsCount) || 0;
                const waClicks = Number(item.waClicksCount) || 0;
                const totalClicks = views + waClicks;
                const score = getListingEngagementScore(item);
                const pct = Math.min(
                  100,
                  Math.max(8, Math.round((score / stats.maxScore) * 100))
                );
                const isTopThree = index < 3;

                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-slate-50/90 transition-colors ${
                      index === 0 ? 'bg-amber-50/30' : ''
                    }`}
                  >
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-mono font-bold text-xs tabular-nums ${
                          index === 0
                            ? 'bg-amber-500 text-white'
                            : isTopThree
                            ? 'bg-emerald-100 text-emerald-900'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        #{index + 1}
                        {index === 0 && <span>Terlaris</span>}
                        {index > 0 && isTopThree && <span>Ramai</span>}
                      </span>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="font-semibold text-slate-900 line-clamp-1">
                        {item.title}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono font-semibold text-emerald-700">
                          {item.code}
                        </span>
                        <span>·</span>
                        <span>{item.propertyType}</span>
                        <span>·</span>
                        <span>{item.transactionType}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{item.area}</div>
                      <div className="text-[11px] font-mono text-emerald-700 font-semibold tabular-nums">
                        {formatRupiahRingkas(item.price, item.pricePeriod)}
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono font-semibold text-slate-800 tabular-nums whitespace-nowrap">
                      {views}x dilihat
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono font-semibold text-emerald-700 tabular-nums whitespace-nowrap">
                      {waClicks}x WA
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-slate-700 inline-flex items-center gap-1">
                            <TrendingUp className="w-3 h-3 text-emerald-600" />
                            {totalClicks} total klik
                          </span>
                          <span className="font-mono text-slate-500 tabular-nums">
                            {pct}%
                          </span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              index === 0
                                ? 'bg-amber-500'
                                : isTopThree
                                ? 'bg-emerald-600'
                                : 'bg-slate-400'
                            }`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onViewListing(item.slug)}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                      >
                        Lihat Unit
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
