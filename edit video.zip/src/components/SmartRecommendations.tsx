import React, { useMemo } from 'react';
import { Flame, RotateCcw, Sparkles, TrendingUp } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import {
  formatRupiahRingkas,
  getSmartRecommendations,
  PRICE_RANGE_OPTIONS,
} from '../utils/propertyLogic';
import { PropertyCard } from './PropertyCard';
import { PropertyListing } from '../types/property';

interface SmartRecommendationsProps {
  onSelectListing: (slug: string) => void;
  onAskSurvey?: (listing: PropertyListing) => void;
  excludeListingId?: string;
  limit?: number;
  compactHeader?: boolean;
}

export const SmartRecommendations: React.FC<SmartRecommendationsProps> = ({
  onSelectListing,
  excludeListingId,
  limit = 6,
  compactHeader = false,
}) => {
  const {
    publicListings,
    userPreferences,
    recordUserSearchIntent,
    resetUserPreferences,
  } = useProperty();

  const pool = useMemo(
    () =>
      excludeListingId
        ? publicListings.filter((item) => item.id !== excludeListingId)
        : publicListings,
    [excludeListingId, publicListings]
  );

  const { combined, activeIntentSummary } = useMemo(
    () => getSmartRecommendations(pool, userPreferences, limit),
    [pool, userPreferences, limit]
  );

  if (combined.length === 0) return null;

  return (
    <section
      aria-label="Rekomendasi Pintar & Properti Terpopuler"
      className="bg-white border border-stone-200/90 rounded-3xl p-5 sm:p-7 space-y-6 shadow-xs"
    >
      {/* Header & Interactive User Preference Reader Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-stone-100 pb-5">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-700">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>
              {activeIntentSummary
                ? 'Rekomendasi Pintar Sesuai Kemauan Anda + Unit Paling Ramai'
                : 'Properti Paling Ramai & Terklik Terbanyak di Batam'}
            </span>
          </div>

          <h2
            className={`${
              compactHeader ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl'
            } font-bold text-slate-900 font-serif`}
          >
            {activeIntentSummary
              ? `Disarankan untuk Anda (${activeIntentSummary})`
              : 'Rekomendasi Sesuai Budget & Properti Terpopuler'}
          </h2>

          <p className="text-xs text-slate-600 max-w-2xl">
            {activeIntentSummary ? (
              <>
                Menampilkan kombinasi properti yang <strong>sesuai pilihan harga/kriteria Anda</strong> serta unit yang{' '}
                <strong>sedang ramai &amp; paling banyak diklik</strong> pengunjung.
              </>
            ) : (
              <>
                Pilih kisaran harga yang Anda inginkan (misalnya <strong>Di bawah Rp500 juta</strong> atau <strong>Rp500 juta–Rp1 miliar</strong>) atau gunakan kolom pencarian. Sistem otomatis menyajikan unit yang cocok beserta properti yang paling ramai diminati.
              </>
            )}
          </p>
        </div>

        {/* Quick Budget Intent Selector Chips */}
        <div className="flex flex-col sm:items-end gap-2">
          <span className="text-[11px] font-semibold text-slate-500">
            Pilih Kisaran Harga Cepat:
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={resetUserPreferences}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
                !userPreferences.priceRangeLabel && !userPreferences.targetPrice
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                  : 'bg-stone-50 hover:bg-emerald-50 text-slate-700 border-stone-200 hover:border-emerald-300'
              }`}
            >
              Semua Harga
            </button>

            {PRICE_RANGE_OPTIONS.map((preset) => {
              const isSelected =
                userPreferences.priceRangeLabel === preset.priceRangeLabel ||
                userPreferences.targetPrice === preset.targetPrice;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() =>
                    recordUserSearchIntent({
                      targetPrice: preset.targetPrice,
                      minPrice: preset.minPrice,
                      maxPrice: preset.maxPrice,
                      priceRangeLabel: preset.priceRangeLabel,
                    })
                  }
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
                    isSelected
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                      : 'bg-stone-50 hover:bg-emerald-50 text-slate-700 border-stone-200 hover:border-emerald-300'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}

            {activeIntentSummary && (
              <button
                type="button"
                onClick={resetUserPreferences}
                title="Reset preferensi rekomendasi"
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-rose-700 bg-stone-100 hover:bg-rose-50 border border-stone-200 transition-colors inline-flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Active Preference Summary Banner when User Intent is Detected */}
      {activeIntentSummary && (
        <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-800">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              Preferensi terbaca:{' '}
              <strong className="text-emerald-900">{activeIntentSummary}</strong>
              {typeof userPreferences.targetPrice === 'number' &&
                userPreferences.targetPrice > 0 && (
                  <span className="text-slate-600">
                    {' '}
                    (Target sekitar {formatRupiahRingkas(userPreferences.targetPrice)})
                  </span>
                )}
              {' — '}menampilkan properti yang sesuai &amp; properti terpopuler.
            </span>
          </div>
        </div>
      )}

      {/* Recommended & Popular Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {combined.map((item) => (
          <div key={item.listing.id} className="flex flex-col space-y-2">
            {/* Reason Badge Above Card */}
            <div className="flex items-center justify-between px-1 text-xs">
              <span
                className={`inline-flex items-center gap-1.5 font-semibold ${
                  item.matchType === 'budget' || item.matchType === 'preference'
                    ? 'text-emerald-800'
                    : 'text-amber-800'
                }`}
              >
                {item.matchType === 'popular' ? (
                  <Flame className="w-3.5 h-3.5 text-amber-600" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                )}
                <span>{item.reasonBadge}</span>
              </span>
              <span className="text-[11px] font-mono text-slate-500 tabular-nums">
                {(item.listing.viewsCount || 0) + (item.listing.waClicksCount || 0)} klik
              </span>
            </div>

            <div className="flex-1 flex flex-col">
              <PropertyCard
                listing={item.listing}
                onSelect={onSelectListing}
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
