import React, { useState } from 'react';
import {
  Heart,
  Building2,
  MessageCircle,
} from 'lucide-react';
import { PropertyListing } from '../types/property';
import {
  buildListingWhatsAppMessage,
  buildWhatsAppUrl,
  formatRupiahRingkas,
} from '../utils/propertyLogic';
import { useProperty } from '../context/PropertyContext';

interface PropertyCardProps {
  listing: PropertyListing;
  onSelect: (slug: string) => void;
  onAskSurvey?: (listing: PropertyListing) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({
  listing,
  onSelect,
}) => {
  const { favorites, toggleFavorite, settings, recordListingInteraction } =
    useProperty();
  const photos =
    listing.photos && listing.photos.length > 0
      ? listing.photos
      : ['/images/rumah-batam-center.svg'];

  const mainIdx =
    listing.mainPhotoIndex && listing.mainPhotoIndex < photos.length
      ? listing.mainPhotoIndex
      : 0;
  const [imgError, setImgError] = useState(false);

  const isFav = favorites.includes(listing.id);
  const currentPhoto = photos[mainIdx] || photos[0];

  const specs: string[] = [];
  if (listing.landArea > 0) specs.push(`LT ${listing.landArea} m²`);
  if (listing.buildingArea > 0) specs.push(`LB ${listing.buildingArea} m²`);
  if (listing.bedrooms > 0) specs.push(`${listing.bedrooms} KT`);
  if (listing.bathrooms > 0) specs.push(`${listing.bathrooms} KM`);

  const directWaUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    buildListingWhatsAppMessage(listing)
  );

  const totalClicks = (listing.viewsCount || 0) + (listing.waClicksCount || 0);
  const isHot = totalClicks >= 120;
  const isPrimary = listing.marketCategory === 'Primary';

  const handleOpenDetail = () => {
    recordListingInteraction(listing, 'view');
    onSelect(listing.slug);
  };

  return (
    <article className="group bg-white border border-stone-200/90 hover:border-emerald-500/70 rounded-3xl p-2.5 flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 shadow-xs hover:shadow-xl">
      <div>
        {/* Clean Modern Daylight Photo Frame */}
        <div className="relative aspect-[4/3] bg-stone-100 rounded-2xl overflow-hidden select-none border border-stone-200/60">
          {!imgError ? (
            <img
              src={currentPhoto}
              alt={listing.title}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              onClick={handleOpenDetail}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 cursor-pointer"
            />
          ) : (
            <div
              onClick={handleOpenDetail}
              className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-100 to-emerald-50 text-slate-700 p-6 text-center cursor-pointer"
            >
              <Building2 className="w-10 h-10 text-emerald-600 mb-2" />
              <span className="text-xs font-medium text-slate-600">
                {listing.propertyType} · {listing.area}
              </span>
            </div>
          )}

          {/* Top Left Crisp Daylight Glass Status Overlay */}
          <div className="absolute top-3 left-3 bg-white/92 backdrop-blur-md text-slate-900 px-3 py-1 rounded-xl text-xs font-medium pointer-events-none flex items-center gap-1.5 shadow-xs border border-white/80">
            <span className="text-emerald-700 font-bold">
              {listing.transactionType}
            </span>
            <span aria-hidden="true" className="text-slate-300">
              ·
            </span>
            <span className="font-semibold text-slate-700">
              {listing.propertyType}
            </span>
            {isPrimary && (
              <>
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <span className="font-bold text-teal-700">Primary</span>
              </>
            )}
          </div>

          {/* Interactive Favorite Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(listing.id);
            }}
            aria-label={
              isFav
                ? `Hapus ${listing.title} dari favorit`
                : `Simpan ${listing.title} ke favorit`
            }
            className={`absolute top-3 right-3 w-9 h-9 rounded-xl flex items-center justify-center transition-colors shadow-xs border ${
              isFav
                ? 'bg-rose-500 text-white border-rose-500'
                : 'bg-white/92 text-slate-700 border-white/80 hover:bg-white hover:text-rose-600'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
          </button>

          {/* Bottom Right Listing Code Badge */}
          <div className="absolute bottom-2.5 right-2.5 bg-slate-900/70 backdrop-blur-md px-2.5 py-1 rounded-lg pointer-events-none">
            <span className="font-mono text-[11px] text-emerald-200 font-semibold tabular-nums">
              {listing.code}
            </span>
          </div>
        </div>

        {/* Card Content Body */}
        <div className="px-3 pt-4 pb-3 space-y-2.5">
          {/* Quiet 1-line text kicker with middot separators */}
          <div className="flex items-center flex-wrap gap-1.5 text-xs text-slate-500">
            <span className="font-semibold text-emerald-800">{listing.area}</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                isPrimary
                  ? 'font-semibold text-teal-700'
                  : 'font-medium text-slate-500'
              }
            >
              {isPrimary ? 'Primary (Baru)' : 'Secondary'}
            </span>
            {isHot && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-amber-700">Ramai</span>
              </>
            )}
            {totalClicks > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums text-slate-500">
                  {totalClicks}x dilihat
                </span>
              </>
            )}
            {listing.isFeatured && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-teal-700">Unggulan</span>
              </>
            )}
            {listing.isDemo && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-slate-500">Contoh Listing</span>
              </>
            )}
            {listing.status !== 'Aktif' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-red-700">{listing.status}</span>
              </>
            )}
          </div>

          {/* Price in Rupiah */}
          <div className="flex items-baseline justify-between gap-2">
            <p className="text-xl font-bold text-slate-900 tabular-nums tracking-tight">
              {formatRupiahRingkas(listing.price, listing.pricePeriod)}
            </p>
          </div>

          {/* Primary Title */}
          <h3 className="text-[15px] font-semibold text-slate-800 leading-snug line-clamp-2">
            <button
              type="button"
              onClick={handleOpenDetail}
              className="text-left hover:text-emerald-700 transition-colors focus:outline-none focus:underline"
            >
              {listing.title}
            </button>
          </h3>

          {/* Specifications Line with middot separators */}
          {specs.length > 0 && (
            <div className="pt-2.5 border-t border-stone-100 flex items-center flex-wrap gap-1.5 text-xs text-slate-600 font-medium tabular-nums">
              {specs.map((spec, idx) => (
                <React.Fragment key={spec}>
                  {idx > 0 && (
                    <span aria-hidden="true" className="text-stone-300">
                      ·
                    </span>
                  )}
                  <span>{spec}</span>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Card Footer Actions — Pure Direct WhatsApp Link + Detail */}
      <div className="px-3 pb-2.5 pt-1 flex items-center gap-2">
        <a
          href={directWaUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => recordListingInteraction(listing, 'wa_click')}
          className="flex-1 py-2.5 px-3.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors whitespace-nowrap inline-flex items-center justify-center gap-1.5 shadow-2xs"
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>Hubungi WA</span>
        </a>
        <button
          type="button"
          onClick={handleOpenDetail}
          className="py-2.5 px-3.5 text-xs font-semibold text-slate-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors whitespace-nowrap"
        >
          Detail Unit
        </button>
      </div>
    </article>
  );
};
