import React, { useState } from 'react';
import { X } from 'lucide-react';
import { PropertyListing } from '../types/property';
import { useProperty } from '../context/PropertyContext';

interface InquiryModalProps {
  listing: PropertyListing | null;
  defaultType?: 'Pertanyaan' | 'Survei';
  onClose: () => void;
}

export const InquiryModal: React.FC<InquiryModalProps> = ({
  listing,
  defaultType = 'Survei',
  onClose,
}) => {
  const { submitInquiry } = useProperty();
  const [inquiryType, setInquiryType] = useState<'Pertanyaan' | 'Survei'>(defaultType);
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [preferredSurveyTime, setPreferredSurveyTime] = useState('');
  const [message, setMessage] = useState(
    listing
      ? `Halo, saya tertarik dengan properti "${listing.title}" (${listing.code}) di ${listing.area}. Mohon informasi jadwal survei dan ketersediaan unit.`
      : 'Halo, saya ingin berkonsultasi mengenai pencarian properti di Batam.'
  );
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    const res = await submitInquiry({
      inquiryType,
      name,
      whatsapp,
      listingId: listing?.id || 'general',
      listingCode: listing?.code || 'UMUM',
      listingTitle: listing?.title || 'Konsultasi Umum Properti Batam',
      message,
      preferredSurveyTime: preferredSurveyTime || 'Fleksibel (Sesuai Konfirmasi Broker)',
    });

    setSubmitting(false);
    if (!res.ok) {
      setError(res.error || 'Mohon periksa kembali data yang Anda isi.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-inquiry-title"
    >
      <div className="bg-white rounded-xl max-w-lg w-full border border-slate-200 overflow-hidden my-8">
        <div className="px-6 py-4 bg-[#0A192F] text-white flex items-center justify-between">
          <div>
            <h2 id="modal-inquiry-title" className="text-base font-semibold">
              {inquiryType === 'Survei'
                ? 'Jadwalkan Survei Lokasi'
                : 'Ajukan Pertanyaan Properti'}
            </h2>
            {listing && (
              <p className="text-xs text-slate-300 mt-0.5 font-mono">
                {listing.code} · {listing.area}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup formulir"
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-6 space-y-4">
            <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm space-y-1">
              <p className="font-semibold">Permintaan Anda Telah Diterima</p>
              <p className="text-xs text-emerald-800 leading-relaxed">
                Data Anda telah tersimpan di sistem PT Cuan Properti. Tim broker kami akan segera menghubungi nomor WhatsApp Anda untuk konfirmasi jadwal survei atau penjelasan detail unit.
              </p>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Catatan: Pengajuan minat atau jadwal survei ini bukan merupakan tanda jadi (booking fee) dan tidak mengikat transaksi sebelum ada kesepakatan tertulis resmi.
            </p>
            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0A192F] rounded-lg hover:bg-slate-800"
              >
                Selesai & Tutup
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Segmented Mode Control */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setInquiryType('Survei')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  inquiryType === 'Survei'
                    ? 'bg-white text-[#0A192F] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Permintaan Survei Lokasi
              </button>
              <button
                type="button"
                onClick={() => setInquiryType('Pertanyaan')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  inquiryType === 'Pertanyaan'
                    ? 'bg-white text-[#0A192F] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pertanyaan Umum / Harga
              </button>
            </div>

            {listing && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                <p className="font-semibold text-slate-900">{listing.title}</p>
                <p className="text-slate-500 mt-0.5">
                  Kode Listing: <span className="font-mono">{listing.code}</span> · Area: {listing.area}
                </p>
              </div>
            )}

            {error && (
              <div
                role="alert"
                className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700"
              >
                {error}
              </div>
            )}

            <div>
              <label
                htmlFor="inq-name"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Nama Lengkap *
              </label>
              <input
                id="inq-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Contoh: Budi Santoso"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A192F]"
              />
            </div>

            <div>
              <label
                htmlFor="inq-wa"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Nomor WhatsApp Aktif *
              </label>
              <input
                id="inq-wa"
                type="tel"
                required
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="Contoh: 081270008988"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A192F] tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="inq-time"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Waktu Survei / Konsultasi yang Diinginkan
              </label>
              <input
                id="inq-time"
                type="text"
                value={preferredSurveyTime}
                onChange={(e) => setPreferredSurveyTime(e.target.value)}
                placeholder="Contoh: Sabtu pukul 10:00 WIB atau Sore hari kerja"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A192F]"
              />
            </div>

            <div>
              <label
                htmlFor="inq-msg"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Pesan / Pertanyaan *
              </label>
              <textarea
                id="inq-msg"
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A192F]"
              />
            </div>

            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-lg text-[11px] text-slate-700 leading-relaxed">
              <strong>Pemberitahuan Penting:</strong> Pengajuan minat atau permintaan survei ini <strong>bukan tanda jadi (booking fee)</strong> dan <strong>tidak mengikat transaksi</strong>. Seluruh proses transaksi properti dilakukan melalui konsultasi resmi, survei fisik, negosiasi, dan penandatanganan dokumen di hadapan PPAT/Notaris.
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-5 py-2.5 text-xs font-semibold text-[#0A192F] bg-[#D4AF37] hover:bg-[#e3be42] rounded-lg disabled:opacity-50"
              >
                {submitting ? 'Mengirim...' : 'Kirim Permintaan'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
