import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { BATAM_AREAS, buildWhatsAppUrl } from '../utils/propertyLogic';
import { RoutePath } from './Navbar';

interface FooterProps {
  navigate: (route: RoutePath) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  const { settings } = useProperty();

  const waUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Halo Admin ${settings.siteName} (${settings.companyName}), saya ingin menanyakan layanan jual/sewa properti di Batam.`
  );

  const go = (route: RoutePath) => {
    navigate(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-stone-100 text-slate-600 border-t border-stone-200">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Brand & Company */}
          <div className="space-y-3">
            <div className="text-xl font-bold text-slate-900 font-serif">
              {settings.logoText || 'BatamProperti.com'}
            </div>
            <p className="text-xs font-semibold text-emerald-700">
              Dikelola oleh {settings.companyName || 'PT Cuan Properti'}
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              Portal jual, sewa, dan pemasaran properti residensial serta komersial di Batam. Admin kami siap mendampingi konsultasi hingga proses transaksi.
            </p>
            <div className="pt-1">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Chat Admin via WhatsApp Sekarang</span>
              </a>
            </div>
          </div>

          {/* Column 2: Fokus Area Batam */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Fokus Area di Batam
            </h3>
            <ul className="space-y-2 text-sm">
              {BATAM_AREAS.slice(0, 6).map((area) => (
                <li key={area}>
                  <button
                    type="button"
                    onClick={() => go({ page: 'catalog', presetArea: area })}
                    className="text-slate-600 hover:text-emerald-700 transition-colors text-left"
                  >
                    Properti di {area}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Halaman Informasi & Layanan */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Layanan & Informasi
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'catalog' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Katalog Properti Batam
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'consign' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Jual / Titipkan Properti
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'info', tab: 'tentang' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Tentang Kami ({settings.companyName})
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'info', tab: 'kontak' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Hubungi Admin Kami
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'info', tab: 'faq' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Pertanyaan Umum (FAQ)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'info', tab: 'privasi' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Kebijakan Privasi
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go({ page: 'info', tab: 'syarat' })}
                  className="text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  Syarat Penggunaan
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Kontak Resmi Admin */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Kantor & Kontak Admin
            </h3>
            <div className="space-y-2 text-sm text-slate-600">
              <p className="leading-relaxed">
                {settings.officeAddress ||
                  '[Placeholder Admin: Alamat kantor belum diisi di Pengaturan Website]'}
              </p>
              <p className="tabular-nums">
                WhatsApp Admin:{' '}
                {settings.whatsappNumber ? (
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-700 font-semibold hover:underline"
                  >
                    +{settings.whatsappNumber.replace(/^\+/, '')}
                  </a>
                ) : (
                  '[Belum dikonfigurasi admin]'
                )}
              </p>
              <p>
                Email:{' '}
                {settings.email ? (
                  <a
                    href={`mailto:${settings.email}`}
                    className="text-slate-800 hover:underline"
                  >
                    {settings.email}
                  </a>
                ) : (
                  '[Belum dikonfigurasi admin]'
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} {settings.siteName} — {settings.companyName}. Hak cipta dilindungi undang-undang.
          </p>
        </div>
      </div>
    </footer>
  );
};
