import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { buildWhatsAppUrl } from '../utils/propertyLogic';

export const WhatsAppFab: React.FC = () => {
  const { settings, userPreferences } = useProperty();

  const preferenceNote = userPreferences.priceRangeLabel
    ? ` Saya sedang mencari properti dengan kisaran ${userPreferences.priceRangeLabel}${
        userPreferences.preferredArea ? ` di area ${userPreferences.preferredArea}` : ''
      }.`
    : '';

  const message = `Halo Admin ${settings.siteName} (${settings.companyName}), saya ingin berkonsultasi mengenai properti di Batam.${preferenceNote} Mohon dibantu rekomendasinya. Terima kasih.`;

  const waUrl = buildWhatsAppUrl(settings.whatsappNumber, message);

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Chat Admin ${settings.siteName} via WhatsApp Sekarang`}
        className="group inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-full shadow-md hover:shadow-lg border border-emerald-500/80 transition-all duration-200 hover:-translate-y-0.5 text-xs font-semibold"
      >
        <span className="relative flex items-center justify-center w-4 h-4">
          <MessageCircle className="w-3.5 h-3.5 fill-white/20 text-white" />
          <span
            aria-hidden="true"
            className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-200"
          />
        </span>
        <span className="tracking-tight">Chat WA</span>
      </a>
    </div>
  );
};
