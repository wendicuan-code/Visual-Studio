import {
  CustomerInquiry,
  FilterState,
  ListingStatus,
  PropertyListing,
  PropertySubmission,
  PropertyType,
  RecommendedListingItem,
  TransactionType,
  UserPreferenceProfile,
} from '../types/property';

export const BATAM_AREAS: string[] = [
  'Batam Center',
  'Pasir Putih',
  'Nagoya',
  'Bengkong',
  'Sekupang',
  'Tiban',
  'Lubuk Baja',
  'Batu Aji',
  'Nongsa',
  'Kabil & Punggur',
];

export const PROPERTY_TYPES: PropertyType[] = [
  'Rumah',
  'Ruko',
  'Apartemen',
  'Tanah',
  'Kos-kosan',
  'Gudang',
  'Komersial Lainnya',
];

export const PUBLIC_VISIBLE_STATUSES: ListingStatus[] = [
  'Aktif',
  'Terjual',
  'Tersewa',
];

export interface PriceRangeOption {
  id: string;
  label: string;
  minPrice: number | '';
  maxPrice: number | '';
  targetPrice: number;
  priceRangeLabel: string;
}

export const PRICE_RANGE_OPTIONS: PriceRangeOption[] = [
  {
    id: 'under-500m',
    label: 'Di bawah Rp500 juta',
    minPrice: '',
    maxPrice: 500_000_000,
    targetPrice: 450_000_000,
    priceRangeLabel: 'Di bawah Rp500 juta',
  },
  {
    id: '500m-1b',
    label: 'Rp500 juta–Rp1 miliar',
    minPrice: 500_000_000,
    maxPrice: 1_000_000_000,
    targetPrice: 750_000_000,
    priceRangeLabel: 'Rp500 juta–Rp1 miliar',
  },
  {
    id: '1b-2b',
    label: 'Rp1 miliar–Rp2 miliar',
    minPrice: 1_000_000_001,
    maxPrice: 2_000_000_000,
    targetPrice: 1_500_000_000,
    priceRangeLabel: 'Rp1 miliar–Rp2 miliar',
  },
  {
    id: 'above-2b',
    label: 'Di atas Rp2 miliar',
    minPrice: 2_000_000_001,
    maxPrice: '',
    targetPrice: 2_500_000_000,
    priceRangeLabel: 'Di atas Rp2 miliar',
  },
];

export function mapPriceRangeToBounds(rangeId: string): {
  minPrice: number | '';
  maxPrice: number | '';
  targetPrice?: number;
  priceRangeLabel?: string;
} {
  const found = PRICE_RANGE_OPTIONS.find((opt) => opt.id === rangeId);
  if (!found) {
    return { minPrice: '', maxPrice: '', targetPrice: undefined, priceRangeLabel: undefined };
  }
  return {
    minPrice: found.minPrice,
    maxPrice: found.maxPrice,
    targetPrice: found.targetPrice,
    priceRangeLabel: found.priceRangeLabel,
  };
}

export function detectPriceRangeId(
  minPrice: number | '',
  maxPrice: number | ''
): string {
  const match = PRICE_RANGE_OPTIONS.find(
    (opt) => opt.minPrice === minPrice && opt.maxPrice === maxPrice
  );
  return match ? match.id : 'all';
}

/**
 * Formats IDR numbers into human-readable Indonesian format such as
 * "Rp 750 juta" or "Rp 1,98 miliar".
 */
export function formatRupiahRingkas(price: number, pricePeriod?: string): string {
  if (!Number.isFinite(price) || price <= 0) {
    return 'Hubungi Admin';
  }

  let formatted = '';
  if (price >= 1_000_000_000_000) {
    const val = price / 1_000_000_000_000;
    formatted = `Rp ${formatIndonesianDecimal(val)} triliun`;
  } else if (price >= 1_000_000_000) {
    const val = price / 1_000_000_000;
    formatted = `Rp ${formatIndonesianDecimal(val)} miliar`;
  } else if (price >= 1_000_000) {
    const val = price / 1_000_000;
    formatted = `Rp ${formatIndonesianDecimal(val)} juta`;
  } else if (price >= 1_000) {
    const val = price / 1_000;
    formatted = `Rp ${formatIndonesianDecimal(val)} ribu`;
  } else {
    formatted = `Rp ${Math.round(price).toLocaleString('id-ID')}`;
  }

  if (pricePeriod && pricePeriod.trim().length > 0) {
    return `${formatted} / ${pricePeriod.trim().replace(/^per\s+/i, '')}`;
  }
  return formatted;
}

function formatIndonesianDecimal(val: number): string {
  const rounded = Math.round(val * 100) / 100;
  if (Number.isInteger(rounded)) {
    return String(rounded);
  }
  return rounded
    .toFixed(2)
    .replace(/\.?0+$/, '')
    .replace('.', ',');
}

/**
 * Formats full IDR number e.g. "Rp 1.980.000.000"
 */
export function formatRupiahLengkap(price: number): string {
  if (!Number.isFinite(price) || price <= 0) {
    return 'Rp 0';
  }
  return `Rp ${Math.round(price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
}

/**
 * Generates an SEO-friendly slug from title and listing code.
 */
export function generateSlug(title: string, code: string): string {
  const cleanTitle = title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 160);
  const cleanCode = code
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, '')
    .trim();
  if (!cleanTitle) return cleanCode || 'properti-batam';
  if (!cleanCode || cleanTitle.endsWith(cleanCode)) return cleanTitle;
  return `${cleanTitle}-${cleanCode}`;
}

/**
 * Normalizes Indonesian phone number into international WhatsApp format (628...)
 */
export function normalizeWhatsAppNumber(phone: string): string {
  const digits = (phone || '').replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.startsWith('0')) {
    return `62${digits.slice(1)}`;
  }
  if (digits.startsWith('8')) {
    return `62${digits}`;
  }
  return digits;
}

/**
 * Builds a pre-filled WhatsApp chat URL.
 */
export function buildWhatsAppUrl(phone: string, message: string): string {
  const normalized = normalizeWhatsAppNumber(phone);
  const encoded = encodeURIComponent(message);
  if (!normalized) {
    return `https://wa.me/?text=${encoded}`;
  }
  return `https://wa.me/${normalized}?text=${encoded}`;
}

/**
 * Builds an automatic WhatsApp inquiry message containing the listing title and code.
 */
export function buildListingWhatsAppMessage(listing: {
  title: string;
  code: string;
  transactionType: TransactionType;
  area: string;
  price: number;
  pricePeriod?: string;
}): string {
  const harga = formatRupiahRingkas(listing.price, listing.pricePeriod);
  return `Halo Admin BatamProperti.com (PT Cuan Properti), saya tertarik menanyakan informasi lebih lanjut mengenai properti berikut:\n\n• Judul: ${listing.title}\n• Kode Listing: ${listing.code}\n• Status: ${listing.transactionType} (${harga})\n• Area: ${listing.area}\n\nMohon informasi ketersediaan unit. Terima kasih.`;
}

/**
 * Builds a direct WhatsApp Admin message for "Titipkan Properti" containing
 * Nama, Alamat & Blok Rumah, and Deskripsi.
 */
export function buildConsignWhatsAppMessage(payload: {
  ownerName: string;
  blockAddress: string;
  description: string;
}): string {
  const lines = [
    'Halo Admin BatamProperti.com (PT Cuan Properti), saya ingin menitipkan listing properti:',
    '',
    `• Nama: ${payload.ownerName.trim()}`,
    `• Alamat & Blok Rumah: ${payload.blockAddress.trim()}`,
    `• Deskripsi: ${payload.description.trim()}`,
    '',
    'Mohon dibantu proses pemasarannya. Terima kasih.',
  ];
  return lines.join('\n');
}

/**
 * Checks if a listing is considered "Baru" (listed within the last 30 days).
 */
export function isNewListing(listedDate: string, referenceDate?: Date): boolean {
  if (!listedDate) return false;
  const parsed = new Date(listedDate);
  if (Number.isNaN(parsed.getTime())) return false;
  const now = referenceDate || new Date();
  const diffDays = (now.getTime() - parsed.getTime()) / (1000 * 60 * 60 * 24);
  return diffDays >= -2 && diffDays <= 35;
}

/**
 * Checks if a listing belongs to "Properti Baru / Primary".
 * Uses explicit `marketCategory` ('Primary' | 'Secondary') if set, falling back to `isNewListing`.
 */
export function isPrimaryListing(item: PropertyListing): boolean {
  if (item.marketCategory === 'Primary') return true;
  if (item.marketCategory === 'Secondary') return false;
  return isNewListing(item.listedDate);
}

/**
 * Filters and sorts listings for the public catalog or admin view.
 * By default (`includeNonPublic = false`), Draft, Menunggu Review, and Diarsipkan
 * listings are strictly excluded from public results.
 */
export function filterAndSortListings(
  listings: PropertyListing[],
  filters: FilterState,
  includeNonPublic = false
): PropertyListing[] {
  const kw = (filters.keyword || '').trim().toLowerCase();

  const filtered = listings.filter((item) => {
    if (!includeNonPublic && !PUBLIC_VISIBLE_STATUSES.includes(item.status)) {
      return false;
    }

    if (
      filters.transactionType !== 'Semua' &&
      item.transactionType !== filters.transactionType
    ) {
      return false;
    }

    if (
      filters.propertyType !== 'Semua' &&
      item.propertyType !== filters.propertyType
    ) {
      return false;
    }

    if (
      filters.marketCategory &&
      filters.marketCategory !== 'Semua'
    ) {
      const cat = item.marketCategory || 'Secondary';
      if (cat !== filters.marketCategory) {
        return false;
      }
    }

    if (
      filters.area &&
      filters.area !== 'Semua' &&
      item.area.toLowerCase() !== filters.area.toLowerCase()
    ) {
      return false;
    }

    if (filters.minPrice !== '' && item.price < Number(filters.minPrice)) {
      return false;
    }

    if (filters.maxPrice !== '' && item.price > Number(filters.maxPrice)) {
      return false;
    }

    if (filters.minLandArea !== '' && item.landArea < Number(filters.minLandArea)) {
      return false;
    }

    if (
      filters.minBuildingArea !== '' &&
      item.buildingArea < Number(filters.minBuildingArea)
    ) {
      return false;
    }

    if (filters.minBedrooms !== '' && item.bedrooms < Number(filters.minBedrooms)) {
      return false;
    }

    if (
      filters.minBathrooms !== '' &&
      item.bathrooms < Number(filters.minBathrooms)
    ) {
      return false;
    }

    if (filters.onlyFeatured && !item.isFeatured) {
      return false;
    }

    if (filters.onlyNew && !isPrimaryListing(item)) {
      return false;
    }

    if (kw) {
      const searchable = [
        item.code,
        item.title,
        item.area,
        item.complexName || '',
        item.address || '',
        item.propertyType,
        item.marketCategory || '',
        item.description,
      ]
        .join(' ')
        .toLowerCase();
      if (!searchable.includes(kw)) {
        return false;
      }
    }

    return true;
  });

  const sorted = [...filtered];
  sorted.sort((a, b) => {
    if (filters.sortBy === 'harga-terendah') {
      return a.price - b.price;
    }
    if (filters.sortBy === 'harga-tertinggi') {
      return b.price - a.price;
    }
    // Default: 'terbaru'
    const timeA = new Date(a.listedDate || a.createdAt).getTime() || 0;
    const timeB = new Date(b.listedDate || b.createdAt).getTime() || 0;
    return timeB - timeA;
  });

  return sorted;
}

/**
 * Validates admin listing creation / update payload.
 */
export function validateListingInput(
  input: Partial<PropertyListing>,
  existingListings: Array<{ id: string; code: string }>,
  editingId?: string
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  const code = (input.code || '').trim();
  if (!code || code.length < 3 || code.length > 40) {
    errors.push('Kode listing wajib diisi (3–40 karakter, huruf/angka/strip).');
  } else if (!/^[a-zA-Z0-9_-]+$/.test(code)) {
    errors.push('Kode listing hanya boleh berisi huruf, angka, tanda hubung (-), atau garis bawah (_).');
  } else {
    const duplicate = existingListings.find(
      (item) =>
        item.code.toLowerCase() === code.toLowerCase() && item.id !== editingId
    );
    if (duplicate) {
      errors.push(`Kode listing "${code}" sudah digunakan oleh properti lain.`);
    }
  }

  const title = (input.title || '').trim();
  if (!title || title.length < 5 || title.length > 200) {
    errors.push('Judul properti wajib diisi (5–200 karakter).');
  }

  if (typeof input.price !== 'number' || Number.isNaN(input.price) || input.price <= 0) {
    errors.push('Harga properti harus berupa angka lebih dari Rp 0.');
  }

  const area = (input.area || '').trim();
  if (!area || area.length < 2) {
    errors.push('Area / Kecamatan di Batam wajib dipilih.');
  }

  const description = (input.description || '').trim();
  if (!description || description.length < 10 || description.length > 4000) {
    errors.push('Deskripsi properti wajib diisi (minimal 10 karakter, maksimal 4000 karakter).');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates customer inquiry or survey request input.
 */
export function validateInquiryInput(input: Partial<CustomerInquiry>): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  const name = (input.name || '').trim();
  const whatsapp = (input.whatsapp || '').replace(/[^0-9+]/g, '');
  const message = (input.message || '').trim();

  if (!name || name.length < 2 || name.length > 120) {
    errors.push('Nama lengkap wajib diisi (minimal 2 karakter).');
  }
  if (!whatsapp || whatsapp.length < 8 || whatsapp.length > 30) {
    errors.push('Nomor WhatsApp aktif wajib diisi (8–30 digit).');
  }
  if (!message || message.length < 3 || message.length > 2000) {
    errors.push('Pesan atau pertanyaan wajib diisi.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates property owner consignment (Titip Properti) submission.
 */
export function validateSubmissionInput(input: Partial<PropertySubmission>): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  const ownerName = (input.ownerName || '').trim();
  const whatsapp = (input.whatsapp || '').replace(/[^0-9+]/g, '');
  const location = (input.location || '').trim();
  const specifications = (input.specifications || '').trim();
  const description = (input.description || '').trim();

  if (!ownerName || ownerName.length < 2 || ownerName.length > 120) {
    errors.push('Nama pemilik properti wajib diisi.');
  }
  if (!whatsapp || whatsapp.length < 8 || whatsapp.length > 30) {
    errors.push('Nomor WhatsApp pemilik wajib diisi (8–30 digit).');
  }
  if (!location || location.length < 2 || location.length > 200) {
    errors.push('Lokasi / Area properti di Batam wajib diisi.');
  }
  if (
    typeof input.expectedPrice !== 'number' ||
    Number.isNaN(input.expectedPrice) ||
    input.expectedPrice <= 0
  ) {
    errors.push('Harga yang diharapkan wajib diisi dengan angka valid.');
  }
  if (!specifications || specifications.length < 3 || specifications.length > 1000) {
    errors.push('Spesifikasi singkat (LT/LB/KT/KM) wajib diisi.');
  }
  if (!description || description.length < 5 || description.length > 3000) {
    errors.push('Deskripsi properti wajib diisi.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

export const DEFAULT_FILTERS: FilterState = {
  keyword: '',
  transactionType: 'Semua',
  propertyType: 'Semua',
  marketCategory: 'Semua',
  area: 'Semua',
  minPrice: '',
  maxPrice: '',
  minLandArea: '',
  minBuildingArea: '',
  minBedrooms: '',
  minBathrooms: '',
  onlyFeatured: false,
  onlyNew: false,
  sortBy: 'terbaru',
};

/**
 * Computes total engagement score of a property listing based on detail views and WhatsApp clicks.
 * WhatsApp clicks have 2x weight since they represent direct lead intent.
 */
export function getListingEngagementScore(listing: PropertyListing): number {
  const views = Math.max(0, Number(listing.viewsCount) || 0);
  const waClicks = Math.max(0, Number(listing.waClicksCount) || 0);
  return views + waClicks * 2;
}

/**
 * Returns the most popular / most clicked listings sorted by total engagement score.
 */
export function getPopularListings(
  listings: PropertyListing[],
  limit = 6,
  includeNonPublic = false
): PropertyListing[] {
  const pool = includeNonPublic
    ? listings
    : listings.filter((item) => PUBLIC_VISIBLE_STATUSES.includes(item.status));

  return [...pool]
    .sort((a, b) => {
      const scoreDiff = getListingEngagementScore(b) - getListingEngagementScore(a);
      if (scoreDiff !== 0) return scoreDiff;
      const viewsDiff = (b.viewsCount || 0) - (a.viewsCount || 0);
      if (viewsDiff !== 0) return viewsDiff;
      return b.price - a.price;
    })
    .slice(0, limit);
}

/**
 * Extracts a structured UserPreferenceProfile update from search/filter inputs or keyword (e.g., "500 juta").
 */
export function deriveUserPreferenceFromSearch(
  current: UserPreferenceProfile,
  input: Partial<FilterState> & {
    priceRangeLabel?: string;
    targetPrice?: number;
  }
): UserPreferenceProfile {
  const next: UserPreferenceProfile = {
    ...current,
    updatedAt: new Date().toISOString(),
  };

  if (input.area && input.area !== 'Semua') {
    next.preferredArea = input.area;
  } else if (input.area === 'Semua') {
    next.preferredArea = undefined;
  }

  if (input.propertyType && input.propertyType !== 'Semua') {
    next.preferredPropertyType = input.propertyType;
  } else if (input.propertyType === 'Semua') {
    next.preferredPropertyType = undefined;
  }

  if (input.transactionType && input.transactionType !== 'Semua') {
    next.preferredTransactionType = input.transactionType;
  } else if (input.transactionType === 'Semua') {
    next.preferredTransactionType = undefined;
  }

  if (typeof input.keyword === 'string') {
    const kw = input.keyword.trim();
    next.lastKeyword = kw || undefined;

    // Detect if user typed a budget in keyword like "500 juta", "500jt", "1.5 miliar", "1,5m"
    const jtMatch = kw.match(/(\d+(?:[.,]\d+)?)\s*(juta|jt)\b/i);
    const mMatch = kw.match(/(\d+(?:[.,]\d+)?)\s*(miliar|milyar|m)\b/i);
    if (jtMatch) {
      const num = parseFloat(jtMatch[1].replace(',', '.'));
      if (Number.isFinite(num) && num > 0) {
        next.targetPrice = Math.round(num * 1_000_000);
        next.priceRangeLabel =
          next.targetPrice <= 500_000_000
            ? 'Di bawah Rp500 juta'
            : `Sekitar Rp ${jtMatch[1]} Juta`;
      }
    } else if (mMatch) {
      const num = parseFloat(mMatch[1].replace(',', '.'));
      if (Number.isFinite(num) && num > 0) {
        next.targetPrice = Math.round(num * 1_000_000_000);
        next.priceRangeLabel = `Sekitar Rp ${mMatch[1]} Miliar`;
      }
    }
  }

  if (input.minPrice !== undefined || input.maxPrice !== undefined) {
    const minP =
      input.minPrice !== '' && input.minPrice !== undefined
        ? Number(input.minPrice)
        : '';
    const maxP =
      input.maxPrice !== '' && input.maxPrice !== undefined
        ? Number(input.maxPrice)
        : '';
    next.minPrice = minP;
    next.maxPrice = maxP;

    const matchedPreset = PRICE_RANGE_OPTIONS.find(
      (opt) => opt.minPrice === minP && opt.maxPrice === maxP
    );

    if (matchedPreset) {
      next.targetPrice = matchedPreset.targetPrice;
      next.priceRangeLabel = matchedPreset.priceRangeLabel;
    } else if (typeof minP === 'number' && typeof maxP === 'number') {
      next.targetPrice = Math.round((minP + maxP) / 2);
      next.priceRangeLabel = `${formatRupiahRingkas(minP)} – ${formatRupiahRingkas(maxP)}`;
    } else if (typeof maxP === 'number') {
      next.targetPrice = maxP;
      next.priceRangeLabel =
        maxP === 500_000_000
          ? 'Di bawah Rp500 juta'
          : `Maksimal ${formatRupiahRingkas(maxP)}`;
    } else if (typeof minP === 'number') {
      next.targetPrice = minP;
      next.priceRangeLabel =
        minP >= 2_000_000_000
          ? 'Di atas Rp2 miliar'
          : `Mulai ${formatRupiahRingkas(minP)}`;
    } else if (minP === '' && maxP === '' && !input.targetPrice) {
      next.targetPrice = undefined;
      next.priceRangeLabel = undefined;
    }
  }

  if (typeof input.targetPrice === 'number' && input.targetPrice > 0) {
    next.targetPrice = input.targetPrice;
  }

  if (input.priceRangeLabel) {
    next.priceRangeLabel = input.priceRangeLabel;
  }

  return next;
}

/**
 * Smart Recommendation Engine ("Membaca Kemauan User + Properti Ramai"):
 * - Reads user preferences (targetPrice e.g. 500 juta, min/max price, preferred area, property type, viewed items)
 * - Matches listings within or near their desired price rate (e.g., < 500 juta, Rp500 - 1 M, > 1 M - 2 M, > 2 Miliar) & criteria
 * - Blends in the most popular / most-clicked listings ("Ramai & Terklik Terbanyak") so the user gets both tailored matches and high-demand options.
 */
export function getSmartRecommendations(
  listings: PropertyListing[],
  prefs: UserPreferenceProfile | null,
  limit = 6
): {
  matched: RecommendedListingItem[];
  popular: RecommendedListingItem[];
  combined: RecommendedListingItem[];
  activeIntentSummary: string | null;
} {
  const publicPool = listings.filter((item) =>
    PUBLIC_VISIBLE_STATUSES.includes(item.status)
  );

  const popularRaw = getPopularListings(publicPool, limit);
  const popular: RecommendedListingItem[] = popularRaw.map((item, idx) => ({
    listing: item,
    reasonBadge:
      idx === 0
        ? `Paling Ramai (${(item.viewsCount || 0) + (item.waClicksCount || 0)}x Diklik)`
        : `Populer · ${(item.viewsCount || 0) + (item.waClicksCount || 0)}x Diklik`,
    matchType: 'popular',
    engagementScore: getListingEngagementScore(item),
  }));

  if (!prefs) {
    return {
      matched: [],
      popular,
      combined: popular.slice(0, limit),
      activeIntentSummary: null,
    };
  }

  const hasPriceIntent =
    (typeof prefs.targetPrice === 'number' && prefs.targetPrice > 0) ||
    (typeof prefs.minPrice === 'number' && prefs.minPrice > 0) ||
    (typeof prefs.maxPrice === 'number' && prefs.maxPrice > 0);
  const hasAreaIntent = Boolean(
    prefs.preferredArea && prefs.preferredArea !== 'Semua'
  );
  const hasTypeIntent = Boolean(
    prefs.preferredPropertyType && prefs.preferredPropertyType !== 'Semua'
  );
  const hasTransIntent = Boolean(
    prefs.preferredTransactionType && prefs.preferredTransactionType !== 'Semua'
  );
  const hasViewedIntent =
    Array.isArray(prefs.viewedListingIds) && prefs.viewedListingIds.length > 0;

  if (
    !hasPriceIntent &&
    !hasAreaIntent &&
    !hasTypeIntent &&
    !hasTransIntent &&
    !hasViewedIntent
  ) {
    return {
      matched: [],
      popular,
      combined: popular.slice(0, limit),
      activeIntentSummary: null,
    };
  }

  // Build human-readable summary of what the system detected from the user
  const summaryParts: string[] = [];
  if (prefs.priceRangeLabel) {
    summaryParts.push(prefs.priceRangeLabel);
  } else if (typeof prefs.targetPrice === 'number' && prefs.targetPrice > 0) {
    summaryParts.push(`Rate ~${formatRupiahRingkas(prefs.targetPrice)}`);
  }
  if (hasTypeIntent && prefs.preferredPropertyType) {
    summaryParts.push(`Jenis: ${prefs.preferredPropertyType}`);
  }
  if (hasAreaIntent && prefs.preferredArea) {
    summaryParts.push(`Area: ${prefs.preferredArea}`);
  }
  if (hasTransIntent && prefs.preferredTransactionType) {
    summaryParts.push(`Status: ${prefs.preferredTransactionType}`);
  }

  const activeIntentSummary =
    summaryParts.length > 0
      ? summaryParts.join(' · ')
      : 'Riwayat Properti yang Anda Lihat';

  // Determine effective target price
  let effectiveTargetPrice = prefs.targetPrice;
  if (!effectiveTargetPrice) {
    if (typeof prefs.minPrice === 'number' && typeof prefs.maxPrice === 'number') {
      effectiveTargetPrice = Math.round((prefs.minPrice + prefs.maxPrice) / 2);
    } else if (typeof prefs.maxPrice === 'number') {
      effectiveTargetPrice = prefs.maxPrice;
    } else if (typeof prefs.minPrice === 'number') {
      effectiveTargetPrice = prefs.minPrice;
    }
  }

  // Score each listing for relevance to user preferences
  const scoredCandidates: Array<{
    listing: PropertyListing;
    relevanceScore: number;
    reasonBadge: string;
    matchType: 'budget' | 'preference';
    priceDistanceRatio: number;
  }> = [];

  for (const item of publicPool) {
    let relevanceScore = 0;
    let reasonBadge = '';
    let matchType: 'budget' | 'preference' = 'preference';
    let priceDistanceRatio = 999;

    if (
      hasTransIntent &&
      prefs.preferredTransactionType &&
      item.transactionType === prefs.preferredTransactionType
    ) {
      relevanceScore += 15;
    }

    if (hasPriceIntent && effectiveTargetPrice && effectiveTargetPrice > 0) {
      const diff = Math.abs(item.price - effectiveTargetPrice);
      priceDistanceRatio = diff / effectiveTargetPrice;

      const withinExplicitRange =
        (typeof prefs.minPrice !== 'number' || item.price >= prefs.minPrice) &&
        (typeof prefs.maxPrice !== 'number' || item.price <= prefs.maxPrice);

      if (withinExplicitRange && (prefs.minPrice !== '' || prefs.maxPrice !== '')) {
        relevanceScore += 60;
        matchType = 'budget';
        reasonBadge = prefs.priceRangeLabel
          ? `Sesuai ${prefs.priceRangeLabel}`
          : `Sesuai Budget ~${formatRupiahRingkas(effectiveTargetPrice)}`;
      } else if (priceDistanceRatio <= 0.35) {
        relevanceScore += 55 - Math.round(priceDistanceRatio * 40);
        matchType = 'budget';
        reasonBadge = prefs.priceRangeLabel
          ? `Cocok (${prefs.priceRangeLabel})`
          : `Cocok Rate ~${formatRupiahRingkas(effectiveTargetPrice)}`;
      } else if (priceDistanceRatio <= 0.55) {
        relevanceScore += 30 - Math.round(priceDistanceRatio * 20);
        matchType = 'budget';
        reasonBadge = `Mendekati Budget ${formatRupiahRingkas(effectiveTargetPrice)}`;
      }
    }

    if (
      hasAreaIntent &&
      prefs.preferredArea &&
      item.area.toLowerCase() === prefs.preferredArea.toLowerCase()
    ) {
      relevanceScore += 35;
      if (!reasonBadge) {
        reasonBadge = `Sesuai Area ${item.area}`;
      } else {
        reasonBadge = `${reasonBadge} · ${item.area}`;
      }
    }

    if (
      hasTypeIntent &&
      prefs.preferredPropertyType &&
      item.propertyType === prefs.preferredPropertyType
    ) {
      relevanceScore += 30;
      if (!reasonBadge) {
        reasonBadge = `Sesuai Pilihan ${item.propertyType}`;
      }
    }

    if (relevanceScore > 0) {
      scoredCandidates.push({
        listing: item,
        relevanceScore,
        reasonBadge: reasonBadge || 'Sesuai Preferensi Anda',
        matchType,
        priceDistanceRatio,
      });
    }
  }

  scoredCandidates.sort((a, b) => {
    if (b.relevanceScore !== a.relevanceScore) {
      return b.relevanceScore - a.relevanceScore;
    }
    if (a.priceDistanceRatio !== b.priceDistanceRatio) {
      return a.priceDistanceRatio - b.priceDistanceRatio;
    }
    return getListingEngagementScore(b.listing) - getListingEngagementScore(a.listing);
  });

  const matched: RecommendedListingItem[] = scoredCandidates
    .slice(0, limit)
    .map((c) => ({
      listing: c.listing,
      reasonBadge: c.reasonBadge,
      matchType: c.matchType,
      engagementScore: getListingEngagementScore(c.listing),
    }));

  // Combine matched properties + popular properties without duplicates
  // Ensure at least 2 popular ("ramai") listings are blended in when limit >= 4 so the user sees both matched AND popular items
  const combined: RecommendedListingItem[] = [];
  const usedIds = new Set<string>();

  const maxMatchedSlots = Math.max(2, limit - 2);
  for (const m of matched.slice(0, maxMatchedSlots)) {
    if (!usedIds.has(m.listing.id)) {
      usedIds.add(m.listing.id);
      combined.push(m);
    }
  }

  for (const p of popular) {
    if (combined.length >= limit) break;
    if (!usedIds.has(p.listing.id)) {
      usedIds.add(p.listing.id);
      combined.push(p);
    }
  }

  // If still under limit, fill with remaining matched items
  for (const m of matched) {
    if (combined.length >= limit) break;
    if (!usedIds.has(m.listing.id)) {
      usedIds.add(m.listing.id);
      combined.push(m);
    }
  }

  return {
    matched,
    popular,
    combined,
    activeIntentSummary,
  };
}
