import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatRupiahRingkas,
  formatRupiahLengkap,
  generateSlug,
  buildWhatsAppUrl,
  buildListingWhatsAppMessage,
  buildConsignWhatsAppMessage,
  filterAndSortListings,
  validateListingInput,
  validateInquiryInput,
  validateSubmissionInput,
  getPopularListings,
  deriveUserPreferenceFromSearch,
  getSmartRecommendations,
  PRICE_RANGE_OPTIONS,
  mapPriceRangeToBounds,
  DEFAULT_FILTERS,
} from './propertyLogic';
import { DEMO_LISTINGS } from '../data/demoData';

test('formatRupiahRingkas formats millions and billions in clear Indonesian Rupiah format', () => {
  assert.equal(formatRupiahRingkas(750_000_000), 'Rp 750 juta');
  assert.equal(formatRupiahRingkas(1_980_000_000), 'Rp 1,98 miliar');
  assert.equal(formatRupiahRingkas(3_450_000_000), 'Rp 3,45 miliar');
  assert.equal(formatRupiahRingkas(85_000_000, 'tahun'), 'Rp 85 juta / tahun');
});

test('formatRupiahLengkap formats full numbers with dot separators', () => {
  assert.equal(formatRupiahLengkap(1_980_000_000), 'Rp 1.980.000.000');
  assert.equal(formatRupiahLengkap(750_000_000), 'Rp 750.000.000');
});

test('generateSlug produces search-friendly URLs including listing code', () => {
  const slug = generateSlug('Rumah 2 Lantai Modern di Batam Center!', 'BP-BTM-001');
  assert.equal(slug, 'rumah-2-lantai-modern-di-batam-center-bp-btm-001');
});

test('buildWhatsAppUrl and buildListingWhatsAppMessage include title and listing code', () => {
  const msg = buildListingWhatsAppMessage({
    title: 'Rumah 2 Lantai Batam Center',
    code: 'BP-BTM-001',
    transactionType: 'Dijual',
    area: 'Batam Center',
    price: 1_980_000_000,
  });
  assert.ok(msg.includes('Rumah 2 Lantai Batam Center'));
  assert.ok(msg.includes('BP-BTM-001'));
  const url = buildWhatsAppUrl('081270008988', msg);
  assert.ok(url.startsWith('https://wa.me/6281270008988?text='));
});

test('buildConsignWhatsAppMessage includes Nama, Alamat & Blok Rumah, and Deskripsi for direct WA Admin', () => {
  const msg = buildConsignWhatsAppMessage({
    ownerName: 'Hendra Wijaya',
    blockAddress: 'Cluster Harmoni Sukajadi Blok B No. 12, Batam Center',
    description: 'Rumah 2 lantai, 4 kamar tidur, kondisi siap huni.',
  });
  assert.ok(msg.includes('Nama: Hendra Wijaya'));
  assert.ok(msg.includes('Alamat & Blok Rumah: Cluster Harmoni Sukajadi Blok B No. 12, Batam Center'));
  assert.ok(msg.includes('Deskripsi: Rumah 2 lantai, 4 kamar tidur, kondisi siap huni.'));
});

test('filterAndSortListings excludes Draft and Menunggu Review listings from public catalog', () => {
  const publicResults = filterAndSortListings(DEMO_LISTINGS, DEFAULT_FILTERS, false);
  // BP-BTM-007 has status 'Menunggu Review', so it must NOT appear in publicResults
  assert.equal(
    publicResults.some((item) => item.code === 'BP-BTM-007'),
    false
  );
  // Admin view (includeNonPublic = true) includes BP-BTM-007
  const adminResults = filterAndSortListings(DEMO_LISTINGS, DEFAULT_FILTERS, true);
  assert.equal(
    adminResults.some((item) => item.code === 'BP-BTM-007'),
    true
  );
});

test('filterAndSortListings filters by area, transactionType, propertyType, and sorts by price', () => {
  const filtered = filterAndSortListings(
    DEMO_LISTINGS,
    {
      ...DEFAULT_FILTERS,
      transactionType: 'Dijual',
      area: 'Pasir Putih',
    },
    false
  );
  assert.equal(filtered.length, 1);
  assert.equal(filtered[0].code, 'BP-BTM-004');

  const sortedLow = filterAndSortListings(
    DEMO_LISTINGS,
    { ...DEFAULT_FILTERS, sortBy: 'harga-terendah' },
    false
  );
  assert.ok(sortedLow[0].price <= sortedLow[1].price);

  const sortedHigh = filterAndSortListings(
    DEMO_LISTINGS,
    { ...DEFAULT_FILTERS, sortBy: 'harga-tertinggi' },
    false
  );
  assert.ok(sortedHigh[0].price >= sortedHigh[1].price);
});

test('validateListingInput enforces unique listing code and required fields', () => {
  const existing = [{ id: '1', code: 'BP-BTM-001' }];
  const dupCheck = validateListingInput(
    {
      code: 'bp-btm-001',
      title: 'Rumah Baru Batam Center',
      price: 900_000_000,
      area: 'Batam Center',
      description: 'Deskripsi lengkap rumah baru di Batam Center.',
    },
    existing
  );
  assert.equal(dupCheck.valid, false);
  assert.ok(dupCheck.errors.some((e) => e.includes('sudah digunakan')));

  // Editing the same listing ID with its own code is valid
  const sameIdCheck = validateListingInput(
    {
      code: 'BP-BTM-001',
      title: 'Rumah Baru Batam Center',
      price: 900_000_000,
      area: 'Batam Center',
      description: 'Deskripsi lengkap rumah baru di Batam Center.',
    },
    existing,
    '1'
  );
  assert.equal(sameIdCheck.valid, true);
});

test('validateInquiryInput and validateSubmissionInput reject empty required fields', () => {
  const badInquiry = validateInquiryInput({ name: 'A', whatsapp: '123', message: '' });
  assert.equal(badInquiry.valid, false);

  const goodInquiry = validateInquiryInput({
    name: 'Andi Pratama',
    whatsapp: '081234567890',
    message: 'Ingin jadwalkan survei hari Sabtu.',
  });
  assert.equal(goodInquiry.valid, true);

  const badSubmission = validateSubmissionInput({
    ownerName: '',
    whatsapp: '123',
    location: '',
    expectedPrice: 0,
    specifications: '',
    description: '',
  });
  assert.equal(badSubmission.valid, false);
});

test('getPopularListings ranks properties by viewsCount and waClicksCount', () => {
  const popular = getPopularListings(DEMO_LISTINGS, 3, false);
  assert.equal(popular.length, 3);
  // BP-BTM-001 has 148 views + 42*2 WA clicks = 232 score, highest among DEMO_LISTINGS
  assert.equal(popular[0].code, 'BP-BTM-001');
  assert.equal(popular[1].code, 'BP-BTM-008');
});

test('PRICE_RANGE_OPTIONS defines exact 4 price ranges (Di bawah Rp500 juta, Rp500 juta–Rp1 miliar, Rp1 miliar–Rp2 miliar, Di atas Rp2 miliar)', () => {
  assert.deepEqual(
    PRICE_RANGE_OPTIONS.map((o) => o.label),
    [
      'Di bawah Rp500 juta',
      'Rp500 juta–Rp1 miliar',
      'Rp1 miliar–Rp2 miliar',
      'Di atas Rp2 miliar',
    ]
  );

  const under500 = mapPriceRangeToBounds('under-500m');
  assert.equal(under500.maxPrice, 500_000_000);
  assert.equal(under500.priceRangeLabel, 'Di bawah Rp500 juta');

  const r500to1b = mapPriceRangeToBounds('500m-1b');
  assert.equal(r500to1b.minPrice, 500_000_000);
  assert.equal(r500to1b.maxPrice, 1_000_000_000);
  assert.equal(r500to1b.priceRangeLabel, 'Rp500 juta–Rp1 miliar');

  const r1bto2b = mapPriceRangeToBounds('1b-2b');
  assert.equal(r1bto2b.minPrice, 1_000_000_001);
  assert.equal(r1bto2b.maxPrice, 2_000_000_000);
  assert.equal(r1bto2b.priceRangeLabel, 'Rp1 miliar–Rp2 miliar');

  const above2b = mapPriceRangeToBounds('above-2b');
  assert.equal(above2b.minPrice, 2_000_000_001);
  assert.equal(above2b.maxPrice, '');
  assert.equal(above2b.priceRangeLabel, 'Di atas Rp2 miliar');
});

test('getSmartRecommendations reads user Di bawah Rp500 juta intent and suggests matching ~500 juta properties plus popular items', () => {
  const bounds = mapPriceRangeToBounds('under-500m');
  const prefs = deriveUserPreferenceFromSearch(
    { viewedListingIds: [], updatedAt: new Date().toISOString() },
    bounds
  );

  const result = getSmartRecommendations(DEMO_LISTINGS, prefs, 6);
  assert.equal(result.activeIntentSummary, 'Di bawah Rp500 juta');
  assert.ok(result.matched.length >= 2);
  // Should prioritize BP-BTM-008 (Rp 495 juta) and BP-BTM-009 (Rp 535 juta)
  const matchedCodes = result.matched.map((m) => m.listing.code);
  assert.ok(matchedCodes.includes('BP-BTM-008'));
  assert.ok(matchedCodes.includes('BP-BTM-009'));
  // Combined result should also include popular items like BP-BTM-001
  const combinedCodes = result.combined.map((c) => c.listing.code);
  assert.ok(combinedCodes.includes('BP-BTM-008'));
  assert.ok(combinedCodes.includes('BP-BTM-001'));
});

test('filterAndSortListings filters by Primary and Secondary marketCategory and onlyNew', () => {
  const primaryResults = filterAndSortListings(
    DEMO_LISTINGS,
    { ...DEFAULT_FILTERS, marketCategory: 'Primary' },
    false
  );
  assert.ok(primaryResults.length > 0);
  assert.ok(primaryResults.every((item) => item.marketCategory === 'Primary'));

  const secondaryResults = filterAndSortListings(
    DEMO_LISTINGS,
    { ...DEFAULT_FILTERS, marketCategory: 'Secondary' },
    false
  );
  assert.ok(secondaryResults.length > 0);
  assert.ok(secondaryResults.every((item) => item.marketCategory === 'Secondary'));

  const onlyNewResults = filterAndSortListings(
    DEMO_LISTINGS,
    { ...DEFAULT_FILTERS, onlyNew: true },
    false
  );
  assert.deepEqual(
    onlyNewResults.map((i) => i.code),
    primaryResults.map((i) => i.code)
  );
});

