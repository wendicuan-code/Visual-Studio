import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  auth,
  db,
  firebaseProjectInfo,
  handleFirestoreError,
  signInAdminWithGoogle,
  signOutAdmin,
  testFirestoreConnection,
} from '../lib/firebase';
import {
  DEMO_INQUIRIES,
  DEMO_LISTINGS,
  DEMO_SUBMISSIONS,
  INITIAL_SITE_SETTINGS,
} from '../data/demoData';
import {
  CustomerInquiry,
  FilterState,
  LeadStatus,
  OperationType,
  PropertyListing,
  PropertySubmission,
  SiteSettings,
  UserPreferenceProfile,
} from '../types/property';
import {
  deriveUserPreferenceFromSearch,
  formatRupiahRingkas,
  generateSlug,
  PUBLIC_VISIBLE_STATUSES,
} from '../utils/propertyLogic';

interface AdminSession {
  email: string;
  name: string;
  mode: 'firebase' | 'setup-token';
  token?: string;
}

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

interface PropertyContextValue {
  listings: PropertyListing[];
  publicListings: PropertyListing[];
  inquiries: CustomerInquiry[];
  submissions: PropertySubmission[];
  settings: SiteSettings;
  favorites: string[];
  visitorInquiries: CustomerInquiry[];
  isAdmin: boolean;
  adminSession: AdminSession | null;
  firestoreConnected: boolean;
  firebaseProjectInfo: typeof firebaseProjectInfo;
  loading: boolean;
  toast: ToastMessage | null;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  clearToast: () => void;
  toggleFavorite: (listingId: string) => void;
  loginAdminGoogle: () => Promise<{ ok: boolean; error?: string }>;
  loginAdminWithToken: (setupToken: string) => Promise<{ ok: boolean; error?: string }>;
  logoutAdmin: () => Promise<void>;
  createListing: (input: Partial<PropertyListing>) => Promise<{ ok: boolean; error?: string; listing?: PropertyListing }>;
  updateListing: (id: string, input: Partial<PropertyListing>) => Promise<{ ok: boolean; error?: string }>;
  deleteListing: (id: string) => Promise<{ ok: boolean; error?: string }>;
  clearDemoListings: () => Promise<void>;
  restoreDemoListings: () => Promise<void>;
  submitInquiry: (input: Partial<CustomerInquiry>) => Promise<{ ok: boolean; error?: string }>;
  updateInquiryAdmin: (id: string, status: LeadStatus, internalNotes: string) => Promise<void>;
  submitPropertyConsignment: (input: Partial<PropertySubmission>) => Promise<{ ok: boolean; error?: string }>;
  updateSubmissionAdmin: (id: string, leadStatus: LeadStatus, internalNotes: string) => Promise<void>;
  convertSubmissionToListing: (submission: PropertySubmission) => Promise<{ ok: boolean; code?: string }>;
  updateSiteSettings: (nextSettings: Partial<SiteSettings>) => Promise<{ ok: boolean; error?: string }>;
  updateSeoMeta: (title: string, description: string) => void;
  userPreferences: UserPreferenceProfile;
  recordListingInteraction: (listing: PropertyListing, type: 'view' | 'wa_click') => void;
  recordUserSearchIntent: (
    input: Partial<FilterState> & { priceRangeLabel?: string; targetPrice?: number }
  ) => void;
  resetUserPreferences: () => void;
}

const PropertyContext = createContext<PropertyContextValue | undefined>(undefined);

const FAVORITES_STORAGE_KEY = 'batamproperti_favorites_v1';
const VISITOR_INQUIRIES_KEY = 'batamproperti_visitor_inquiries_v1';
const ADMIN_SESSION_STORAGE_KEY = 'batamproperti_admin_session_v1';
const USER_PREFS_STORAGE_KEY = 'batamproperti_user_prefs_v1';

const INITIAL_USER_PREFS: UserPreferenceProfile = {
  viewedListingIds: [],
  updatedAt: new Date().toISOString(),
};

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [listings, setListings] = useState<PropertyListing[]>(DEMO_LISTINGS);
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>(DEMO_INQUIRIES);
  const [submissions, setSubmissions] = useState<PropertySubmission[]>(DEMO_SUBMISSIONS);
  const [settings, setSettings] = useState<SiteSettings>(INITIAL_SITE_SETTINGS);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [visitorInquiries, setVisitorInquiries] = useState<CustomerInquiry[]>(() => {
    try {
      const saved = localStorage.getItem(VISITOR_INQUIRIES_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [adminSession, setAdminSession] = useState<AdminSession | null>(() => {
    try {
      const saved = localStorage.getItem(ADMIN_SESSION_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [userPreferences, setUserPreferences] = useState<UserPreferenceProfile>(() => {
    try {
      const saved = localStorage.getItem(USER_PREFS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_USER_PREFS,
          ...parsed,
          viewedListingIds: Array.isArray(parsed.viewedListingIds)
            ? parsed.viewedListingIds
            : [],
        };
      }
      return INITIAL_USER_PREFS;
    } catch {
      return INITIAL_USER_PREFS;
    }
  });
  const [firestoreConnected, setFirestoreConnected] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = useCallback(
    (text: string, type: 'success' | 'error' | 'info' = 'success') => {
      setToast({ id: String(Date.now()), text, type });
    },
    []
  );

  const clearToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(timer);
  }, [toast]);

  const isAdmin = Boolean(adminSession);

  const getAdminHeaders = useCallback((): Record<string, string> => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (adminSession?.token) {
      headers['x-admin-token'] = adminSession.token;
    } else if (adminSession?.mode === 'firebase') {
      headers['x-admin-token'] = 'FIREBASE_VERIFIED_ADMIN';
    }
    if (adminSession?.email) {
      headers['x-admin-email'] = adminSession.email;
    }
    return headers;
  }, [adminSession]);

  // Fetch initial state from Express backend + verify Firestore connection
  const fetchState = useCallback(async () => {
    try {
      const res = await fetch('/api/state', {
        headers: getAdminHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.listings)) setListings(data.listings);
        if (data.settings) setSettings(data.settings);
        if (Array.isArray(data.inquiries)) setInquiries(data.inquiries);
        if (Array.isArray(data.submissions)) setSubmissions(data.submissions);
      }
    } catch (err) {
      console.error('Error fetching state from server:', err);
    } finally {
      setLoading(false);
    }
  }, [getAdminHeaders]);

  useEffect(() => {
    fetchState();
    testFirestoreConnection().then((connected) => {
      setFirestoreConnected(connected);
    });
  }, [fetchState]);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user && user.email) {
        try {
          const verifyRes = await fetch('/api/admin/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: user.email }),
          });
          if (verifyRes.ok) {
            const session: AdminSession = {
              email: user.email,
              name: user.displayName || 'Administrator BatamProperti',
              mode: 'firebase',
              token: 'FIREBASE_VERIFIED_ADMIN',
            };
            setAdminSession(session);
            localStorage.setItem(ADMIN_SESSION_STORAGE_KEY, JSON.stringify(session));
          }
        } catch {
          // Ignore verification network error
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const toggleFavorite = useCallback(
    (listingId: string) => {
      setFavorites((prev) => {
        const exists = prev.includes(listingId);
        const next = exists
          ? prev.filter((id) => id !== listingId)
          : [...prev, listingId];
        try {
          localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
        } catch {
          // Ignore storage error
        }
        showToast(
          exists
            ? 'Properti dihapus dari daftar Favorit.'
            : 'Properti disimpan ke daftar Favorit.',
          'info'
        );
        return next;
      });
    },
    [showToast]
  );

  const loginAdminGoogle = useCallback(async (): Promise<{
    ok: boolean;
    error?: string;
  }> => {
    try {
      const user = await signInAdminWithGoogle();
      if (!user.email) {
        await signOutAdmin();
        return { ok: false, error: 'Akun Google tidak memiliki alamat email terverifikasi.' };
      }
      const verifyRes = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user.email }),
      });
      if (!verifyRes.ok) {
        await signOutAdmin();
        return {
          ok: false,
          error: `Email ${user.email} belum terdaftar sebagai Administrator PT Cuan Properti.`,
        };
      }
      const session: AdminSession = {
        email: user.email,
        name: user.displayName || 'Administrator BatamProperti',
        mode: 'firebase',
        token: 'FIREBASE_VERIFIED_ADMIN',
      };
      setAdminSession(session);
      localStorage.setItem(ADMIN_SESSION_STORAGE_KEY, JSON.stringify(session));
      showToast('Berhasil masuk ke Dashboard Admin menggunakan Google Auth.');
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        error:
          err instanceof Error
            ? `Gagal login Google: ${err.message}`
            : 'Gagal melakukan autentikasi Google.',
      };
    }
  }, [showToast]);

  const loginAdminWithToken = useCallback(
    async (setupToken: string): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch('/api/admin/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ setupToken }),
        });
        const data = await res.json();
        if (!res.ok || !data.authorized) {
          return {
            ok: false,
            error: data.error || 'Token setup admin tidak valid.',
          };
        }
        const session: AdminSession = {
          email: data.email || 'properti988@gmail.com',
          name: 'Admin PT Cuan Properti',
          mode: 'setup-token',
          token: setupToken.trim(),
        };
        setAdminSession(session);
        localStorage.setItem(ADMIN_SESSION_STORAGE_KEY, JSON.stringify(session));
        showToast('Berhasil masuk ke Dashboard Admin.');
        return { ok: true };
      } catch {
        return { ok: false, error: 'Gagal menghubungi server verifikasi admin.' };
      }
    },
    [showToast]
  );

  const logoutAdmin = useCallback(async () => {
    try {
      await signOutAdmin();
    } catch {
      // Ignore if not signed into Firebase
    }
    setAdminSession(null);
    localStorage.removeItem(ADMIN_SESSION_STORAGE_KEY);
    showToast('Anda telah keluar dari sesi Administrator.', 'info');
  }, [showToast]);

  const createListing = useCallback(
    async (
      input: Partial<PropertyListing>
    ): Promise<{ ok: boolean; error?: string; listing?: PropertyListing }> => {
      try {
        const res = await fetch('/api/listings', {
          method: 'POST',
          headers: getAdminHeaders(),
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || 'Gagal menyimpan listing.' };
        }
        const created: PropertyListing = data.listing;
        setListings((prev) => [created, ...prev]);

        // Sync to Firestore if authenticated with Firebase Admin
        if (auth.currentUser) {
          try {
            await setDoc(doc(db, 'listings', created.id), {
              ...created,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } catch (fsErr) {
            handleFirestoreError(fsErr, OperationType.CREATE, `listings/${created.id}`);
          }
        }

        showToast(`Listing ${created.code} berhasil ditambahkan.`);
        return { ok: true, listing: created };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : 'Gagal membuat listing.',
        };
      }
    },
    [getAdminHeaders, showToast]
  );

  const updateListing = useCallback(
    async (
      id: string,
      input: Partial<PropertyListing>
    ): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch(`/api/listings/${id}`, {
          method: 'PUT',
          headers: getAdminHeaders(),
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || 'Gagal memperbarui listing.' };
        }
        const updated: PropertyListing = data.listing;
        setListings((prev) => prev.map((item) => (item.id === id ? updated : item)));

        if (auth.currentUser) {
          try {
            await setDoc(doc(db, 'listings', updated.id), {
              ...updated,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } catch (fsErr) {
            handleFirestoreError(fsErr, OperationType.UPDATE, `listings/${updated.id}`);
          }
        }

        showToast(`Perubahan pada listing ${updated.code} berhasil disimpan.`);
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : 'Gagal memperbarui listing.',
        };
      }
    },
    [getAdminHeaders, showToast]
  );

  const deleteListing = useCallback(
    async (id: string): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch(`/api/listings/${id}`, {
          method: 'DELETE',
          headers: getAdminHeaders(),
        });
        if (!res.ok) {
          const data = await res.json();
          return { ok: false, error: data.error || 'Gagal menghapus listing.' };
        }
        setListings((prev) => prev.filter((item) => item.id !== id));

        if (auth.currentUser) {
          try {
            await deleteDoc(doc(db, 'listings', id));
          } catch (fsErr) {
            handleFirestoreError(fsErr, OperationType.DELETE, `listings/${id}`);
          }
        }

        showToast('Listing properti telah dihapus.', 'info');
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : 'Gagal menghapus listing.',
        };
      }
    },
    [getAdminHeaders, showToast]
  );

  const clearDemoListings = useCallback(async () => {
    const res = await fetch('/api/listings/clear-demo', {
      method: 'DELETE',
      headers: getAdminHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      setListings(data.listings);
      showToast('Seluruh Contoh Listing demonstrasi telah dihapus.');
    }
  }, [getAdminHeaders, showToast]);

  const restoreDemoListings = useCallback(async () => {
    const res = await fetch('/api/listings/restore-demo', {
      method: 'DELETE',
      headers: getAdminHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      setListings(data.listings);
      showToast('Contoh Listing demonstrasi berhasil dipulihkan.');
    }
  }, [getAdminHeaders, showToast]);

  const submitInquiry = useCallback(
    async (
      input: Partial<CustomerInquiry>
    ): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch('/api/inquiries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || 'Gagal mengirim permintaan.' };
        }
        const created: CustomerInquiry = data.inquiry;

        // Also write to Firestore /inquiries/{id} using public create rule
        try {
          await setDoc(doc(db, 'inquiries', created.id), {
            id: created.id,
            inquiryType: created.inquiryType,
            name: created.name,
            whatsapp: created.whatsapp,
            listingId: created.listingId,
            listingCode: created.listingCode,
            listingTitle: created.listingTitle,
            message: created.message,
            preferredSurveyTime: created.preferredSurveyTime,
            status: 'Baru',
            internalNotes: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch {
          // Server already persisted inquiry if client Firestore is offline
        }

        if (isAdmin) {
          setInquiries((prev) => [created, ...prev]);
        }

        setVisitorInquiries((prev) => {
          const next = [created, ...prev];
          try {
            localStorage.setItem(VISITOR_INQUIRIES_KEY, JSON.stringify(next));
          } catch {
            // Ignore
          }
          return next;
        });

        showToast(
          created.inquiryType === 'Survei'
            ? 'Permintaan jadwal survei berhasil dikirim! Tim broker kami akan segera menghubungi Anda.'
            : 'Pertanyaan Anda berhasil dikirim! Tim broker kami akan segera merespons via WhatsApp.'
        );
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : 'Gagal mengirim pertanyaan.',
        };
      }
    },
    [isAdmin, showToast]
  );

  const updateInquiryAdmin = useCallback(
    async (id: string, status: LeadStatus, internalNotes: string) => {
      const res = await fetch(`/api/inquiries/${id}`, {
        method: 'PUT',
        headers: getAdminHeaders(),
        body: JSON.stringify({ status, internalNotes }),
      });
      if (res.ok) {
        const data = await res.json();
        setInquiries((prev) =>
          prev.map((item) => (item.id === id ? data.inquiry : item))
        );
        if (auth.currentUser) {
          try {
            await updateDoc(doc(db, 'inquiries', id), {
              status,
              internalNotes,
              updatedAt: serverTimestamp(),
            });
          } catch {
            // Synced via backend
          }
        }
        showToast('Status dan catatan internal permintaan diperbarui.');
      }
    },
    [getAdminHeaders, showToast]
  );

  const submitPropertyConsignment = useCallback(
    async (
      input: Partial<PropertySubmission>
    ): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch('/api/submissions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || 'Gagal mengirim pengajuan titip properti.' };
        }
        const created: PropertySubmission = data.submission;

        // Also write to Firestore /submissions/{id} using public create rule
        try {
          await setDoc(doc(db, 'submissions', created.id), {
            id: created.id,
            ownerName: created.ownerName,
            whatsapp: created.whatsapp,
            propertyType: created.propertyType,
            transactionType: created.transactionType,
            location: created.location,
            expectedPrice: created.expectedPrice,
            specifications: created.specifications,
            description: created.description,
            photos: created.photos,
            reviewStatus: 'Menunggu Review',
            leadStatus: 'Baru',
            internalNotes: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch {
          // Persisted via server
        }

        if (isAdmin) {
          setSubmissions((prev) => [created, ...prev]);
        }

        showToast(
          'Pengajuan Titip Properti berhasil disimpan dengan status "Menunggu Review".'
        );
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error:
            err instanceof Error
              ? err.message
              : 'Gagal mengirim pengajuan titip properti.',
        };
      }
    },
    [isAdmin, showToast]
  );

  const updateSubmissionAdmin = useCallback(
    async (id: string, leadStatus: LeadStatus, internalNotes: string) => {
      const res = await fetch(`/api/submissions/${id}`, {
        method: 'PUT',
        headers: getAdminHeaders(),
        body: JSON.stringify({ leadStatus, internalNotes }),
      });
      if (res.ok) {
        const data = await res.json();
        setSubmissions((prev) =>
          prev.map((item) => (item.id === id ? data.submission : item))
        );
        showToast('Status pengajuan titip properti berhasil diperbarui.');
      }
    },
    [getAdminHeaders, showToast]
  );

  const convertSubmissionToListing = useCallback(
    async (
      submission: PropertySubmission
    ): Promise<{ ok: boolean; code?: string }> => {
      const nextNum = listings.length + 1;
      const code = `BP-TITIP-${String(nextNum).padStart(3, '0')}`;
      const title = `${submission.propertyType} ${submission.transactionType} di ${submission.location}`;
      const res = await createListing({
        code,
        title,
        slug: generateSlug(title, code),
        propertyType: submission.propertyType,
        transactionType: submission.transactionType,
        price: submission.expectedPrice,
        area: submission.location.split('—')[0].trim() || 'Batam Center',
        address: submission.location,
        landArea: 120,
        buildingArea: 100,
        bedrooms: 3,
        bathrooms: 2,
        floors: 1,
        facilities: [submission.specifications],
        description: `${submission.description}\n\nSpesifikasi Pemilik: ${submission.specifications}`,
        photos:
          submission.photos.length > 0
            ? submission.photos
            : ['/images/rumah-batam-center.svg'],
        mainPhotoIndex: 0,
        isFeatured: false,
        isDemo: false,
        status: 'Menunggu Review',
        listedDate: new Date().toISOString().slice(0, 10),
      });
      if (res.ok) {
        await updateSubmissionAdmin(
          submission.id,
          'Selesai',
          `${submission.internalNotes ? submission.internalNotes + ' | ' : ''}Dikonversi menjadi Listing ${code} (Menunggu Review)`
        );
        return { ok: true, code };
      }
      return { ok: false };
    },
    [createListing, listings.length, updateSubmissionAdmin]
  );

  const updateSiteSettings = useCallback(
    async (
      nextSettings: Partial<SiteSettings>
    ): Promise<{ ok: boolean; error?: string }> => {
      try {
        const res = await fetch('/api/settings', {
          method: 'PUT',
          headers: getAdminHeaders(),
          body: JSON.stringify(nextSettings),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || 'Gagal menyimpan pengaturan.' };
        }
        setSettings(data.settings);

        if (auth.currentUser) {
          try {
            await setDoc(doc(db, 'settings', 'general'), {
              ...data.settings,
              updatedAt: serverTimestamp(),
            });
          } catch (fsErr) {
            handleFirestoreError(fsErr, OperationType.WRITE, 'settings/general');
          }
        }

        showToast('Pengaturan website BatamProperti.com berhasil disimpan.');
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error:
            err instanceof Error ? err.message : 'Gagal memperbarui pengaturan.',
        };
      }
    },
    [getAdminHeaders, showToast]
  );

  const updateSeoMeta = useCallback(
    (title: string, description: string) => {
      const fullTitle = title.includes(settings.siteName)
        ? title
        : `${title} | ${settings.siteName}`;
      document.title = fullTitle;
      const setMeta = (selector: string, content: string) => {
        const el = document.querySelector(selector);
        if (el) el.setAttribute('content', content);
      };
      setMeta('meta[name="description"]', description);
      setMeta('meta[property="og:title"]', fullTitle);
      setMeta('meta[property="og:description"]', description);
      setMeta('meta[name="twitter:title"]', fullTitle);
      setMeta('meta[name="twitter:description"]', description);
    },
    [settings.siteName]
  );

  const recordUserSearchIntent = useCallback(
    (
      input: Partial<FilterState> & {
        priceRangeLabel?: string;
        targetPrice?: number;
      }
    ) => {
      setUserPreferences((prev) => {
        const next = deriveUserPreferenceFromSearch(prev, input);
        try {
          localStorage.setItem(USER_PREFS_STORAGE_KEY, JSON.stringify(next));
        } catch {
          // Ignore storage error
        }
        return next;
      });
    },
    []
  );

  const resetUserPreferences = useCallback(() => {
    const fresh: UserPreferenceProfile = {
      viewedListingIds: [],
      updatedAt: new Date().toISOString(),
    };
    setUserPreferences(fresh);
    try {
      localStorage.removeItem(USER_PREFS_STORAGE_KEY);
    } catch {
      // Ignore
    }
  }, []);

  const recordListingInteraction = useCallback(
    (listing: PropertyListing, type: 'view' | 'wa_click') => {
      const now = new Date().toISOString();

      // Optimistically update local listing engagement counter
      setListings((prev) =>
        prev.map((item) => {
          if (item.id !== listing.id) return item;
          return {
            ...item,
            viewsCount: (item.viewsCount || 0) + 1,
            waClicksCount:
              type === 'wa_click'
                ? (item.waClicksCount || 0) + 1
                : item.waClicksCount || 0,
            lastClickedAt: now,
          };
        })
      );

      // Update user preference profile based on the property they clicked
      setUserPreferences((prev) => {
        const viewed = prev.viewedListingIds.includes(listing.id)
          ? prev.viewedListingIds
          : [listing.id, ...prev.viewedListingIds].slice(0, 15);

        const hasExplicitPrice =
          typeof prev.targetPrice === 'number' && prev.targetPrice > 0;

        const next: UserPreferenceProfile = {
          ...prev,
          viewedListingIds: viewed,
          preferredArea: prev.preferredArea || listing.area,
          preferredPropertyType:
            prev.preferredPropertyType || listing.propertyType,
          targetPrice: hasExplicitPrice ? prev.targetPrice : listing.price,
          priceRangeLabel:
            prev.priceRangeLabel ||
            `Sekitar ${formatRupiahRingkas(listing.price, listing.pricePeriod)}`,
          updatedAt: now,
        };
        try {
          localStorage.setItem(USER_PREFS_STORAGE_KEY, JSON.stringify(next));
        } catch {
          // Ignore
        }
        return next;
      });

      // Also write engagement event to Firestore /listing_events/{eventId} for real-time Firestore aggregation
      const eventId = `evt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setDoc(doc(db, 'listing_events', eventId), {
        id: eventId,
        listingId: listing.id,
        listingCode: listing.code,
        listingTitle: listing.title.slice(0, 200),
        area: listing.area.slice(0, 100),
        propertyType: listing.propertyType,
        eventType: type,
        createdAt: serverTimestamp(),
      }).catch(() => {
        // Fallback persisted via server if Firestore offline
      });

      // Persist click/view to backend asynchronously
      fetch(`/api/listings/${encodeURIComponent(listing.id)}/track`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data?.listing) {
            setListings((prev) =>
              prev.map((item) => (item.id === listing.id ? data.listing : item))
            );
          }
        })
        .catch(() => {
          // Ignore network error
        });
    },
    []
  );

  // Sync Firestore read when authenticated as Firebase admin
  useEffect(() => {
    if (!auth.currentUser) return;
    getDocs(collection(db, 'listings')).catch(() => {
      // Handled via server state
    });
  }, [adminSession]);

  const publicListings = useMemo(
    () =>
      listings.filter((item) => PUBLIC_VISIBLE_STATUSES.includes(item.status)),
    [listings]
  );

  const value = useMemo<PropertyContextValue>(
    () => ({
      listings,
      publicListings,
      inquiries,
      submissions,
      settings,
      favorites,
      visitorInquiries,
      isAdmin,
      adminSession,
      firestoreConnected,
      firebaseProjectInfo,
      loading,
      toast,
      showToast,
      clearToast,
      toggleFavorite,
      loginAdminGoogle,
      loginAdminWithToken,
      logoutAdmin,
      createListing,
      updateListing,
      deleteListing,
      clearDemoListings,
      restoreDemoListings,
      submitInquiry,
      updateInquiryAdmin,
      submitPropertyConsignment,
      updateSubmissionAdmin,
      convertSubmissionToListing,
      updateSiteSettings,
      updateSeoMeta,
      userPreferences,
      recordListingInteraction,
      recordUserSearchIntent,
      resetUserPreferences,
    }),
    [
      listings,
      publicListings,
      inquiries,
      submissions,
      settings,
      favorites,
      visitorInquiries,
      isAdmin,
      adminSession,
      firestoreConnected,
      loading,
      toast,
      showToast,
      clearToast,
      toggleFavorite,
      loginAdminGoogle,
      loginAdminWithToken,
      logoutAdmin,
      createListing,
      updateListing,
      deleteListing,
      clearDemoListings,
      restoreDemoListings,
      submitInquiry,
      updateInquiryAdmin,
      submitPropertyConsignment,
      updateSubmissionAdmin,
      convertSubmissionToListing,
      updateSiteSettings,
      updateSeoMeta,
      userPreferences,
      recordListingInteraction,
      recordUserSearchIntent,
      resetUserPreferences,
    ]
  );

  return (
    <PropertyContext.Provider value={value}>
      {children}
    </PropertyContext.Provider>
  );
};

export function useProperty(): PropertyContextValue {
  const ctx = useContext(PropertyContext);
  if (!ctx) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return ctx;
}
