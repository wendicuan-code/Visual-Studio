import React, { useEffect, useState } from 'react';
import { PropertyProvider, useProperty } from './context/PropertyContext';
import { Navbar, RoutePath } from './components/Navbar';
import { Footer } from './components/Footer';
import { InquiryModal } from './components/InquiryModal';
import { WhatsAppFab } from './components/WhatsAppFab';
import { HomePage } from './pages/HomePage';
import { CatalogPage } from './pages/CatalogPage';
import { PropertyDetailPage } from './pages/PropertyDetailPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { ConsignPage } from './pages/ConsignPage';
import { InfoPage } from './pages/InfoPage';
import { AdminPage } from './pages/AdminPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { DEFAULT_FILTERS } from './utils/propertyLogic';
import {
  FilterState,
  PropertyListing,
  PropertyType,
  TransactionType,
} from './types/property';

function parseLocationToRoute(): RoutePath {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (path === '/' || path === '') return { page: 'home' };
  if (path === '/properti-baru' || path === '/properti-primary') {
    return { page: 'catalog', presetPrimary: true };
  }
  if (path === '/katalog') return { page: 'catalog', presetPrimary: false };
  if (path.startsWith('/properti/')) {
    const slug = decodeURIComponent(path.replace('/properti/', ''));
    return { page: 'detail', slug };
  }
  if (path === '/favorit') return { page: 'favorites' };
  if (path === '/titip-properti') return { page: 'consign' };
  if (path === '/informasi' || path === '/tentang-kami') {
    return { page: 'info', tab: 'tentang' };
  }
  if (path === '/kontak') return { page: 'info', tab: 'kontak' };
  if (path === '/faq') return { page: 'info', tab: 'faq' };
  if (path === '/kebijakan-privasi') return { page: 'info', tab: 'privasi' };
  if (path === '/syarat-penggunaan') return { page: 'info', tab: 'syarat' };
  if (path === '/admin88') return { page: 'admin' };
  return { page: 'not-found' };
}

function routeToUrl(route: RoutePath): string {
  switch (route.page) {
    case 'home':
      return '/';
    case 'catalog':
      return route.presetPrimary ? '/properti-baru' : '/katalog';
    case 'detail':
      return `/properti/${encodeURIComponent(route.slug)}`;
    case 'favorites':
      return '/favorit';
    case 'consign':
      return '/titip-properti';
    case 'info':
      if (route.tab === 'kontak') return '/kontak';
      if (route.tab === 'faq') return '/faq';
      if (route.tab === 'privasi') return '/kebijakan-privasi';
      if (route.tab === 'syarat') return '/syarat-penggunaan';
      return '/informasi';
    case 'admin':
      return '/admin88';
    default:
      return '/404';
  }
}

const PortalMain: React.FC = () => {
  const { toast, clearToast, recordUserSearchIntent } = useProperty();
  const [currentRoute, setCurrentRoute] = useState<RoutePath>(() =>
    parseLocationToRoute()
  );
  const [filters, setFilters] = useState<FilterState>(() => {
    const initial = parseLocationToRoute();
    if (initial.page === 'catalog' && initial.presetPrimary) {
      return { ...DEFAULT_FILTERS, onlyNew: true };
    }
    return DEFAULT_FILTERS;
  });
  const [modalListing, setModalListing] = useState<PropertyListing | null>(null);
  const [modalMode, setModalMode] = useState<'Pertanyaan' | 'Survei'>('Survei');
  const [showInquiryModal, setShowInquiryModal] = useState(false);

  useEffect(() => {
    const onPopState = () => {
      const next = parseLocationToRoute();
      setCurrentRoute(next);
      if (next.page === 'catalog') {
        setFilters((prev) => ({
          ...prev,
          onlyNew: Boolean(next.presetPrimary),
        }));
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = (nextRoute: RoutePath) => {
    if (nextRoute.page === 'catalog') {
      if (typeof nextRoute.presetPrimary === 'boolean') {
        setFilters({
          ...DEFAULT_FILTERS,
          onlyNew: nextRoute.presetPrimary,
        });
      } else if (nextRoute.presetArea) {
        setFilters({ ...DEFAULT_FILTERS, area: nextRoute.presetArea });
        recordUserSearchIntent({ area: nextRoute.presetArea });
      } else if (nextRoute.presetType) {
        setFilters({
          ...DEFAULT_FILTERS,
          propertyType: nextRoute.presetType as PropertyType,
        });
        recordUserSearchIntent({
          propertyType: nextRoute.presetType as PropertyType,
        });
      } else if (nextRoute.presetTransaction) {
        setFilters({
          ...DEFAULT_FILTERS,
          transactionType: nextRoute.presetTransaction as TransactionType,
        });
        recordUserSearchIntent({
          transactionType: nextRoute.presetTransaction as TransactionType,
        });
      }
    }
    const url = routeToUrl(nextRoute);
    if (window.location.pathname !== url) {
      window.history.pushState({}, '', url);
    }
    setCurrentRoute(nextRoute);
  };

  const handleApplyQuickSearch = (partial: Partial<FilterState>) => {
    setFilters({
      ...DEFAULT_FILTERS,
      ...partial,
    });
    recordUserSearchIntent(partial);
  };

  const handleOpenSurveyModal = (
    listing: PropertyListing,
    mode: 'Pertanyaan' | 'Survei' = 'Survei'
  ) => {
    setModalListing(listing);
    setModalMode(mode);
    setShowInquiryModal(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-slate-900 font-sans">
      <Navbar currentRoute={currentRoute} navigate={navigate} />

      {/* Global Toast Notification */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-24 right-5 z-50 max-w-md bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center justify-between gap-4 text-xs"
        >
          <span>{toast.text}</span>
          <button
            type="button"
            onClick={clearToast}
            className="text-emerald-400 font-semibold hover:underline shrink-0"
          >
            Tutup
          </button>
        </div>
      )}

      <main className="flex-1">
        {currentRoute.page === 'home' && (
          <HomePage
            navigate={navigate}
            onApplyQuickSearch={handleApplyQuickSearch}
            onAskSurvey={(l) => handleOpenSurveyModal(l, 'Survei')}
          />
        )}

        {currentRoute.page === 'catalog' && (
          <CatalogPage
            filters={filters}
            setFilters={setFilters}
            navigate={navigate}
            onAskSurvey={(l) => handleOpenSurveyModal(l, 'Survei')}
          />
        )}

        {currentRoute.page === 'detail' && (
          <PropertyDetailPage
            slug={currentRoute.slug}
            navigate={navigate}
            onAskSurvey={handleOpenSurveyModal}
          />
        )}

        {currentRoute.page === 'favorites' && (
          <FavoritesPage
            navigate={navigate}
            onAskSurvey={(l) => handleOpenSurveyModal(l, 'Survei')}
          />
        )}

        {currentRoute.page === 'consign' && <ConsignPage navigate={navigate} />}

        {currentRoute.page === 'info' && (
          <InfoPage initialTab={currentRoute.tab} navigate={navigate} />
        )}

        {currentRoute.page === 'admin' && <AdminPage navigate={navigate} />}

        {currentRoute.page === 'not-found' && (
          <NotFoundPage navigate={navigate} />
        )}
      </main>

      <Footer navigate={navigate} />

      {/* Persistent Bottom-Right WhatsApp Floating Action Button */}
      <WhatsAppFab />

      {showInquiryModal && (
        <InquiryModal
          listing={modalListing}
          defaultType={modalMode}
          onClose={() => setShowInquiryModal(false)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <PropertyProvider>
      <PortalMain />
    </PropertyProvider>
  );
}
