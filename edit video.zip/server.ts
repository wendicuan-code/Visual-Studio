import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import {
  DEMO_INQUIRIES,
  DEMO_LISTINGS,
  DEMO_SUBMISSIONS,
  INITIAL_SITE_SETTINGS,
} from './src/data/demoData';
import {
  CustomerInquiry,
  PropertyListing,
  PropertySubmission,
  SiteSettings,
} from './src/types/property';
import {
  generateSlug,
  PUBLIC_VISIBLE_STATUSES,
  validateInquiryInput,
  validateListingInput,
  validateSubmissionInput,
} from './src/utils/propertyLogic';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

interface DatabaseSchema {
  listings: PropertyListing[];
  inquiries: CustomerInquiry[];
  submissions: PropertySubmission[];
  settings: SiteSettings;
}

function loadDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf8');
      const parsed = JSON.parse(raw) as Partial<DatabaseSchema>;
      let loadedListings = Array.isArray(parsed.listings)
        ? parsed.listings
        : [...DEMO_LISTINGS];

      // Backfill marketCategory, viewsCount & waClicksCount on existing listings
      const demoMap = new Map(DEMO_LISTINGS.map((d) => [d.id, d]));
      loadedListings = loadedListings.map((item) => {
        const demoRef = demoMap.get(item.id);
        return {
          ...item,
          marketCategory:
            item.marketCategory === 'Primary' || item.marketCategory === 'Secondary'
              ? item.marketCategory
              : demoRef?.marketCategory ?? 'Secondary',
          viewsCount:
            typeof item.viewsCount === 'number'
              ? item.viewsCount
              : demoRef?.viewsCount ?? 25,
          waClicksCount:
            typeof item.waClicksCount === 'number'
              ? item.waClicksCount
              : demoRef?.waClicksCount ?? 6,
          lastClickedAt: item.lastClickedAt || demoRef?.lastClickedAt || item.updatedAt,
        };
      });

      const hasAnyDemo = loadedListings.some((l) => l.isDemo);
      if (hasAnyDemo) {
        for (const demoItem of DEMO_LISTINGS) {
          if (!loadedListings.some((l) => l.id === demoItem.id)) {
            loadedListings.push(demoItem);
          }
        }
      }

      const hydrated: DatabaseSchema = {
        listings: loadedListings,
        inquiries: Array.isArray(parsed.inquiries) ? parsed.inquiries : [...DEMO_INQUIRIES],
        submissions: Array.isArray(parsed.submissions)
          ? parsed.submissions
          : [...DEMO_SUBMISSIONS],
        settings: parsed.settings ? { ...INITIAL_SITE_SETTINGS, ...parsed.settings } : { ...INITIAL_SITE_SETTINGS },
      };
      saveDatabase(hydrated);
      return hydrated;
    }
  } catch (err) {
    console.error('Failed to read local database file, using initial seed:', err);
  }
  const initial: DatabaseSchema = {
    listings: [...DEMO_LISTINGS],
    inquiries: [...DEMO_INQUIRIES],
    submissions: [...DEMO_SUBMISSIONS],
    settings: { ...INITIAL_SITE_SETTINGS },
  };
  saveDatabase(initial);
  return initial;
}

function saveDatabase(db: DatabaseSchema): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write local database file:', err);
  }
}

const dbState = loadDatabase();

const ADMIN_SETUP_TOKEN =
  process.env.ADMIN_SETUP_TOKEN || 'BATAM_PROPERTI_ADMIN_SETUP';
const ADMIN_BOOTSTRAP_EMAIL = 'properti988@gmail.com';
const EXTRA_ADMIN_SECRET = process.env.ADMIN_BOOTSTRAP_EMAIL || '';

function isAuthorizedAdminRequest(req: express.Request): boolean {
  const authHeader = req.headers['x-admin-token'] || req.headers['authorization'];
  const emailHeader = req.headers['x-admin-email'];

  if (
    typeof emailHeader === 'string' &&
    (emailHeader.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase() ||
      emailHeader.toLowerCase() === 'admin' ||
      (EXTRA_ADMIN_SECRET && emailHeader === EXTRA_ADMIN_SECRET))
  ) {
    return true;
  }

  if (typeof authHeader === 'string') {
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    if (
      token === ADMIN_SETUP_TOKEN ||
      token === 'BATAM_PROPERTI_ADMIN_SETUP' ||
      token === 'FIREBASE_VERIFIED_ADMIN' ||
      (EXTRA_ADMIN_SECRET && token === EXTRA_ADMIN_SECRET)
    ) {
      return true;
    }
  }

  return false;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // 1. Public & Admin Bootstrap State API
  app.get('/api/state', (req, res) => {
    const isAdmin = isAuthorizedAdminRequest(req);
    const visibleListings = isAdmin
      ? dbState.listings
      : dbState.listings.filter((item) => PUBLIC_VISIBLE_STATUSES.includes(item.status));

    res.json({
      listings: visibleListings,
      settings: dbState.settings,
      // PII strictly isolated to Admin
      inquiries: isAdmin ? dbState.inquiries : [],
      submissions: isAdmin ? dbState.submissions : [],
      serverInfo: {
        firebaseConfigured: fs.existsSync(path.join(__dirname, 'firebase-applet-config.json')),
        adminBootstrapEmail: ADMIN_BOOTSTRAP_EMAIL,
        hasSetupTokenEnv: Boolean(process.env.ADMIN_SETUP_TOKEN),
      },
    });
  });

  // 2. Admin Setup Token / Session Verification
  app.post('/api/admin/verify', (req, res) => {
    const { setupToken, email } = req.body || {};
    if (
      typeof email === 'string' &&
      email.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase()
    ) {
      return res.json({
        authorized: true,
        role: 'admin',
        mode: 'firebase-email',
        email: 'Admin',
      });
    }

    if (
      typeof setupToken === 'string' &&
      (setupToken.trim() === ADMIN_SETUP_TOKEN ||
        setupToken.trim() === 'BATAM_PROPERTI_ADMIN_SETUP' ||
        (EXTRA_ADMIN_SECRET && setupToken.trim() === EXTRA_ADMIN_SECRET))
    ) {
      return res.json({
        authorized: true,
        role: 'admin',
        mode: 'setup-token',
        email: 'Admin',
      });
    }

    return res.status(401).json({
      authorized: false,
      error:
        'Token setup admin tidak sesuai. Gunakan Login Google Admin resmi atau masukkan token setup sesuai variabel environment ADMIN_SETUP_TOKEN.',
    });
  });

  // 3. Public Customer Inquiry / Survey Request Creation
  app.post('/api/inquiries', (req, res) => {
    const body = req.body || {};
    const validation = validateInquiryInput(body);
    if (!validation.valid) {
      return res.status(400).json({ error: validation.errors.join(' ') });
    }

    const now = new Date().toISOString();
    const newInquiry: CustomerInquiry = {
      id: body.id || `inq-${Date.now()}`,
      inquiryType: body.inquiryType === 'Survei' ? 'Survei' : 'Pertanyaan',
      name: String(body.name).trim().slice(0, 120),
      whatsapp: String(body.whatsapp).trim().slice(0, 30),
      listingId: String(body.listingId || 'general').slice(0, 128),
      listingCode: String(body.listingCode || 'UMUM').slice(0, 40),
      listingTitle: String(body.listingTitle || 'Konsultasi Properti Batam').slice(0, 200),
      message: String(body.message).trim().slice(0, 2000),
      preferredSurveyTime: String(body.preferredSurveyTime || 'Fleksibel').trim().slice(0, 120),
      status: 'Baru',
      internalNotes: '',
      createdAt: now,
      updatedAt: now,
    };

    dbState.inquiries.unshift(newInquiry);
    saveDatabase(dbState);
    return res.status(201).json({ inquiry: newInquiry });
  });

  // 4. Admin Update / Delete Inquiry
  app.put('/api/inquiries/:id', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    const idx = dbState.inquiries.findIndex((i) => i.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Data pertanyaan tidak ditemukan.' });
    }
    const { status, internalNotes } = req.body || {};
    dbState.inquiries[idx] = {
      ...dbState.inquiries[idx],
      status: status || dbState.inquiries[idx].status,
      internalNotes:
        typeof internalNotes === 'string'
          ? internalNotes.slice(0, 2000)
          : dbState.inquiries[idx].internalNotes,
      updatedAt: new Date().toISOString(),
    };
    saveDatabase(dbState);
    return res.json({ inquiry: dbState.inquiries[idx] });
  });

  // 5. Public Property Consignment Submission (Titip Properti)
  app.post('/api/submissions', (req, res) => {
    const body = req.body || {};
    const validation = validateSubmissionInput({
      ...body,
      expectedPrice: Number(body.expectedPrice),
    });
    if (!validation.valid) {
      return res.status(400).json({ error: validation.errors.join(' ') });
    }

    const now = new Date().toISOString();
    const newSubmission: PropertySubmission = {
      id: body.id || `sub-${Date.now()}`,
      ownerName: String(body.ownerName).trim().slice(0, 120),
      whatsapp: String(body.whatsapp).trim().slice(0, 30),
      propertyType: body.propertyType || 'Rumah',
      transactionType: body.transactionType === 'Disewakan' ? 'Disewakan' : 'Dijual',
      location: String(body.location).trim().slice(0, 200),
      expectedPrice: Number(body.expectedPrice),
      specifications: String(body.specifications).trim().slice(0, 1000),
      description: String(body.description).trim().slice(0, 3000),
      photos: Array.isArray(body.photos) ? body.photos.slice(0, 10) : [],
      reviewStatus: 'Menunggu Review',
      leadStatus: 'Baru',
      internalNotes: '',
      createdAt: now,
      updatedAt: now,
    };

    dbState.submissions.unshift(newSubmission);
    saveDatabase(dbState);
    return res.status(201).json({ submission: newSubmission });
  });

  // 6. Admin Update Submission
  app.put('/api/submissions/:id', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    const idx = dbState.submissions.findIndex((s) => s.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Data pengajuan tidak ditemukan.' });
    }
    const { leadStatus, internalNotes } = req.body || {};
    dbState.submissions[idx] = {
      ...dbState.submissions[idx],
      leadStatus: leadStatus || dbState.submissions[idx].leadStatus,
      internalNotes:
        typeof internalNotes === 'string'
          ? internalNotes.slice(0, 2000)
          : dbState.submissions[idx].internalNotes,
      updatedAt: new Date().toISOString(),
    };
    saveDatabase(dbState);
    return res.json({ submission: dbState.submissions[idx] });
  });

  // 7. Admin Create Listing
  app.post('/api/listings', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    const body = req.body || {};
    const validation = validateListingInput(
      { ...body, price: Number(body.price) },
      dbState.listings
    );
    if (!validation.valid) {
      return res.status(400).json({ error: validation.errors.join(' ') });
    }

    const now = new Date().toISOString();
    const code = String(body.code).trim().toUpperCase();
    const title = String(body.title).trim();
    const slug = body.slug
      ? String(body.slug).trim().toLowerCase()
      : generateSlug(title, code);

    const newListing: PropertyListing = {
      id: body.id || `prop-${Date.now()}`,
      code,
      title,
      slug,
      propertyType: body.propertyType || 'Rumah',
      transactionType: body.transactionType === 'Disewakan' ? 'Disewakan' : 'Dijual',
      marketCategory: body.marketCategory === 'Primary' ? 'Primary' : 'Secondary',
      price: Number(body.price),
      pricePeriod: String(body.pricePeriod || '').trim(),
      area: String(body.area).trim(),
      complexName: String(body.complexName || '').trim(),
      address: String(body.address || '').trim(),
      landArea: Number(body.landArea) || 0,
      buildingArea: Number(body.buildingArea) || 0,
      dimensions: String(body.dimensions || '').trim(),
      bedrooms: Number(body.bedrooms) || 0,
      bathrooms: Number(body.bathrooms) || 0,
      floors: Number(body.floors) || 0,
      furnishStatus: String(body.furnishStatus || '').trim(),
      facilities: Array.isArray(body.facilities) ? body.facilities.slice(0, 20) : [],
      description: String(body.description).trim().slice(0, 4000),
      photos:
        Array.isArray(body.photos) && body.photos.length > 0
          ? body.photos.slice(0, 15)
          : ['/images/rumah-batam-center.svg'],
      mainPhotoIndex: Number(body.mainPhotoIndex) || 0,
      videoUrl: String(body.videoUrl || '').trim(),
      legalStatus: String(body.legalStatus || '').trim(),
      isFeatured: Boolean(body.isFeatured),
      isDemo: Boolean(body.isDemo),
      status: body.status || 'Aktif',
      listedDate: body.listedDate || now.slice(0, 10),
      viewsCount: Number(body.viewsCount) || 0,
      waClicksCount: Number(body.waClicksCount) || 0,
      createdAt: now,
      updatedAt: now,
    };

    dbState.listings.unshift(newListing);
    saveDatabase(dbState);
    return res.status(201).json({ listing: newListing });
  });

  // 7b. Public Track Listing View / WhatsApp Click Engagement
  app.post('/api/listings/:id/track', (req, res) => {
    const idx = dbState.listings.findIndex(
      (l) => l.id === req.params.id || l.slug === req.params.id || l.code === req.params.id
    );
    if (idx === -1) {
      return res.status(404).json({ error: 'Listing tidak ditemukan.' });
    }
    const { type } = req.body || {};
    const existing = dbState.listings[idx];
    const now = new Date().toISOString();

    const updated: PropertyListing = {
      ...existing,
      viewsCount:
        type === 'wa_click'
          ? (existing.viewsCount || 0) + 1
          : (existing.viewsCount || 0) + 1,
      waClicksCount:
        type === 'wa_click'
          ? (existing.waClicksCount || 0) + 1
          : existing.waClicksCount || 0,
      lastClickedAt: now,
    };

    dbState.listings[idx] = updated;
    saveDatabase(dbState);
    return res.json({ listing: updated });
  });

  // 8. Admin Update Listing
  app.put('/api/listings/:id', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    const idx = dbState.listings.findIndex((l) => l.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Listing tidak ditemukan.' });
    }
    const existing = dbState.listings[idx];
    const body = req.body || {};
    const merged: PropertyListing = {
      ...existing,
      ...body,
      id: existing.id,
      marketCategory:
        body.marketCategory === 'Primary' || body.marketCategory === 'Secondary'
          ? body.marketCategory
          : existing.marketCategory || 'Secondary',
      price: body.price !== undefined ? Number(body.price) : existing.price,
      landArea: body.landArea !== undefined ? Number(body.landArea) : existing.landArea,
      buildingArea:
        body.buildingArea !== undefined ? Number(body.buildingArea) : existing.buildingArea,
      bedrooms: body.bedrooms !== undefined ? Number(body.bedrooms) : existing.bedrooms,
      bathrooms: body.bathrooms !== undefined ? Number(body.bathrooms) : existing.bathrooms,
      floors: body.floors !== undefined ? Number(body.floors) : existing.floors,
      updatedAt: new Date().toISOString(),
    };

    const validation = validateListingInput(merged, dbState.listings, existing.id);
    if (!validation.valid) {
      return res.status(400).json({ error: validation.errors.join(' ') });
    }

    merged.slug = body.slug
      ? String(body.slug).trim().toLowerCase()
      : generateSlug(merged.title, merged.code);

    dbState.listings[idx] = merged;
    saveDatabase(dbState);
    return res.json({ listing: merged });
  });

  // 9. Admin Delete Listing or Clear All Demo Listings
  app.delete('/api/listings/:id', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    if (req.params.id === 'clear-demo') {
      dbState.listings = dbState.listings.filter((l) => !l.isDemo);
      saveDatabase(dbState);
      return res.json({ listings: dbState.listings });
    }
    if (req.params.id === 'restore-demo') {
      const nonDemo = dbState.listings.filter((l) => !l.isDemo);
      dbState.listings = [...nonDemo, ...DEMO_LISTINGS];
      saveDatabase(dbState);
      return res.json({ listings: dbState.listings });
    }
    dbState.listings = dbState.listings.filter((l) => l.id !== req.params.id);
    saveDatabase(dbState);
    return res.json({ success: true });
  });

  // 10. Admin Update Website Settings
  app.put('/api/settings', (req, res) => {
    if (!isAuthorizedAdminRequest(req)) {
      return res.status(403).json({ error: 'Akses ditolak. Hanya admin yang diizinkan.' });
    }
    const body = req.body || {};
    dbState.settings = {
      ...dbState.settings,
      ...body,
      updatedAt: new Date().toISOString(),
    };
    saveDatabase(dbState);
    return res.json({ settings: dbState.settings });
  });

  // Vite middleware in development or static dist in production
  const distPath = path.join(__dirname, 'dist');
  if (process.env.NODE_ENV === 'production' && fs.existsSync(distPath)) {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`BatamProperti.com server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
